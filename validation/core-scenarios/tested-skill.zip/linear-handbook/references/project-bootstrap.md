# 小型待辦產品：從環境初始化到首批 Issues

本案例為虛構規畫，以紙上核對示範個人開發者與多個 Agent 的工作安排。
本文代號與配置均為示範設定。

- 初始化：[Workspace 初始化與接手](workspace-setup.md)。
- Project 規畫：[從需求建立 Project](project-planning.md)。
- Brief 欄位：[Project brief 範本](../assets/templates/project-brief.md)。
- 排程：[Milestone 與相依排程](planning-and-dependencies.md)。
- 拆分：[單一 session 成果](issue-decomposition.md)。

## 情境與輸入

- 模擬需求紀錄 R1
  - 使用者每天開啟同一台電腦，想快速記下少量待辦。
  - 重新整理網頁後，仍需看到待辦內容與完成狀態。
  - 第一版需新增待辦。
  - 第一版需切換完成狀態。
- 模擬環境紀錄 E1
  - 維護者已有個人開發用 Linear Workspace。
  - 既有 Product Team 承接個人產品開發。
  - 搜尋後沒有相同成果的 Project 或 issues。
  - 產品 repository `pocket-tasks` 已有可啟動的空白網頁與測試指令。
- 需求決策
  - 使用同一瀏覽器的本機儲存。
  - 需要持久化失敗的提示與重試方式。
  - 帳號不納入第一版。
  - 跨裝置同步不納入第一版。
  - 刪除功能不納入第一版。
  - 理由：R1 的核心成果只需要本機新增與完成標記。

## Workspace 與物件選擇

### 選擇理由

- Workspace：沿用 E1 的個人開發 Workspace。
  - 理由：產品仍由同一位維護者管理，沒有新的組織邊界。
- Team：沿用 Product Team。
  - 理由：首批工作共用流程與存取範圍。
- Project：建立「在本機保留待辦與完成狀態」。
  - 理由：用共同 Brief 協調四份交付，並追蹤首版整體成果。
- Milestone：以 M1 與 M2 表達兩種可驗收成果。
  - 具體成果與所屬 issues 見「Milestones」。
- Issue：四項工作各自提供下游可用的成果。
  - 具體邊界見「首批 Issues」。
- Parent：本案例由 Project 保留整體驗收，四項 issues 直接歸入 Project。
  - 理由：四項工作涵蓋同一首版成果，另加 parent 會重複相同驗收。
- Cycle：本案例先依成果相依安排。
  - 理由：尚無固定週期的容量紀錄。

### E1 的採用配置

以下依[環境紀錄](workspace-setup.md#環境紀錄)的欄位填寫案例決策。

- Workspace
  - 名稱：個人產品開發。
  - 設定管理者：產品維護者。
- Team
  - 名稱：Product。
  - Identifier：TASK。
  - 時區：Asia/Taipei。
  - 存取範圍：維護者與本次執行連線。
- Issue status
  - 待排程：Backlog。
  - 待執行：Todo。
  - 執行中：In Progress。
  - 審閱與驗收：保留 In Progress。
  - 完成：Done。
  - 取消：Canceled。
  - Default status：Backlog。
  - 選擇理由：預設工作階段足以表達本案例進度。
- Automations
  - 採用手動完成驗收後更新狀態。
  - 沿用環境前需逐條核對會改變 status 的既有規則。
- Priority：No priority。
  - 理由：尚無額外急迫性差異，先依真正前置安排。
- Estimates：未啟用。
  - 理由：先以可驗收成果邊界與 WIP 管理本批工作。
- Labels：留空。
  - 理由：四項工作目前沒有反覆分類的需要。
- 執行身分
  - 人類 Assignee：產品維護者。
  - Agent A：執行 TASK-A 後接續儲存與整合工作。
  - Agent B：執行介面工作。
  - 連線方式：採用已授權 MCP 連線。
  - 操作範圍：限指定 issue 與其交付檔案。
  - 選擇理由：人類承擔成果責任，各 Agent 範圍可明確交接。
- 通知
  - 查看入口：Inbox。
  - Subscription：維護者訂閱本批正式工作。
  - 選擇理由：首批工作由同一人持續追蹤。

### 由盤點進入首批工作

1. 按[既有環境接手清單](workspace-setup.md#既有環境接手清單)核對 E1 對應的真實值。
2. 保存實際 Workspace 識別資料。
3. 保存 Team UUID。
4. 逐項保存 status ID 與類別。
5. 確認執行連線可讀取目標 Team。
6. 由維護者確認設定管理權限。
7. 確認 repository 的啟動與測試方式。
8. 依下方 Brief 建立 Project。
9. 建立 M1 與 M2，分別填入階段驗收。
10. 將首批工作逐項建立並回填實際入口。
11. 設定「相依與執行順序」中的關係。
12. 讀回首批 issues 的 Team 與 Project 歸屬。
13. 核對 milestone 歸屬。
14. 核對初始 status 與選用欄位。
15. 在 TASK-A 內文回填可供接手的環境紀錄。

從空白環境轉用時，先完成[空白環境初始化清單](workspace-setup.md#空白環境初始化清單)，再進入上述 Project 規畫。

## Project brief：在本機保留待辦與完成狀態

### 問題與成果

- 目標使用者：在同一瀏覽器管理少量待辦的個人。
- 問題：R1 的使用者需要在重新開啟網頁後繼續處理待辦。
- 需求依據：本文「模擬需求紀錄 R1」。
- 預期成果
  - 使用者能新增待辦。
  - 使用者能切換完成狀態。
  - 重新載入後保留結果。

### 範圍

- 本次交付
  - 待辦新增。
  - 完成狀態切換。
  - 本機持久化。
  - 無法讀寫本機資料時的錯誤處理。
- 排除範圍
  - 帳號：R1 尚無此需求。
  - 跨裝置同步：R1 尚無此需求。
  - 刪除待辦：另待使用需求確認。
- 限制
  - 僅同一瀏覽器設定檔使用，依本文需求決策。
  - 採用 E1 既有網頁專案與測試工具。
- 工作位置
  - 示範 repository：`pocket-tasks`。
    - `docs/task-contract.md`：資料與介面契約。
    - `src/tasks/`：儲存能力。
    - `src/ui/`：待辦介面。
    - `src/app/`：組裝入口。
    - `tests/`：沿用既有工具驗證行為。
    - `docs/acceptance.md`：整體驗收證據。

### 成功標準

- [ ] 新增兩筆待辦後，重新載入仍保留文字與順序。
  1. 以空資料開始。
  2. 新增「買牛奶」與「整理書桌」。
  3. 重新載入，核對兩筆文字與先後順序。
- [ ] 完成狀態可切換並持續保存。
  1. 將「買牛奶」標為完成。
  2. 重新載入並核對完成狀態。
  3. 取消完成，再載入並核對未完成狀態。
- [ ] 空白文字遭拒絕，既有待辦保持完整。
- [ ] 寫入失敗時顯示錯誤，保留輸入供重試。
- [ ] 讀取失敗或資料格式損壞時顯示錯誤，保留原始資料並停止寫入。

### 角色與執行入口

- Project lead：產品維護者。
- 需求決策者：產品維護者。
- 驗收者：產品維護者。
- 執行分工
  - Agent A
    - TASK-A。
    - TASK-B。
    - TASK-D。
  - Agent B：TASK-C。
  - 每項成果責任由維護者承擔。
- Team：E1 的 Product Team。
- Project：建立時以本 Brief 作為描述的權威內容，回填實際 URL。
- 首批工作：下節 TASK-A 至 TASK-D。
- 日期：依成果安排，暫不設交付日期。
- 下一步：確認環境替換項目，將 TASK-A 的契約工作交給第一個執行 session。

### 待確認

- 跨裝置同步是否值得納入後續版本。
  - 來源：本文第一版排除範圍。
  - 影響：新增帳號與遠端資料儲存的規畫。
  - 確認方式：維護者收集實際跨裝置使用情境。
  - 決策時點：規畫下一版前。
  - 可先進行：本案例全部首批工作。

## Milestones

- M1：待辦資料可可靠保存。
  - 所屬 issues
    - TASK-A。
    - TASK-B。
  - 選擇理由：共用契約與儲存能力形成可供介面整合的成果。
  - [ ] 儲存能力通過資料與錯誤情境驗收。
  - [ ] TASK-C 與 TASK-D 可由契約找到使用方式。
- M2：使用者可完成待辦流程。
  - 所屬 issues
    - TASK-C。
    - TASK-D。
  - 選擇理由：介面與整合共同交付 Project 的使用者成果。
  - [ ] 實際組裝版本通過 Brief 全部成功標準。

M2 的介面工作可在 M1 尚未完成時使用已確認契約先行開發。
Milestone 的結果仍按各自驗收判斷。

## 首批 Issues

所有項目共用 E1 的 repository 與既有測試工具。
接手時依序讀取：

1. 本 Brief。
2. 所屬 issue 最新內文。
3. 前置成果的固定版本。

每項以一個 session 交付下列成果與驗證為目標。
發現範圍無法完整驗收時，依[超出 session 的處理](issue-decomposition.md#超出-session-時的處理)保存成果並重新拆分。

### TASK-A：提供可供儲存與介面共用的待辦契約

- Milestone：M1。
- 執行者：Agent A。
- 輸入：本 Brief 與 R1 的需求決策。
- 前置：環境盤點完成且 repository 可用。
- 交付：`docs/task-contract.md`。
- 範圍
  - 定義資料欄位
    - 穩定識別碼。
    - 文字。
    - 完成狀態。
    - 新增順序。
  - 定義操作介面
    - 新增。
    - 切換完成狀態。
    - 讀取清單。
  - 定義空白文字的拒絕規則。
  - 定義錯誤回應
    - 寫入失敗。
    - 讀取失敗。
    - 資料損壞。
- 獨立成項理由：TASK-B 與 TASK-C 都需要相同的資料與錯誤語意才能分別驗收。
- 驗收
  - [ ] 契約包含完整資料範例。
  - [ ] 每個操作都有輸入規格。
  - [ ] 每個操作都有輸出規格。
  - [ ] 新增順序有可核對範例。
  - [ ] 狀態切換有可核對範例。
  - [ ] 空白文字有明確回應。
  - [ ] 寫入失敗有明確回應。
  - [ ] 讀取失敗的回應禁止後續覆寫原資料。
  - [ ] 損壞資料的回應禁止後續覆寫原資料。
  - [ ] 維護者確認契約可同時用於儲存實作與介面模擬資料。

### TASK-B：實作可驗證的本機待辦儲存

- Milestone：M1。
- 執行者：Agent A。
- 輸入：TASK-A 已確認的契約版本。
- Blocked by：TASK-A。
- 交付
  - `src/tasks/` 的儲存能力。
  - `tests/tasks/` 的行為驗證。
- 範圍
  - 依契約讀寫待辦資料。
  - 驗證新增與完成狀態保存。
  - 驗證失敗時不覆寫既有資料。
- 獨立成項理由：儲存行為可透過契約直接驗證，並提供 TASK-D 的整合輸入。
- 驗收
  - [ ] 新增兩筆後，以新的儲存實例讀取仍保留文字與順序。
  - [ ] 標為完成後可讀回完成狀態。
  - [ ] 取消完成後可讀回未完成狀態。
  - [ ] 空白文字不產生新項目。
  - [ ] 注入寫入失敗時，回傳契約錯誤並保留原資料。
  - [ ] 注入讀取失敗時，原始資料保持完整。
  - [ ] 注入損壞資料時，原始資料保持完整。

### TASK-C：提供符合契約的待辦介面

- Milestone：M2。
- 執行者：Agent B。
- 輸入：TASK-A 已確認的契約版本。
- Blocked by：TASK-A。
- 交付
  - `src/ui/` 的待辦介面。
  - `tests/ui/` 的模擬回應驗證。
- 範圍
  - 顯示清單並接受新增操作。
  - 提供完成狀態切換。
  - 使用契約模擬成功與失敗回應。
- 獨立成項理由：介面互動可用模擬回應驗收，不需要等待儲存實作。
- 驗收
  - [ ] 空清單有可理解的提示。
  - [ ] 輸入框有可識別名稱。
  - [ ] 操作控制項有可識別名稱。
  - [ ] 新增送出契約要求的操作。
  - [ ] 狀態切換送出契約要求的操作。
  - [ ] 鍵盤可完成新增。
  - [ ] 鍵盤可切換狀態。
  - [ ] 新增寫入失敗時保留文字供重試。
  - [ ] 狀態切換失敗時保留原完成狀態供重試。
  - [ ] 寫入失敗時顯示錯誤。
  - [ ] 讀取失敗時顯示錯誤並停用寫入操作。
  - [ ] 資料損壞時顯示錯誤並停用寫入操作。

### TASK-D：整合並驗證可持續使用的待辦流程

- Milestone：M2。
- 執行者：Agent A。
- 輸入
  - TASK-B 通過驗收的儲存版本。
  - TASK-C 通過驗收的介面版本。
- Blocked by
  - TASK-B：提供真實儲存能力。
  - TASK-C：提供可組裝介面。
- 交付
  - `src/app/` 的組裝入口。
  - `tests/integration/` 的完整流程驗證。
  - `docs/acceptance.md` 的整體驗收紀錄。
- 獨立成項理由：模擬介面與儲存各自通過，仍需確認組裝後符合使用者成果。
- 驗收
  - [ ] 實際組裝版本通過 Brief 全部成功標準。
    1. 記錄整合版本。
    2. 記錄使用的瀏覽器。
    3. 逐項執行 Brief 成功標準中的操作。
    4. 將結果逐項寫入 `docs/acceptance.md`。
  - [ ] 錯誤回應經實際儲存介面傳到畫面，行為符合 TASK-C 的錯誤驗收。
  - [ ] 從 Project 成果入口可定位整合版本與驗收紀錄。

## 相依與執行順序

- 相依圖：`TASK-A → {TASK-B, TASK-C} → TASK-D`。
- TASK-A 可用條件：契約驗收完成，且成果固定版本可存取。
- TASK-B 與 TASK-C 可並行條件
  - 兩者使用同一契約版本。
  - 各自限定在儲存與介面路徑。
  - 執行與審閱容量足夠。
- TASK-D 可用條件：TASK-B 與 TASK-C 的成果均通過驗收。
- 共用設定檔需要變更時，先安排單一寫入者。
  - 修改衝突依寫入範圍協調。
  - 若變更影響契約，先修訂受影響的輸入與驗收。
- 示範 WIP
  - 每個 Agent 同時一項執行工作。
  - 最多一項正在審閱的交付。
  - 等待審閱與返工仍計入原執行者 WIP。

1. 第一個 session 執行 TASK-A。
2. 維護者確認契約後，分別承接 TASK-B 與 TASK-C。
3. 交付同時抵達時，先完成一項審閱，另一項保持待審並占用 WIP。
4. 讀取兩項成果與狀態，確認 TASK-D 輸入齊備後再承接。
5. TASK-D 通過後，核對 M1 驗收。
6. 核對 M2 驗收。
7. 核對 Project 成功標準。

## 轉用時替換的設定

- 環境
  - 實際 Workspace。
  - 實際 Team。
  - 必要權限。
  - 已有 Project 的搜尋結果。
  - 已有 issues 的搜尋結果。
  - Issue workflow 的實際名稱與狀態類別。
- 工作位置
  - Repository URL。
  - 可識別版本。
  - 真實原始碼路徑。
  - 測試指令。
  - 實際支援瀏覽器。
  - 儲存限制。
- 角色與政策
  - Project lead。
  - 需求決策者。
  - 驗收者。
  - 各 issue 的 assignee。
  - 各 Agent 執行範圍。
  - 遠端操作授權。
  - 成果發布方式。
  - WIP。
  - 審閱容量。
  - Cycle 是否啟用及既有設定。
- 需求與追蹤
  - R1 改為真實需求證據。
  - E1 改為實際盤點紀錄。
  - 確認首版範圍及未知需求的決策時點。
  - TASK 代號改為建立後的原生 issue mention。
  - M1 改為實際 milestone。
  - M2 改為實際 milestone。
  - Project 回填可存取連結。
  - 前置成果回填可存取連結。
  - 驗收紀錄回填可存取連結。

## 功能依據

查證日期：2026-09-13。
證據方式：查閱 Linear 官方文件。
本文的物件取捨與容量安排屬使用建議。

- Issue 同時只能屬於一個 Project。
  - 來源：[Projects — Add issues to a project](https://linear.app/docs/projects#add-issues-to-a-project)。
- Milestone 日期可選填。
  - 來源：[Project milestones — Create milestones](https://linear.app/docs/project-milestones#create-milestones)。
- 多個 milestones 可並行。
  - 來源：[Project milestones — FAQ](https://linear.app/docs/project-milestones#faq)。
- `Blocked by` 表達本項等待前置 issue。
  - 來源：[Issue relations — Blocked / blocking](https://linear.app/docs/issue-relations#blocked-blocking)。
