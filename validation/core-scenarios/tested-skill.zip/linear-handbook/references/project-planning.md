# 從需求建立 Project

適用情境：個人開發者＋多個 Agent。
查證日期：2026-09-13。

- 填寫入口：[Project brief](../assets/templates/project-brief.md)。
- 建模依據：[物件關係與功能選擇](object-model.md)。
- 工作分類：[工作類型與 parent issue 選擇](issue-types.md)。

## 功能事實

- 可從 Workspace 或 Team 的 Projects 頁面按 `+` 建立 Project。[P1](https://linear.app/docs/projects#create-a-project)
- 建立時唯一必填欄位是名稱。[P1](https://linear.app/docs/projects#create-a-project)
- Project lead 欄位只容納一位成員。[P1](https://linear.app/docs/projects#faq)
- Project 可跨 Teams。[P1](https://linear.app/docs/projects#multi-team-projects)
- Issue 同時只能屬於一個 Project。[P1](https://linear.app/docs/projects#add-issues-to-a-project)
- Project 可以不設完成日期。[P1](https://linear.app/docs/projects#faq)
- Overview 可編輯詳細描述。[P2](https://linear.app/docs/project-overview#detailed-description)
- Resources 可新增外部連結。[P2](https://linear.app/docs/project-overview#external-links)
- Resources 可建立 Project document。[P2](https://linear.app/docs/project-overview#project-documents)
- 將 parent 轉為 Project 會改變原有結構。[P3](https://linear.app/docs/parent-and-sub-issues#turn-issues-into-projects)
  - 原 parent 會重新命名。
  - 原 parent 與子項成為獨立 issues。
  - 原親子關係會移除。

## 規畫流程

以下是 handbook 建議。
平台允許建立 Project 的條件，比能交接執行的規畫條件少。

### 1. 整理需求輸入

- 輸入
  - 需求提出者的原始說法。
  - 目前使用情境的證據。
  - 既有成果入口。
- 操作
  1. 寫出誰在什麼情境遇到什麼問題。
  2. 連到可定位的需求依據。
  3. 將提案與已採用需求分開。
  4. 中途導入時盤點既有工作，依下節處理。
- 完成條件
  - [ ] 下一位讀者能理解問題及其依據。
  - [ ] 假設保留待確認狀態。

### 2. 定義成果與邊界

- 輸入
  - 問題描述。
  - 已確認需求。
  - 已知限制。
- 操作
  1. 以使用者可完成的任務寫出預期成果。
  2. 列本次交付範圍。
  3. 列容易被誤認為包含在內的排除範圍。
  4. 將每項限制連到依據。
  5. 逐項定義成功標準及驗證方法。
- 完成條件
  - [ ] 每項交付有可判定的完成結果。
  - [ ] 門檻屬於已確認需求，或明確標為待決提案。

### 3. 選擇工作容器

- 輸入
  - 成果與成功標準。
  - 需要協調的工作範圍。
- 操作
  1. 單一成果可直接交付時，使用 Issue。
  2. 局部成果需要分開交接時，使用 parent 與 sub-issues。
  3. 需要共同 brief 與持續專案進度管理時，選擇 Project。
  4. 搜尋既有 Project，確認是否已有相同成果入口。
  5. 逐項記錄 repository 的工作位置。
- 完成條件
  - [ ] 容器選擇有協調需求作為理由。
  - [ ] 沒有因 Agent 或 repository 的數量直接增加 Project。

### 4. 指定角色與處理不確定性

- 輸入
  - Brief 草稿。
  - 仍需回答的問題。
- 操作
  1. 指定 Project lead 維護整體範圍。
  2. 指定需求決策者。
  3. 指定驗收者。
  4. 對每項未決需求記錄影響。
  5. 指定取得答案的責任與方法。
  6. 設定必須決策的時點。
  7. 先安排不依賴答案的工作。
  8. 指明每個 Agent 在該工作內的執行範圍。
- 完成條件
  - [ ] 每項未決需求有確認途徑。
  - [ ] 需要等待答案的工作可識別。
  - [ ] 首批可執行工作沒有把假設當成承諾。

### 5. 建立或更新 Project

- 輸入
  - 可執行的 Brief。
  - 已選定的 Workspace 與 Team。
  - 既有 Project 搜尋結果。
- 操作
  1. 若已有對應 Project，更新該入口。
  2. 若需新建，在 Projects 頁面按 `+` 並填寫成果名稱。[P1](https://linear.app/docs/projects#create-a-project)
  3. 設定實際承接 Team。
  4. 設定已確認的 lead。
  5. 依環境的實際狀態選項記錄進度。
  6. 日期尚未確認時，在 Brief 保留問題及確認方式。
  7. 在 Overview 詳細描述放入 Brief，或連到作為權威版本的文件。[P2](https://linear.app/docs/project-overview#detailed-description)
  8. 將工作資源逐項加入 Resources。[P2](https://linear.app/docs/project-overview#external-links)
  9. 讀回內容並核對必要連結的存取。
- 完成條件
  - [ ] Project 的成果範圍與 Brief 一致。
  - [ ] 權威文件入口可辨識。
  - [ ] 執行者可找到必要資源。

### 6. 交接首批工作

- 輸入
  - Project 入口。
  - 已確認交付。
  - 未決問題的影響。
- 操作
  1. 依可獨立驗收的成果列首批工作。
  2. 每項記錄交付與驗收。
  3. 每項列出必要前置。
  4. 將既有 issues 連回 Brief。
  5. 建立缺少的工作後回填入口。
  6. 寫出下一位接手者可立即執行的操作。
  7. 已確認需求變更時，同步修訂受影響工作的驗收。
- 完成條件
  - [ ] 首批工作可由下一個 session 接續。
  - [ ] 整體成功標準仍留在 Project 層級。

## 中途導入

1. 記錄盤點日期與版本。
2. 以成果證據確認已完成範圍。
3. 列出仍在執行的 issues。
4. 比對需求文件與目前行為。
5. 對矛盾或缺少依據的敘述建立待確認項目。
6. 優先更新既有 issue，保留原始追蹤入口。
7. 改變 Project 歸屬前確認原 Project 的交付責任。
8. 共用成果已有主要 Project 時，從 Brief 引用該成果。
9. 若需獨立採用或驗收，建立具有不同交付的工作。
10. 讀回更新後的關係與狀態。

若考慮將 parent 轉為 Project，先保存整體驗收與親子清單。
轉換後按 [P3](https://linear.app/docs/parent-and-sub-issues#turn-issues-into-projects) 的結構變化逐項核對。
需要保留局部親子結構時，可建立 Project 再加入既有 issues。

## 案例一：從零建立 CSV 匯出

以下為假設案例，需求與門檻供示範填寫方式。

- 輸入
  - 模擬訪談紀錄：使用者每週手動抄寫工時。
  - 已採用需求：將指定日期範圍的工時匯出為 CSV。
- 問題：手動抄寫容易遺漏紀錄。
- 成果：使用者能取得可核對的工時 CSV。
- 本次範圍
  - 日期範圍選擇。
  - CSV 下載。
- 排除範圍
  - 排程寄送。
- 限制：沿用既有工時資料格式。
- 工作位置
  - 示範 repository：`time-log`。
    - `app/`：匯出介面。
    - `api/`：資料查詢與 CSV 產生。
- 角色
  - Project lead：產品維護者。
  - 需求決策者：產品維護者。
  - 驗收者：產品維護者。
  - API 執行者：Agent A。
  - 介面執行者：Agent B。
- 待確認：是否需要自訂欄位。
  - 狀態：待確認。
  - 影響：自訂欄位介面需等待答案。
  - 確認方式：由維護者取得需求提出者的使用範例。
  - 決策時點：規畫自訂欄位工作前。
  - 可先進行：固定欄位匯出。
- 成功標準
  - [ ] 固定欄位 CSV 與指定日期內的工時紀錄一致。
    1. 準備跨日期範圍的已知紀錄。
    2. 匯出其中一段日期。
    3. 核對筆數與各筆欄位值。
- 建模：建立「提供工時 CSV 匯出」Project。
  - 理由：共同 Brief 協調 API 與介面的交付。
- 首批工作
  - 產生固定欄位 CSV。
    - 驗收：已知資料與輸出逐筆一致。
  - 提供下載介面。
    - 前置：CSV API 契約。
    - 驗收：使用者取得指定範圍的檔案。
  - 驗證完整匯出流程。
    - 前置：可用的 API 與介面。
    - 驗收：通過 Project 成功標準。
- 下一步：先定義 CSV API 契約，供兩個執行工作使用。

## 案例二：中途導入通知偏好

以下為假設案例，現況證據代號代表接手時需要取得的入口。

- 盤點基準：目前測試版本 `v0.4`。
- 輸入
  - 成果 A：通知寄送 API 的驗證報告。
  - 工作 B：正在開發的偏好設定介面 issue。
  - 提案 C：聊天紀錄中的 SMS 建議。
- 問題：使用者無法自行停止每週摘要信。
- 成果：使用者可儲存偏好並控制後續摘要信。
- 本次範圍
  - Email 摘要開關。
  - 寄送端遵守偏好。
- 限制：沿用目前 Email 供應商。
- 工作位置
  - 示範 repository：`notifications`。
    - `settings/`：偏好介面。
    - `mailer/`：寄送判斷。
- 既有工作處理
  - 成果 A：列為已完成的基礎能力並保留報告入口。
  - 工作 B：沿用原 issue 並補入成功標準。
  - 提案 C：保留為待確認需求。
- 角色
  - Project lead：產品維護者。
  - 需求決策者：產品維護者。
  - 驗收者：產品維護者。
  - 介面執行者：原工作 B 的執行者。
  - 寄送判斷執行者：Agent C。
- 待確認：是否納入 SMS。
  - 狀態：待確認。
  - 影響：SMS 供應商選擇與實作需等待答案。
  - 確認方式：維護者請需求提出者確認使用情境。
  - 決策時點：新增 SMS 工作前。
  - 可先進行：Email 偏好功能。
- 成功標準
  - [ ] 關閉摘要後的下一次排程不寄送摘要信。
    1. 儲存關閉偏好。
    2. 執行測試排程。
    3. 以寄送紀錄核對未產生摘要郵件。
  - [ ] 重新開啟後的下一次排程恢復摘要信。
- 建模：搜尋後沿用「提供通知偏好」Project。
- 首批工作
  - 完成工作 B 的偏好儲存介面。
    - 驗收：重新載入後保留偏好值。
  - 補入寄送端偏好判斷。
    - 前置：偏好資料契約。
    - 驗收：關閉偏好時跳過寄送。
  - 驗證下一次排程行為。
    - 前置：可用的介面與寄送判斷。
    - 驗收：通過兩項 Project 成功標準。
- 下一步：核對工作 B 採用的偏好資料契約，再補入寄送端工作。

## 採用配置

下列項目由採用者依自己的授權與工作習慣設定。

- 決定 lead 是否兼任需求決策者。
- 決定驗收者是否由同一人兼任。
- 指定可執行遠端變更的授權範圍。

## 來源記錄

發布者均為 Linear。
查證日期：2026-09-13。
證據狀態：文件已確認。
適用範圍：下列章節的產品功能說明。

- P1：[Projects](https://linear.app/docs/projects)
  - `Create a project`：建立入口與必填名稱。
  - `Add issues to a project`：Issue 的單一 Project 歸屬。
  - `Multi-team projects`：跨 Team Project。
  - `FAQ`：單一 lead 與完成日期選填。
- P2：[Project overview](https://linear.app/docs/project-overview)
  - `Detailed description`：詳細描述的編輯能力。
  - `External links`：Resources 連結。
  - `Project documents`：建立文件。
- P3：[Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues)
  - `Turn issues into projects`：parent 轉換的結構變化。
