# 團隊協作與產品營運的擴充邊界

查證日期：2026-09-12。
適用情境：個人開發者＋多個 Agent，逐步擴充到小型團隊及上線產品。
證據原則：[policy](policy.md#證據與來源)。
物件關係：[object-model.md](object-model.md)。
功能矩陣：[feature-coverage.md](feature-coverage.md)。

## 採用方式

組織規模與營運需求分別判斷。
個人產品上線後即可採用回饋、發布、incident 與維護模組。
加入同事時再分配責任與調整協作政策。
這是本 handbook 的設計建議，承接研究範圍的「後續擴充邊界」。

1. 先以核心規則管理每項工作，確認成果、責任與驗收證據。
2. 依觸發表選擇需要的協作或營運能力。
3. 由環境政策提供實際 Team、狀態、權限、工具與責任人對應。
4. 用一項代表工作驗證配置與交接，再擴大採用。

下文「建議」表達流程設計。
「文件事實」限於來源明示的產品行為。
格式與目前結論維護預設見 [writing](writing.md)。
使用者明確指定的適用政策優先。

## 四類責任

- 核心規則
  - 界定交付成果與完成條件。
  - 按成果拆分工作。
  - 判斷真正相依。
  - 維護目前採用結論。
  - 保存可用證據與交接入口。
  - Handbook 維護者負責共通規則。
  - 工作負責人維護該項事實。
- 角色
  - 指定需求決策者。
  - 指定執行者。
  - 指定審查者。
  - 指定驗收者。
  - 啟用營運時指定發布與事故責任。
  - 由產品或專案負責人分配具名責任。
- Workspace 政策
  - 將共通概念對應到實際環境。
  - 保存物件識別資料。
  - 保存狀態與分類映射。
  - 記錄實際權限。
  - 記錄排程與整合設定。
  - 由設定維護者維護有效版本。
- 營運模組
  - 客戶回饋提供受理流程。
  - 發布流程保存環境交付證據。
  - Incident 流程處理服務恢復。
  - 可靠性與週期維護提供持續檢查。
  - 每個啟用模組有具名維護者。

核心使用工作階段的語意，政策提供實際 status ID。
本版以單一入口按需載入各項 reference。

## 角色與交接

以下是流程責任，同一人可兼任多個角色。
責任名稱不代表 Linear 原生權限類型。

- 需求與優先順序
  - 個人階段由開發者作出需求取捨。
  - 團隊階段指定產品或專案決策者。
  - 交接保留採用決策。
  - 交接保留取捨理由。
  - 交接保留完成條件。
- Issue 責任與執行
  - Assignee 承擔成果責任。
  - Agent 執行已授權範圍。
  - 交接保留執行範圍。
  - 交接保留目前結論。
  - 交接保留成果入口。
  - 實際阻塞保留解除條件。
- 審查與驗收
  - 作者提供自查證據。
  - 需要獨立審查時，依政策安排審查者。
  - 指定接受成果的人。
  - 交接保留驗證方法。
  - 交接保留結果。
  - 交接保留影響驗收的問題。
- 設定維護
  - 指定維護者並確認其管理權限。
  - 記錄設定生效範圍。
  - 記錄修改前後差異。
  - 指出受影響工作。
- 發布與營運
  - 指定當次發布負責人。
  - 指定事故負責人。
  - 需要接續處理時另列備援。
  - 交接保留目標環境。
  - 交接保留事件影響。
  - 交接保留恢復證據。
  - 交接保留後續工作入口。
  - 需發送訊息時保留已授權目的地。

文件事實：Issue 同時有一名 Assignee。[E03](https://linear.app/docs/assigning-issues#overview)
原生 delegation 保留人類責任，Agent 需有該 Team 的存取權。[E03](https://linear.app/docs/assigning-issues#delegating-to-agents)
外部 MCP session 是否對應原生 Agent 身分，依當前能力確認。

文件事實：[Members and roles](https://linear.app/docs/members-roles#role-types) 說明角色與方案。

- Free 成員均為 Admin。
- Team owner 限 Business／Enterprise。
- Guest 限 Business／Enterprise。
- Team owner 可限制部分設定管理權限。

流程中的審查責任不能代替平台存取控制。

## 擴充觸發與設定

下表為建議。
觸發以實際需求判斷，不設人數或 issue 數量門檻。

- 另一位成員開始共同交付
  - 設定或政策變動
    - 指定責任
      - Assignee。
      - 審查者。
      - 需求決策者。
    - 補交接入口與通知責任。
  - 採用時驗證：接手者能讀成果並判斷下一個動作

- 經常需要共同安排固定工作區間
  - 設定或政策變動
    - 定義排程節奏與容量檢視。
    - 有需求再啟用 Team Cycles。
  - 採用時驗證
    - 試行一個區間，確認未完成工作的下一步與發布安排分開記錄。
    - Cycles 不綁定 Releases。
    - [E08](https://linear.app/docs/use-cycles)。

- 工作領域有不同 workflow、排程或存取需求
  - 設定或政策變動
    - 評估新增 Team。
    - 建立環境映射
      - Status。
      - Label。
      - Template。
      - 成員。
      - Agent access。
      - 整合設定。
  - 採用時驗證
    - 以代表 issue 核對
      - 目標設定。
      - 關聯。
      - 成員可見性。
    - 再分批調整。

- 跨領域工作需要共同成果與持續協調
  - 設定或政策變動
    - 維持一份 Project brief，加入參與 Teams。
    - 各 issue 指定主要歸屬。
  - 採用時驗證
    - 確認物件歸屬
      - 每項 issue 有一個 Team。
      - 每項 issue 至多有一個 Project。
    - 共用成果有引用及各方驗收。
    - [E01](https://linear.app/docs/teams#tips-on-structuring-teams)。
    - [E09](https://linear.app/docs/projects#add-issues-to-a-project)。

- 客戶回饋或整合持續送入需求
  - 設定或政策變動
    - 啟用回饋模組。
    - 定義受理配置
      - 受理者。
      - 查重入口。
      - 處理期限。
    - 依需求選用
      - Triage。
      - Customer Requests。
  - 採用時驗證
    - 代表來源的驗證
      - 可進入待受理清單。
      - 原始來源可定位。
      - 處理決策可追溯。
      - 負責人明確。
    - template 可能覆寫預設 Triage status，需納入檢查。
    - [E04](https://linear.app/docs/triage#create-issues)。

- 使用者開始依賴正式環境
  - 設定或政策變動
    - 啟用發布與 incident 模組。
    - 補齊發布配置
      - 目標環境。
      - 發布責任。
      - 恢復入口。
      - 通知政策。
  - 採用時驗證
    - 一次發布可追到部署與驗證證據。
    - 一次事故演練可找到處理人及後續改善。

- 備份恢復、依賴更新或可靠性檢查形成固定節奏
  - 設定或政策變動
    - 啟用維護模組。
    - 設定維護工作
      - Cadence。
      - Team 時區。
      - 每期完成條件。
      - 維護者。
  - 採用時驗證
    - 檢查前次未完與新一期工作。
    - 原生 recurrence 依到期時間產生，更新 template 不會同步既有 recurrence。
    - [E07](https://linear.app/docs/creating-issues#create-recurring-issues)。

- 外部協作者只需部分工作資訊
  - 設定或政策變動
    - 確認外部協作邊界
      - Guest／Team access。
      - 可分享成果。
      - 整合可見性。
    - 指定內部接洽人。
  - 採用時驗證
    - 以實際協作者角色確認可讀性
      - Issue。
      - 附件。
      - 必要來源。
    - Customer Requests 不可作為 Guest 的唯一工作入口。
    - [E02](https://linear.app/docs/members-roles#guest)。
    - [E05](https://linear.app/docs/customer-requests#faq)。

- 出現正式稽核、組織級權限或合規要求
  - 設定或政策變動：將需求與未解問題記入企業治理範圍，另立可驗收研究
  - 採用時驗證：明確需求責任人與判斷依據，見企業治理表


Team 可分別配置 workflow。
Project 可跨 Teams，Issue 只屬於一個 Team。[E01](https://linear.app/docs/teams#tips-on-structuring-teams)
新增 Team 前還需確認方案額度。
個人新增 Agent 或產品上線本身不構成分 Team 的理由。
此選擇沿用 [object-model.md 的功能選擇表](object-model.md#功能選擇表)。

## 營運模組

依產品需要選擇啟用模組。
詳細操作見 [maintenance](maintenance.md#發布與事故管理)。

- 客戶回饋
  - 輸入：可定位來源。
  - 輸入：問題情境。
  - 輸入：實際影響。
  - 受理者決定查重與補件。
  - 需求決策者決定優先順序。
  - 產出採用、拒絕或待補資訊的決策。
  - 產出對應 issue 入口。
  - 需要回覆時確認接收者與授權。
  - Customer Requests 的方案與整合分開確認。[E05](https://linear.app/docs/customer-requests#configure)
- 發布
  - 輸入：已驗證的變更。
  - 輸入：目標環境。
  - 輸入：可識別版本。
  - 指定發布責任人。
  - 保存部署紀錄。
  - 保存環境驗證。
  - 保存恢復方式。
  - 提供所需 release notes。
  - 原生 Releases 限 Business／Enterprise。[E06](https://linear.app/docs/releases#ci-setup)
  - CI setup 使用 pipeline access key。[E06](https://linear.app/docs/releases#ci-setup)
  - 可先以 issue 連到外部 CI/CD 證據。
- Incident
  - 輸入：告警或回報。
  - 輸入：受影響服務。
  - 輸入：開始時間。
  - 指定處理人。
  - 保存影響與處理時間線。
  - 保存恢復證據。
  - 記錄原因證據或待查問題。
  - 後續改善各有責任與驗收。
  - 偵測與即時告警由既有營運工具承擔。
  - 恢復操作依適用 runbook。
  - Triage responsibility 可另行設定輪值來源。[E04](https://linear.app/docs/triage#triage-responsibility)
- 可靠性與維護
  - 輸入：固定檢查或事故改善。
  - 指定維護者與檢查範圍。
  - 保存每期結果。
  - 保存異常處置。
  - 連到改善 issue。
  - 指明下一次檢查。
  - 使用服務目標時，記錄指標來源。
  - 記錄量測區間。
  - 記錄判定閾值。
  - 可選 recurring issues。[E07](https://linear.app/docs/creating-issues#create-recurring-issues)

同一人兼任時，仍分別保存實作、部署與接受成果的證據。
Releases 官方區分 Done 與真正交付使用者。[E06](https://linear.app/docs/releases#overview)
停用模組前指定未完工作的承接者。
同步更新事件入口與排程，避免工作送往無人處理的位置。

## 遷移案例：個人產品上線後加入兩位協作者

此為設計案例，驗收方式是逐步比對責任、物件限制及成果入口。
範例政策值由案例自行設定。

### 起點與目標

- 起點：一位開發者與多個 Agent，在一個 Team 管理同一產品的前端與 API repos。
- 變化：產品開始有正式用戶。
- 之後加入一位開發者及一位支援協作者。
- 目標：每項回饋有人受理，每次發布可追到正式環境證據，每項工作可以由另一人接手。
- 假設：三位協作者均有同一 Team 的必要存取權，共用 workflow。
- 無需依賴新增 Team 或付費營運功能。

### 遷移步驟

1. 個人先補產品的回饋入口、發布環境、部署／監控／runbook 連結及責任人。
   以一般 issue 人工記錄回饋來源、發布證據及 incident 後續工作，先讓營運流程可用。
2. 用「正式環境可完成訂閱」作為代表成果。
   由既有 Project 的前端及 API issues 提供功能驗證，另設發布工作記錄版本、正式環境驗證與恢復入口。
Project brief 連結相關成果。
3. 同事加入後，將每項 issue 的 Assignee、當次審查者及發布負責人明確分配。
   支援協作者負責回饋查重與初步受理，產品負責人決定取捨。
Agent 執行範圍及交接證據寫在工作中。
4. 以「訂閱按鈕失效」回饋走一次受理流程。
   記錄來源與影響，連至既有修正工作，確認接手人讀得到成果。
修正後附正式環境驗證，按已授權範圍回覆。
5. 因三人共用 workflow，沿用既有 Team。
   需要固定排程時再評估 Cycle。
回饋量增加時再盤點 Triage 與 Customer Requests
需要發布環境視圖時再評估 Releases。
6. 若之後支援工作需要獨立狀態或存取邊界，再評估分 Team。
   先列現有映射與受影響物件，用一項代表 issue 驗證目標狀態、關係、可見性及整合，再調整其他工作。
   試行失敗時停止擴大，依保存的設定與工作對照修復，確認原流程仍有人接手。

### 紙上驗收

- [x] 個人階段已能採用四個營運模組。
- 步驟一提供入口及責任，無人數門檻。
- [x] 三人協作的責任有明確對應。
- Assignee 與 Agent 執行責任符合 E03。
- [x] 前端及 API issues 各只有一個 Team 與至多一個 Project。
- 沿用 E01／E09 的物件限制。
- [x] 步驟二、四以正式環境證據判斷發布成果。
- Cycle 或 Done 均未充當部署證據。
- [x] 付費功能採用前有確認點。
- 新增 Team 由不同流程或存取需求觸發。
- [x] 試行範圍、擴大條件與失敗處理已列出，接手者可追到目前成果。

## 企業治理

此處只界定後續研究範圍與未解問題。

| 範圍 | 待解問題 |
| --- | --- |
| 多 Team／多 Workspace 治理 | 組織邊界、共享成果、資料歸屬與跨環境整合由誰決定？如何避免重複來源？ |
| 身分與存取 | 是否需要集中身分管理、離職處理、最小權限與定期權限審查？各功能及整合實際暴露哪些資料？ |
| 稽核與保存 | 需保留哪些操作與決策，保存多久，誰可查閱，如何驗證完整性？ |
| 變更核准與責任分離 | 哪些操作需要獨立審查或核准？哪些角色不可兼任？緊急變更如何追認？ |
| 合規與資料處理 | 適用義務、敏感資料分類、保存位置與外部處理者要求為何？由誰作出判定？ |

## 採用前待確認

- 目標 Workspace 的方案、角色與設定
  - 影響與確認方式
    - 確認受影響功能
      - 新增 Team。
      - Guest。
      - 進階 Triage。
      - Releases。
    - 盤點實際方案與設定後才選原生功能。

- 外部 Agent 的身分及操作能力
  - 影響與確認方式
    - 原生 delegation 需 Team access。
    - 在 agent-tool-capabilities 比對目前 connector 與實際帳號，再以代表工作回讀欄位。

- 發布整合的觸發點
  - 影響與確認方式
    - E06 的 continuous 範例可在 push main 建立完成的 release。
    - 若部署流程在後續才執行，該事件不足以證明上線。
    - 需將正式環境部署成功及驗證證據納入實際 workflow。

- Guest 的回饋交接與整合可見性
  - 影響與確認方式
    - E05 FAQ 已明確說明 Guest 看不到 Customer Requests，與 E02 一致。
    - 替 Guest 提供允許存取的 issue 與成果入口，並確認外部整合權限。

- recurring issue 前一期未完時的處理
  - 影響與確認方式
    - E07 支持時間觸發，無法據此保證不重疊。
    - 先檢查代表 recurrence 的到期與未完行為，再訂承接方式。

- 分 Team 或跨角色後的實際資料映射
  - 影響與確認方式
    - 文件事實不涵蓋此 Workspace 的客製設定。
    - 擴大前以樣本逐項驗證
      - Status。
      - Labels。
      - Templates。
      - 關聯。
      - 可見性。
      - 整合。


以上是配置時需要的確認點。
本文件交付為研究與設計，功能證據層級為官方文件查閱。

## 來源記錄

以下九個來源發布者均為 Linear，查證日期均為 2026-09-12。
頁面級發布／更新日期未確認。
證據狀態為「文件已確認」。
章節提供頁內搜尋定位，功能限制與採用前確認點分列於上文。

- E01
  - 標題與 URL：[Teams](https://linear.app/docs/teams)
  - 章節／支持結論
    - Overview。
    - Team settings。
    - Team limits。
    - Tips on structuring teams。
    - Team 選擇與作用域。
  - 適用限制：Team 額度及修改權限由實際方案與政策確認

- E02
  - 標題與 URL：[Members and roles](https://linear.app/docs/members-roles)
  - 章節／支持結論
    - Role types。
    - Admin。
    - Team owner。
    - Guest。
    - 支持結論
      - 角色。
      - 權限。
      - Guest 存取。
  - 適用限制
    - 流程責任不等於平台角色。
    - 外部整合需個別確認。

- E03
  - 標題與 URL：[Assign and delegate issues](https://linear.app/docs/assigning-issues)
  - 章節／支持結論
    - Overview。
    - Delegating to agents。
    - 單一 Assignee 與 Agent access。
  - 適用限制：外部 MCP session 的身分映射另查

- E04
  - 標題與 URL：[Triage](https://linear.app/docs/triage)
  - 章節定位
    - Configure。
    - Create issues。
    - Automation。
    - Triage responsibility。
  - 適用限制
    - 進階三項功能限 Business／Enterprise。
    - template 可覆寫 status。

- E05
  - 標題與 URL：[Customer Requests](https://linear.app/docs/customer-requests)
  - 章節定位
    - Configure。
    - Add requests to issues or projects。
    - FAQ。
  - 適用限制
    - 本體與整合方案分開。
    - FAQ 明示 Guest 不可見。

- E06
  - 標題與 URL：[Releases](https://linear.app/docs/releases)
  - 章節定位
    - Overview。
    - Status automations。
    - CI setup。
    - Example for continuous deployments。
  - 適用限制
    - Business／Enterprise。
    - 完成事件需對照實際部署 workflow。

- E07
  - 標題與 URL：[Create issues](https://linear.app/docs/creating-issues)
  - 章節／支持結論：Create recurring issues
  - 適用限制
    - 時間觸發。
    - 原 template 與既有 recurrence 分開維護。

- E08
  - 標題與 URL：[Cycles](https://linear.app/docs/use-cycles)
  - 章節定位
    - 頁首。
    - Configure。
  - 適用限制
    - Team 啟用。
    - 排程與發布分開。

- E09
  - 標題與 URL：[Projects](https://linear.app/docs/projects)
  - 章節定位
    - Overview。
    - Add issues to a project。
  - 適用限制
    - Project 可跨 Team。
    - Issue 只有單一 Project 歸屬。


## Workspace 政策介面

配置欄位、未知值處理及權責依 [policy](policy.md)。
啟用營運模組後使用 [maintenance](maintenance.md) 的對應流程。
