# Workspace 初始化與接手

適用情境：個人開發者＋多個 Agent。
查證日期：2026-09-13。

以下清單與最小配置是使用建議。
功能事實依官方文件整理，來源定位見文末。
環境紀錄填入目標 Workspace 的實際值。

## 設定用途與最小配置

### Team

- 功能事實 [S1]
  - 建立 Workspace 時會產生同名 Team。
  - Team 包含 Issues。
  - Team 可以使用自己的 workflow。
- 用途
  - 確定 Issue 的工作歸屬。
- 採用時機
  - 開始追蹤 Issue 時選定 Team。
  - 需要獨立流程時評估新增 Team。
  - 需要不同存取範圍時評估新增 Team。
- 最小配置
  - 沿用預設 Team。
  - 保存 Team 的實際識別資料。
  - 多產品的建模方式見[物件關係](object-model.md)。

### Issue status

- 功能事實 [S2]
  - Workflow 依 Team 設定。
  - 預設狀態依序為：
    - Backlog
    - Todo
    - In Progress
    - Done
    - Canceled
  - 狀態名稱可以自訂。
  - 狀態類別的順序固定。
  - 每個類別至少保留一個狀態。
  - Duplicate 由系統在標記重複工作時管理。
- 用途
  - 表達目前工作階段。
- 採用時機
  - 執行前先對照狀態語意。
  - 審查需要獨立看板欄位時才增加狀態。
- 最小配置建議
  - 保留預設 workflow。
  - 沿用既有名稱及對應 ID。
  - 審查與驗收階段使用 started 類。
  - 通過完成條件才使用 completed 類。
  - 映射方式見[生命週期](issue-lifecycle.md#先映射既有狀態)。

### Priority

- 功能事實 [S3]
  - Priority 為選填。
  - 原生選項固定為：
    - No priority
    - Low
    - Medium
    - High
    - Urgent
  - 設為 Urgent 會通知 Assignee。
- 用途
  - 表達工作急迫性。
- 採用時機
  - 需要決定先處理哪些工作時使用。
- 最小配置建議
  - 尚無排序判斷時保留 No priority。
  - 沿用既有 Priority 政策。
  - 沒有政策時，先記錄各項工作的急迫原因，再決定等級。
  - 日期承諾另用 due date 表達。

### Estimate

- 功能事實 [S4]
  - Estimates 描述工作大小或複雜度。
  - 在 Team 層級啟用。
  - 量尺由 Team 選擇。
  - Project 的 effort 統計使用 Estimates。
  - Cycle 的 effort 統計使用 Estimates。
  - 0 與未估算不同。
  - 未估算預設計為 1 point，可在設定調整。
- 用途
  - 比較工作大小。
  - 協助安排容量。
- 採用時機
  - 能一致使用量尺，且定期檢視容量時啟用。
- 最小配置建議
  - 空白環境先保留未啟用。
  - 既有環境沿用量尺。
  - 估算值的意義由團隊約定。

### Labels

- 功能事實 [S5]
  - Label 可屬 Workspace。
  - Label 可限定特定 Team。
  - Label group 提供一層分組。
  - 同一 Issue 每組最多選一個 label。
- 用途
  - 分類工作。
  - 支持篩選或路由。
- 採用時機
  - 有反覆使用的分類需求時建立。
- 最小配置建議
  - 先沿用既有 labels。
  - 沒有分類需求可留空。
  - 所有 Team 共用的概念才放 Workspace 層。
  - 同名 label 以 scope 及 ID 判別。
  - 類型選擇見[Issue 工作類型](issue-types.md)。

### 權限與 Agent 身分

- 功能事實
  - Free 方案所有使用者都是 Admin。[S6]
  - Team owner 為 Business／Enterprise 功能。[S6]
  - Team owner 可限制 Team 設定的管理權限。[S6]
  - Guest 只存取被加入的 Teams。[S6]
  - Guest 為 Business／Enterprise 功能。[S6]
  - Private Teams 為 Business／Enterprise 功能。[S7]
  - 原生 delegation 可保留人類 Assignee。[S8]
  - 被委派的 Agent 必須具有目標 Team access。[S8]
- 用途
  - 確認可見範圍。
  - 確認誰能修改資料或設定。
- 採用時機
  - 接手環境時確認。
  - 加入成員時確認。
  - 連接 Agent 時確認。
- 最小配置建議
  - 保存設定管理者的聯絡入口。
  - 執行者取得本次工作所需權限。
  - 分別記錄人類責任人與 Agent 身分。
  - 憑證存放於既有祕密管理位置，環境紀錄只保留存取入口。
  - API／MCP 的權限判斷見[整合能力](agent-tool-capabilities.md#權限方案與身分)。

### 通知

- 功能事實 [S9]
  - 通知可在 Linear Inbox 查看。
  - 其他通道由帳號設定控制。
  - Issue subscription 決定追蹤的工作。
  - 實際通知依個人偏好發送。
  - Status changes 類別包含多種事件，不能只單獨選一般狀態變更。
- 用途
  - 提醒責任人處理需要注意的工作。
- 採用時機
  - 承接工作時確認 subscription。
  - 離開 Linear 仍需及時回應時設定外部通道。
- 最小配置建議
  - 固定檢視 Inbox。
  - 訂閱自己負責的 Issues。
  - 需要即時提醒時，由本人選擇會查看的通道。
  - Agent 接手時讀取 Issue 的目前內容，通知只作提示。

## 原生設定與工具操作

- 原生設定入口
  - Team 名稱：Team settings → General。[S1]
  - Team identifier：Team settings → General。[S1]
  - 時區：Team settings → General。[S1]
  - Status：Team settings → Issue statuses。[S2]
  - Estimates：Team settings → General → Estimates。[S4]
  - Labels：Workspace 或 Team settings → Labels。[S5]
  - 成員角色：Settings → Administration → Members。[S6]
  - Team 管理權限：Team settings → Access and permissions。[S6]
  - 通知：Settings → Account → Notifications。[S9]
- 操作者
  - 設定由具有權限的人或已授權 UI Agent 完成。
  - 個人通知偏好由帳號本人決定。
- 工具操作
  - 先查看當次工具宣告。
  - 查詢目標 Team。
  - 查詢該 Team 的 statuses。
  - 查詢可用 labels。
  - 將顯示名稱解析為實際 ID。
  - 在授權範圍內更新 Issue 欄位。
  - 讀回目標欄位，核對寫入結果。
- 缺少介面或權限
  - 記錄無法完成的具體操作。
  - 指向相應原生設定入口。
  - 交由具權限的操作者處理。
  - 取得結果後刷新映射。

工具能力的證據界線見[整合能力矩陣](agent-tool-capabilities.md#能力矩陣)。

## 空白環境初始化清單

依下列順序執行。

- [ ] Workspace 可定位。
  1. 在原生介面建立 Workspace。
  2. 確認方案。
  3. 保存 Workspace 的識別資料。
- [ ] Team 可用。
  1. 選用預設 Team。
  2. 確認時區。
  3. 保存 Team 的識別資料。
- [ ] Status 映射符合工作階段。
  1. 讀取 statuses。
  2. 依類別填入環境紀錄。
  3. 確認 default status。
  4. 檢查可能提前關閉工作的 automations。
- [ ] Priority 有採用準則。
  1. 確認是否已有政策。
  2. 依本頁建議記錄採用方式。
- [ ] Estimate 的採用方式明確。
  1. 判斷是否需要容量管理。
  2. 決定是否啟用。
  3. 啟用時記錄量尺及各項計分設定。
- [ ] Labels 可用於實際分類需求。
  1. 檢視既有 labels。
  2. 選定有用途的 labels。
  3. 填入逐項紀錄。
- [ ] 執行身分可存取目標工作。
  1. 記錄責任人。
  2. 確認 Agent 的身分與連線方式。
  3. 以執行身分讀取目標 Team。
- [ ] 責任人有通知入口。
  1. 由本人確認通知偏好。
  2. 在首項正式工作確認 subscription。
- [ ] 首項正式工作的欄位符合配置。
  1. 依授權需求建立 Issue，或進入[Project 規畫](project-planning.md)。
  2. 讀回 Issue。
  3. 逐項對照環境紀錄。
  4. 修正實際差異。

## 既有環境接手清單

- [ ] 本次範圍符合目前決策。
  1. 讀取環境政策。
  2. 讀取目標 Issue。
  3. 讀取 parent。
  4. 讀取最新討論。
- [ ] 識別資料仍有效。
  1. 確認目前 Workspace。
  2. 確認目標 Team。
  3. 查詢相關列表的所有分頁。
  4. 以實際 ID 更新過期映射。
- [ ] Status 映射符合既有流程。
  1. 讀取 status 類別。
  2. 核對每個名稱的用途。
  3. 確認 default status。
  4. 用一項代表 Issue 對照[生命週期](issue-lifecycle.md)。
- [ ] 自動化影響可判斷。
  1. 查閱 auto-close 設定。
  2. 查閱 auto-archive 設定。
  3. 查閱 parent 關閉連動。
  4. 查閱 sub-issue 關閉連動。
  5. 有 Cycle 或 Git 整合時，逐條記錄狀態轉換規則。
- [ ] 選用欄位沿用既有政策。
  1. 查閱 Priority 準則。
  2. 查閱 Estimate 量尺。
  3. 核對 labels 的用途。
  4. 同名或用途不明的項目交由管理者釐清。
- [ ] 操作範圍符合本次責任。
  1. 以執行身分讀取目標 Issue。
  2. 確認可開啟成果。
  3. 核對設定管理者。
  4. 核對可用工具。
- [ ] 責任人能追蹤工作。
  1. 確認 subscription。
  2. 由本人檢查通知偏好。
- [ ] 接手紀錄可供下次使用。
  1. 保存查證日期。
  2. 填入環境紀錄。
  3. 記錄影響操作的實際差異。
  4. 首個已授權寫入後讀回欄位。
  5. 核對使用的是原有物件 ID。

## 環境紀錄

將此結構填入目標 Workspace 的既有政策文件。
每項 ID 從目標環境讀取。

- 查證日期：
- 操作者：
- Workspace
  - 名稱：
  - URL：
  - ID：
  - 方案：
  - 設定管理者：
- Team
  - 名稱：
  - Identifier：
  - UUID：
  - 時區：
  - 存取範圍：
  - 設定管理者：
- Status（每個工作階段各填一組）
  - 工作階段：
  - 名稱：
  - ID：
  - 類別：
- Default status：
- Automation（每條規則各填一組）
  - 觸發事件：
  - 執行結果：
  - 設定入口：
- Priority 使用準則：
- Estimates
  - 啟用情況：
  - 量尺：
  - Extended scale：
  - 是否允許 0：
  - 未估算計分：
- Label（每個 label 各填一組）
  - 名稱：
  - ID：
  - Scope：
  - Team ID：
  - Group：
  - 用途：
- 執行身分
  - 人類 Assignee：
  - Agent 身分：
  - 連線方式：
  - Team access：
  - 可用操作：
- 通知
  - 查看入口：
  - Subscription 規則：
- 實際差異（每項各填一組）
  - 差異：
  - 受影響操作：
  - 處理者：
  - 解除條件：
- 首項正式工作入口：
- 讀回證據：

## 來源與查證

發布者均為 Linear。
查證日期均為 2026-09-13。
證據狀態為「文件已確認」。
章節名稱可在頁內搜尋定位。

- S1：[Teams](https://linear.app/docs/teams)
  - Overview：預設 Team。
  - Team settings：設定入口。
- S2：[Issue status](https://linear.app/docs/configuring-workflows)
  - Overview：預設 workflow。
  - Configure：狀態與類別。
  - Default status：新 Issue 的初始狀態。
  - Duplicate issue status：系統管理重複狀態。
  - Auto-close and auto-archive：關閉與封存自動化。
- S3：[Priority](https://linear.app/docs/priority)
  - Overview：固定等級。
  - Urgent Notifications：Urgent 提醒。
- S4：[Estimates](https://linear.app/docs/estimates)
  - Overview：用途。
  - Configure：Team 量尺。
  - Zero estimates：0 與未估算計分。
  - Analytics：effort 統計。
- S5：[Issue labels](https://linear.app/docs/labels)
  - Labels：scope。
  - Label groups：分組選取限制。
  - Create labels：建立入口。
- S6：[Members and roles](https://linear.app/docs/members-roles)
  - Overview：角色管理入口。
  - Admin：Free 全員 Admin。
  - Team owner：Team 設定管理權限。
  - Guest：受限存取。
- S7：[Private teams](https://linear.app/docs/private-teams)
  - Overview：方案條件。
- S8：[Assign and delegate issues](https://linear.app/docs/assigning-issues)
  - Delegating to agents：人類責任與 Agent access。
- S9：[Notifications](https://linear.app/docs/notifications)
  - Overview：Inbox。
  - Configure：通道設定。
  - Subscribing to an issue：subscription。

[S1]: https://linear.app/docs/teams
[S2]: https://linear.app/docs/configuring-workflows
[S3]: https://linear.app/docs/priority
[S4]: https://linear.app/docs/estimates
[S5]: https://linear.app/docs/labels
[S6]: https://linear.app/docs/members-roles
[S7]: https://linear.app/docs/private-teams
[S8]: https://linear.app/docs/assigning-issues
[S9]: https://linear.app/docs/notifications
