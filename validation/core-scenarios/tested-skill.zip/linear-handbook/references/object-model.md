# Linear 物件關係與功能選擇

查證日期：2026-09-12。
適用情境：個人開發者＋多個 Agent。
證據原則：[policy](policy.md#證據與來源)。
本版政策：[寫作規則](writing.md)。

本文件以官方文件確認功能事實，功能選擇與例子則標為建議。
來源代號 O01–O10、G01 的章節、證據狀態及限制列於文末。

## 物件關係

以下為文件已確認的功能事實。

- Workspace
  - 關係與用途：組織工作所在的容器，包含 Teams、Issues 等物件
  - 原生限制／注意事項與來源
    - 同一帳號可使用多個 Workspace。
    - 各自有成員清單與計費方案。
    - [O01](https://linear.app/docs/workspaces#multiple-workspaces)。

- Team
  - 關係與用途
    - 擁有 Issues 及其 workflow。
    - 可參與 Projects。
  - 原生限制／注意事項與來源
    - 每個 Issue 只屬於一個 Team。
    - Project 可由多個 Teams 共用。
    - [O02](https://linear.app/docs/teams#tips-on-structuring-teams)。

- Initiative
  - 關係與用途：以目標聚合 Projects，提供跨專案的進度視角
  - 原生限制／注意事項與來源
    - Workspace 層級與 Team-led Initiative 的可見性不同，不能只靠聚合關係推定權限。
    - [O03](https://linear.app/docs/initiatives#who-can-see-initiatives)。

- Project
  - 關係與用途：聚合具有共同成果的 Issues，可放文件並追蹤進度
  - 原生限制／注意事項與來源
    - 每個 Issue 同時最多屬於一個 Project。
    - 可不設定完成日期。
    - [O04](https://linear.app/docs/projects#add-issues-to-a-project)（另見 FAQ）。

- Milestone
  - 關係與用途：組織單一 Project 內的完成階段，再將該 Project 的 Issues 加入
  - 原生限制／注意事項與來源
    - 無法跨 Projects 共用。
    - 日期為選填。
    - [O05](https://linear.app/docs/project-milestones#faq)（另見 Create milestones）。

- Cycle
  - 關係與用途：Team 的重複工作時間區間，安排 Issues
  - 原生限制／注意事項與來源
    - 需在 Team 啟用。
    - 週期長度設定為 1–8 週，與 release 無綁定關係。
    - Issue 無法排入 cooldown。
    - [O06](https://linear.app/docs/use-cycles#cycle-settings)。

- Issue
  - 關係與用途
    - 可追蹤及驗收的工作單位，沿所屬 Team 的 workflow 移動。
    - 可加入 Project 或 Cycle。
  - 原生限制／注意事項與來源
    - Assignee 同時是一人。
    - 原生 delegation 可保留人類 Assignee，由具有該 Team 存取權的 Agent 執行。
    - [O07](https://linear.app/docs/conceptual-model#issues)。
    - [O10](https://linear.app/docs/assigning-issues#delegating-to-agents)。

- Sub-issue
  - 關係與用途：設定 parent 關係的 Issue，用於拆分較大的工作
  - 原生限制／注意事項與來源
    - 可跨 Team。
    - Project 也可與 parent 不同。
    - 建立 sub-issue 時複製
      - Team。
      - Priority。
      - Project。
    - Cycle 有條件繼承，Labels 不繼承。
    - [O02](https://linear.app/docs/teams#tips-on-structuring-teams)。
    - [O04](https://linear.app/docs/projects#add-issues-to-a-project)。
    - [O08](https://linear.app/docs/parent-and-sub-issues#copy-properties)。


圖中箭頭標示不同關係，並非必須逐層建立的單一路徑。
圖未宣告所有關係的完整 cardinality。
本次未查明者列於限制。
依據：[O01](https://linear.app/docs/workspaces#overview)、[O02](https://linear.app/docs/teams#tips-on-structuring-teams)、[O03](https://linear.app/docs/initiatives#overview)、[O05](https://linear.app/docs/project-milestones#overview)、[O07](https://linear.app/docs/conceptual-model#how-these-concepts-fit-together)、[O08](https://linear.app/docs/parent-and-sub-issues#overview)。

```mermaid
flowchart TD
    W[Workspace] -->|包含| T[Team]
    W -->|包含| N[Initiative]
    N -->|聚合| P[Project]
    T -->|參與，可多 Team| P
    T -->|擁有 workflow 與 Issues| I[Issue]
    T -->|安排週期| C[Cycle]
    P -->|組織階段| M[Milestone]
    P -->|聚合，Issue 最多一個 Project| I
    M -->|分組同 Project 的 Issues| I
    C -->|安排工作時間| I
    I -->|拆分為| S[Sub-issue，仍是 Issue]
```

Cycle 與 Milestone 提供不同維度：前者表達工作時間，後者表達交付階段。
Issue 可同時記錄 Project 與 Cycle。
不需把 Cycle 建成 Project 的子層。[O07](https://linear.app/docs/conceptual-model#issues)

## 會影響建模的行為

- Team 數量依方案判斷
  - Free：2。
  - Basic：5。
  - Business：無上限。
  - Enterprise：無上限。
- 採用前確認目標 Workspace 方案。[O02](https://linear.app/docs/teams#team-limits)
- Workspace-level Initiatives 對非 guest 成員可見。
- 放入其中的 private Project 仍限制存取。Team initiatives 為 Business／Enterprise 功能，private Team-led Initiative 限具有該 Team 存取權的人查看。[O03](https://linear.app/docs/initiatives#team-initiatives)
- Sub-initiatives 為 Enterprise 功能，最多五層，可有多個 parents，向上聚合 Projects。
- 可見性文件的差異見下方限制。[O09](https://linear.app/docs/sub-initiatives#basics)
- Parent auto-close 與 Sub-issue auto-close 都是 Team 選用設定：可分別在所有子項 Done 時關閉 parent，或在 parent Done 時關閉剩餘子項。實際環境未盤點，不假定已啟用。[O08](https://linear.app/docs/parent-and-sub-issues#status-automation)
- Parent 轉為 Project 時，原 parent 和子項會成為 Project 內的獨立 Issues，原 parent 改名，親子關係移除。[O08](https://linear.app/docs/parent-and-sub-issues#turn-issues-into-projects)
- Cycle 結束時未完成工作通常會 rollover。
- cooldown 期間轉入 backlog、triage、canceled、completed 的項目有例外。無法把未完成項目留在已關閉的 Cycle。[O06](https://linear.app/docs/use-cycles#issues-rollover)

## 功能選擇表

以下為本 handbook 的建議，以物件用途與維護成本推導，並非平台強制規則。

- 同一個人管理多個產品與 Agent
  - 選擇：先使用一個 Workspace、一個 Team
  - 判斷理由與取捨
    - 維持共同 workflow。
    - 新增 Team 應有獨立流程、權限或排程需求。
    - 官方也建議不確定時由少量 Teams 開始。
    - [O01](https://linear.app/docs/workspaces#overview)。
    - [O02](https://linear.app/docs/teams#overview)。

- 一項能獨立驗收的工作
  - 選擇：Issue
  - 必要資訊
    - 交付物。
    - 證據。
    - 完成條件。

- 一個成果需拆成數個可分別交接的工作
  - 選擇：Parent＋Sub-issues
  - 判斷理由與取捨
    - Parent 保留整體結果與整合驗收。
    - 每個子項有自己的交付及負責人。
    - 符合官方較小工作群的建議。
    - [O08](https://linear.app/docs/parent-and-sub-issues#overview)。

- 多項工作需要共同 brief、階段、目標日期及持續進度更新
  - 選擇：Project
  - 判斷理由與取捨
    - 使用 Project 的專屬上下文與進度能力。
    - 判斷重點是協調需求，不設固定 Issue 數量門檻。
    - [O04](https://linear.app/docs/projects#overview)。

- 單一 Project 有 Alpha、Beta、正式推出等完成階段
  - 選擇：Milestone
  - 判斷理由與取捨
    - 各階段寫可判定的成果。
    - 階段內仍可有多個 parent 與獨立 Issues。

- 多個 Projects 共同達成較長期目標
  - 選擇：Initiative
  - 判斷理由與取捨
    - 先有可說明的共同目標，再做聚合。
    - 只有一項交付時通常維持 Project 即可。

- 需要每週或雙週檢視承諾工作
  - 選擇：Cycle
  - 判斷理由與取捨
    - 以同一 Team 的節奏安排跨 Project 工作。
    - 先確認有固定檢視習慣再啟用。

- 多 Agent 分頭執行
  - 選擇：各自可驗收的 Issues／Sub-issues
  - 判斷理由與取捨
    - 在 Issue 明示執行範圍及交接入口。
    - 不因 Agent 數量增加而建立 Team。
    - 原生 delegation 的權限前提見 O10，外部 MCP session 是否映射為 Agent 尚未實測。


### Project 與 parent issue

1. 先寫預期成果及整合驗收。
2. 若單一 Issue 已能完整交付，直接使用 Issue。
3. 若只是同一成果的執行拆分，使用 parent，讓子項分別交付可驗收的部分。
4. 若需獨立 brief、階段與持續的專案進度管理，使用 Project。
Project 內仍可用 parent 聚合局部工作。
5. 範圍擴大時重新判斷。
轉換前確認要保留的 parent 說明與親子結構，並依 O08 的轉換結果驗證。

Parent 依整體完成條件驗證成果。
auto-close 設定依 [policy](policy.md) 核對。

## 產品與 Git repository

以下對應是建議：產品代表長期服務的對象與價值，Project 表達一段可交付成果，repository 記錄程式碼位置。
產品可以經過多個 Projects 持續演進。
一項 Project 可以需要多個 repositories，也可以只修改 monorepo 的部分目錄。
此為工作建模方式，不表示 Linear 原生提供本文件定義的 Product 欄位。

- 一個產品、一個 repo
  - 建議記錄方式
    - 以推出功能、改善或遷移成果建立 Projects。
    - brief 連到同一 repo。

- 一個產品、多個 repos
  - 建議記錄方式
    - Brief 逐項列出 repo 與責任，例如
      - 前端。
      - API。
      - Infra。
    - Issue 指明本次路徑及交付驗證。

- 一個 monorepo、多個產品
  - 建議記錄方式
    - brief 指明產品與目錄。
    - Issue 記錄受影響套件，避免僅用 repo 名稱界定工作。

- 多個產品共用元件
  - 建議記錄方式
    - 共用元件改善有獨立 Issue／Project。
    - 消費端各自記錄採用與驗證工作，連結相依成果。


每個 Issue 同時只能加入一個 Project，因此共用成果建議選一個主要歸屬。
其他 Project 用連結說明用途，只有各自有交付與驗收時才拆不同子項。[O04](https://linear.app/docs/projects#add-issues-to-a-project)

GitHub 整合另有實際限制，不能由上表推定同步可行性：

- Issues Sync 設定連接 GitHub repo 與 Linear Team。
- 多個 repos 可單向送入同一 Team，但同時只有一個 repo 可設雙向同步。[G01](https://linear.app/docs/github#configure-github-issues-sync)
- Issues Sync 預設處理新建 Issues。
- 既有 GitHub Issues 需匯入。[G01](https://linear.app/docs/github#configure-github-issues-sync)
- 同一 GitHub organization 不能連接多個 Linear Workspaces。
- 因此拆 Workspace 前須確認整合影響。[G01](https://linear.app/docs/github#add-multiple-github-organizations)

PR、同步配置與 connector 能力見 [agent-tool-capabilities](agent-tool-capabilities.md)。

## 三個建模例子

以下為設計例子與紙上驗收。

### 例一：修正單一產品的登入錯誤

- 情境：一個產品位於一個 repo，需修正過期 token 的錯誤提示。
- 結構：現有 Team → 一個 Issue。
- Issue 保留必要輸入
  - 相關 repo／路徑。
  - 錯誤情境。
  - 驗證入口。
- 選擇：成果可一次獨立驗收，直接追蹤 Issue。
- 有既定 Cycle 才排入。
- 擴大條件：若查證後包含 API 修正與前端提示兩份可獨立交接成果，將原 Issue 作為 parent，分成兩個子項，parent 驗證端到端行為。

- [x] 同一 Issue 只有一個 Team，Project 可省略。
- 單項成果及擴大後的整合驗收均可定位。

### 例二：跨前後端 repos 推出付費方案

- 情境：一位開發者與多個 Agent，前端與 API 分在兩個 repos。
- 結構：同一 Team →「推出付費方案」Project →「可測試付款」「可正式訂閱」Milestones。
- 拆分：「完成訂閱流程」parent 下設 API、前端、端到端驗證三個子項。
- 每個子項寫 repo、交付與驗收，Project brief 彙整兩個 repos。
- 排程：若已使用 Cycle，依當期容量安排 API 與前端 Issues。
- 跨期工作保留其 Project 與交付階段。
- 選擇：Project 管理共同交付，parent 管理局部整合，Milestone 表達階段，Cycle 表達時間。repo 數量不決定 Team 數量。

- [x] 各 Issue 只有一個 Project。
- Milestones 在同一 Project 內
- 兩個 repos 的工作位置明確。
- [x] 若要 Issues Sync，需依 G01 選擇單向／雙向組合，不能假定兩個 repos 均可雙向連同一 Team。

### 例三：monorepo 內兩個產品共同改用新登入系統

- 情境：產品 A、產品 B 與 auth 套件位於同一 repo，各產品可分階段驗收。
- 結構：現有 Team。
- 「統一登入體驗」Initiative 聚合「共用 auth 能力」「產品 A 遷移」「產品 B 遷移」三個 Projects。
- 拆分：共用 auth 的 Issue 歸在共用能力 Project。
- A、B 的採用 Issues 各歸自己的 Project，引用共用能力交付與驗證入口。
- 階段：A、B 分別建立其 Project 內的「試行」「全量」Milestones。
- 同名階段仍各自維護。
- 選擇：獨立推出及驗收需要不同 Projects，共同目標才使用 Initiative。
- 先沿用共通 Team workflow，未來有不同權限或排程需求再評估分 Team。

- [x] 共用 Issue 未同時掛多個 Projects。
- 單一 repo 可明確記錄各 Project 的目錄範圍。
- [x] Milestones 各屬自己的 Project。
- Initiative 聚合成果的理由明確，沒有跨 Project 共用 Milestone。

## 來源記錄

以下來源發布者均為 Linear，查證日期均為 2026-09-12。
頁面級發布／更新日期均未確認。
證據狀態為「文件已確認」。
O03／O09 的可見性差異另標「有衝突」，見下節。
章節名稱可作為頁內搜尋定位。
本文件的網頁連結指向相應頁面與章節。

- O01
  - 標題與 URL：[Workspaces](https://linear.app/docs/workspaces)
  - 章節／支持結論
    - Overview。
    - Multiple workspaces。
    - 容器、獨立成員及計費。
  - 適用限制：沒有驗證跨 Workspace 遷移或權限

- O02
  - 標題與 URL：[Teams](https://linear.app/docs/teams)
  - 章節／支持結論
    - Overview。
    - Team limits。
    - Tips on structuring teams。
    - Team 選擇。
    - 數量。
    - 跨 Team 關係。
  - 適用限制：方案與 Team 設定以實際 Workspace 為準

- O03
  - 標題與 URL：[Initiatives](https://linear.app/docs/initiatives)
  - 章節／支持結論
    - Overview。
    - Who can see initiatives。
    - Team initiatives。
    - 聚合及可見性。
  - 適用限制
    - Team initiatives 限 Business／Enterprise。
    - 與 O09 有範圍差異。

- O04
  - 標題與 URL：[Projects](https://linear.app/docs/projects)
  - 章節／支持結論
    - Overview。
    - Add issues to a project。
    - Multi-team projects。
    - FAQ。
    - 成果、單一歸屬及日期選填。
  - 適用限制：說明產品功能，不保證 connector 操作能力

- O05
  - 標題與 URL：[Project milestones](https://linear.app/docs/project-milestones)
  - 章節／支持結論
    - Overview。
    - Create milestones。
    - Add milestones to issues。
    - FAQ。
    - 階段及不可跨 Project。
  - 適用限制：進度指標未當作實際驗收證據

- O06
  - 標題與 URL：[Cycles](https://linear.app/docs/use-cycles)
  - 章節／支持結論
    - Cycle settings。
    - Issues rollover。
    - FAQ。
    - 排程及 rollover。
  - 適用限制
    - Team 啟用與 automations 未盤點。
    - Sub-team 排程繼承非本版最低配置。

- O07
  - 標題與 URL：[Concepts](https://linear.app/docs/conceptual-model)
  - 章節／支持結論
    - Issues。
    - Cycles。
    - How these concepts fit together。
    - Issue 與多種維度。
  - 適用限制：概念說明，不是完整 API schema

- O08
  - 標題與 URL：[Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues)
  - 章節定位
    - Overview。
    - Copy properties。
    - Status automation。
    - Turn issues into projects。
  - 適用限制
    - 繼承是建立時行為。
    - 未證實後續欄位持續同步。

- O09
  - 標題與 URL：[Sub-initiatives](https://linear.app/docs/sub-initiatives)
  - 章節／支持結論
    - Basics。
    - Visibility and filtering。
    - 五層。
    - 多 parents。
    - 可見性。
  - 適用限制
    - Enterprise。
    - 可見性例外與 O03 待釐清。

- O10
  - 標題與 URL：[Assign and delegate issues](https://linear.app/docs/assigning-issues)
  - 章節／支持結論
    - Overview。
    - Delegating to agents。
    - Assignee 與 delegation。
  - 適用限制：原生 Agent 需 Team access，不代表外部 MCP 自動具備身分

- G01
  - 標題與 URL：[GitHub](https://linear.app/docs/github)
  - 章節定位
    - Configure GitHub Issues Sync。
    - Add multiple GitHub organizations。
  - 適用限制
    - 僅摘錄建模相關限制。
    - GitHub Enterprise 差異、整合授權與實際設定未驗證。


## 限制與待確認

- Initiative 可見性：O03 的 Team initiatives 說明 private Team-led Initiative 有存取限制。
- O09 的 Visibility and filtering 則概括 Sub-initiatives 對非 guest Workspace 成員可見，未說明 private Team-led 例外。兩者可能是適用範圍差異，但未經實測確認
- 需處理敏感目標時先驗證實際可見性。本文件的例子均未依賴私有 Initiative。
- 本次未查明 Project 同時直接屬於多個 Initiatives 的完整規則、Issue parent 深度上限，以及 Issue 的 Cycle／Milestone 欄位完整 cardinality。
- 圖與建議均不依賴這些未定規則。
- 未確認本 Workspace 的方案、Cycle 或 automations 設定。
- 功能可用性與 API／MCP 寫入能力需於具體操作前確認。
