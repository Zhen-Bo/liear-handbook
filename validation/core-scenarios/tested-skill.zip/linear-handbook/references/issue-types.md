# 工作類型與 parent issue 選擇指南

適用情境：個人開發者＋多個 Agent。
查證日期：2026-09-13。

- 物件關係依據：[object-model.md](object-model.md)。
- 本版政策：[寫作規則](writing.md)。

## 先選成果，再選類型

以下分類與完成條件是 handbook 建議。
實際工作應把範例中的門檻替換成可核對的數值或結果。

1. 寫出本項結束後要交付的結果。
2. 依主要完成條件選一個工作類型。
3. 以額外 labels 表達需要搜尋的面向。
4. 不同成果需要各自驗收時，拆成 issues 並寫清相依關係。
5. 最後判斷是否需要 parent 或 project。

| 主要成果 | 建議類型 |
| --- | --- |
| 恢復已承諾的行為 | Bug |
| 提供原本沒有的能力 | Feature |
| 提升既有能力的使用品質 | 改善 |
| 維持外部行為並調整內部結構 | 重構 |
| 清除已知的持續維護負擔 | 技術債 |
| 用證據回答尚未決定的問題 | 研究 |
| 達成可量測的資源或速度目標 | 效能 |
| 降低明確的安全風險 | 安全 |
| 將使用者或資料切換到新基礎 | 遷移 |
| 讓讀者能理解或完成指定操作 | 文件 |
| 增加可持續偵測錯誤的能力 | 測試 |
| 恢復正在受影響的服務 | 事故 |
| 將指定版本交付給目標使用者 | 發布 |

### 重疊時的判斷

- Bug 與改善
  - 有規格或已接受行為可證明偏差時，選 Bug。
  - 原行為符合承諾但希望更好用時，選改善。
- 重構與技術債
  - 交付集中在內部結構變更時，選重構。
  - 交付集中在移除已知負擔時，選技術債。
  - 技術債可能透過重構處理，類型依該 issue 的主要驗收選擇。
- 研究與實作
  - 要先判定方案是否可行時，先建立研究 issue。
  - 已知要修正的 Bug 可在同一 issue 內診斷原因。
  - 診斷過程本身不要求另建研究 issue。
- 效能與 Bug
  - 違反既定延遲承諾的修正可選 Bug。
  - 另加效能面向 label，保留基準測試驗收。
- 安全與事故
  - 服務正在受影響且主要目標為恢復時，選事故。
  - 永久修補以獨立安全 issue 驗收，並連回事故證據。
- 文件與測試
  - 為 Feature 完成條件所需的小型配套可留在原 issue。
  - 有獨立交付與責任時，再拆為文件或測試 issue。
- 遷移與發布
  - 需要處理新舊狀態切換時，選遷移。
  - 以版本推出結果驗收時，選發布。

## 各類工作的證據與完成條件

### Bug

- 目的：修復實際行為與已承諾行為的偏差。
- 必要證據
  - 預期行為的規格或既有驗收依據。
  - 可定位的失敗案例與受影響版本。
  - 重現步驟或能證明問題的觀測紀錄。
- 完成條件
  - [ ] 原失敗案例符合預期行為。
  - [ ] 受影響路徑的回歸檢查通過。

### Feature

- 目的：交付使用者原本無法完成的新能力。
- 必要證據
  - 目標使用者與要完成的任務。
  - 已採用的需求及範圍。
  - 關鍵流程的預期結果。
- 完成條件
  - [ ] 目標使用者能完成指定流程。
  - [ ] 已列出的失敗情境有符合需求的處理結果。

### 改善

- 目的：提升既有能力的使用品質。
- 必要證據
  - 目前摩擦的具體案例。
  - 期望改善的使用結果。
  - 可比較的現況基準。
- 完成條件
  - [ ] 指定情境符合事先定義的改善標準。
  - [ ] 既有核心任務仍能完成。

### 重構

- 目的：在保持外部行為的前提下改善內部結構。
- 必要證據
  - 具體結構問題的程式定位。
  - 需要維持的外部行為契約。
  - 目標結構的可檢查描述。
- 完成條件
  - [ ] 目標結構已落實於指定範圍。
  - [ ] 外部行為契約的相關檢查通過。

### 技術債

- 目的：移除已知會持續增加成本或風險的負擔。
- 必要證據
  - 負擔所在的具體元件或流程。
  - 已觀察到的維護成本或風險。
  - 可判定負擔消除的目標狀態。
- 完成條件
  - [ ] 目標範圍已不再依賴所列負擔。
  - [ ] 原有使用情境的驗證通過。

### 研究

- 目的：提供足以作出下一步決策的證據。
- 必要證據
  - 要回答的具體問題。
  - 比較方案的判斷準則。
  - 可定位的第一手來源或實驗資料。
- 完成條件
  - [ ] 研究回答有證據支持，足以做出約定的決策。
  - [ ] 若採用不可行結論，已有足以排除方案的證據。
  - [ ] 建議結論說明採用理由。
  - [ ] 阻止決策的必要資訊缺口已補齊。

### 效能

- 目的：達成指定的效能或資源使用目標。
- 必要證據
  - 指標定義與目標門檻。
  - 量測環境及工作負載。
  - 可重複取得的基準結果。
- 完成條件
  - [ ] 在可比較條件下達成目標門檻。
  - [ ] 結果記錄量測方法與樣本。
  - [ ] 指定的正確性檢查通過。

### 安全

- 目的：消除或降低具體安全風險。
- 必要證據
  - 受影響資產與適用版本。
  - 風險成立的條件。
  - 可在授權環境驗證的漏洞證據或威脅情境。
- 完成條件
  - [ ] 指定風險情境被阻擋，或達成明定的緩解目標。
  - [ ] 合法使用流程仍可完成。
  - [ ] 若保留殘餘風險，已有具名決策者的處置紀錄。

敏感證據連到具有適當存取權限的位置。
Issue 內保留理解工作所需的風險摘要。

### 遷移

- 目的：將資料或使用流程切換至新系統狀態。
- 必要證據
  - 舊狀態與目標狀態的對應規則。
  - 受影響範圍與切換順序。
  - 資料一致性的檢查方式。
  - 回退或向前修復的條件。
- 完成條件
  - [ ] 指定範圍已在目標狀態運作。
  - [ ] 對帳或一致性檢查通過。
  - [ ] 恢復方案具備約定的驗證證據。
  - [ ] 舊系統依本項退場條件處理完成。

### 文件

- 目的：讓指定讀者能理解內容或執行操作。
- 必要證據
  - 讀者要解決的問題。
  - 適用版本或查證日期。
  - 支持操作與功能結論的來源。
- 完成條件
  - [ ] 文件回答指定問題。
  - [ ] 操作內容依約定方式核對。
  - [ ] 讀者可定位成果與引用入口。

### 測試

- 目的：建立能持續發現指定錯誤的驗證能力。
- 必要證據
  - 要保護的行為或既有漏失案例。
  - 目前檢查的覆蓋缺口。
  - 預定執行位置與時機。
- 完成條件
  - [ ] 測試能偵測指定錯誤。
  - [ ] 正確行為能通過測試。
  - [ ] 測試在指定入口可重複執行。

### 事故

- 目的：恢復正在受影響的服務。
- 必要證據
  - 影響起始時間與範圍。
  - 目前服務狀態的觀測資料。
  - 已採取措施的時間線。
- 完成條件
  - [ ] 服務符合事先指定的恢復指標。
  - [ ] 約定的觀察期間通過。
  - [ ] 仍需永久改善的工作已有可追蹤入口。

恢復服務與永久修正可有不同完成時間。
Postmortem 若需獨立交付，建立相關工作並連回時間線。

### 發布

- 目的：把指定版本交付給目標使用者。
- 必要證據
  - 可識別的版本或建置產物。
  - 目標環境與推出範圍。
  - 發布准入條件。
  - 回退或停止推出的判斷標準。
- 完成條件
  - [ ] 目標環境運行指定版本。
  - [ ] 發布後的健康檢查通過。
  - [ ] 約定的交付通知或版本資訊已提供。

## 原生欄位、Label 與 Template

以下為 Linear 官方文件確認的功能事實。

| 機制 | 用途 | 文件依據 |
| --- | --- | --- |
| 原生 issue 欄位 | 記錄平台定義的工作屬性 | [Create issues — Apply pre-set properties](https://linear.app/docs/creating-issues#apply-pre-set-properties) |
| Label | 依自訂分類組織 issues | [Issue labels — Labels](https://linear.app/docs/labels#labels) |
| Label group | 同一群組至多選一個 label | [Issue labels — Label groups](https://linear.app/docs/labels#label-groups) |
| Standard template | 預填 issue 屬性與內文 | [Issue templates — Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates) |
| Form template | 在建立 issue 時蒐集結構化資訊 | [Issue templates — Create form templates](https://linear.app/docs/issue-templates#create-form-templates) |

- 原生屬性有各自用途。
  - Status 表達 workflow 階段。[Create issues — Overview](https://linear.app/docs/creating-issues#overview)
  - Priority 表達處理急迫程度。[Priority — Overview](https://linear.app/docs/priority#overview)
  - Parent 關係表達工作拆分。[Parent and sub-issues — Overview](https://linear.app/docs/parent-and-sub-issues#overview)
- Labels 可建立於 workspace 或特定 team。[Issue labels — Labels](https://linear.app/docs/labels#labels)
- 官方以 `Type/Bug` 示範建立 label group 與 label。[Issue labels — Create a label during add label workflow](https://linear.app/docs/labels#create-a-label-during-add-label-workflow)
- 官方 Jira 文件將 Issue Type 列為 Linear 未採用的功能。[Jira — Limitations](https://linear.app/docs/jira#limitations)
- Workspace template 不能預設 team 專用的 issue status。[Issue templates — Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates)
- Workspace template 不能預設 team 專用的 labels。[同章節](https://linear.app/docs/issue-templates#create-standard-issue-templates)
- Form template 可將欄位設為必填。[Issue templates — Create form templates](https://linear.app/docs/issue-templates#create-form-templates)
- 依建立時使用的 template 可篩選 issues。[Issue templates — Template based Insights](https://linear.app/docs/issue-templates#template-based-insights)

### 建議配置

1. 先沿用現有 labels 與 templates，確認是否能表達主要成果。
2. 需要一致的工作類型篩選時，使用單選 `Type` label group。
3. 只建立實際需要的類型 labels。
4. 次要面向使用群組外 label，或不同維度的 label group。
5. Template 依要蒐集的證據選用，並核對預設屬性。

- 本指南的十三種類型是工作分類建議。
  - `Type/Bug` 在上述官方範例是 label 配置。
  - 不應將十三種類型描述為 Linear 強制提供的原生 issue type 清單。
- 類型只決定如何描述成果。
  - 安全工作依實際影響設定 Priority。
  - Parent 也可標 Feature 或其他主要工作類型。
  - 改變類型時，同步修訂驗收內容。

## Issue、parent 與 project 選擇

以下決策是 handbook 建議，延續 [object-model.md 的功能選擇](object-model.md#功能選擇表)。

| 情境 | 選擇 | 判斷依據 |
| --- | --- | --- |
| 一份成果可獨立交付並驗收 | Issue | 單一內文能界定工作 |
| 同一成果需拆成可各自交接的部分 | Parent + sub-issues | Parent 驗證整體成果 |
| 共同成果需要獨立專案進度管理 | Project | 需要專屬上下文與進度入口 |
| Project 內有局部成果需要拆分 | Project 內的 parent | 局部整合有獨立完成條件 |
| 不同成果只存在先後依賴 | Issues + blocked by | 相依本身不構成親子關係 |

1. 寫出整體完成條件。
2. 能由單一 issue 交付時，維持 issue。
3. 有可獨立交接的部分時，使用 parent 聚合。
4. 需要專案層級的持續協調時，使用 project。
5. 每個子項寫自己的成果與驗收，parent 保留整合條件。

### 功能依據與操作注意

- 官方建議使用 sub-issues 拆分介於單一 issue 與 project 之間的工作。[Parent and sub-issues — Overview](https://linear.app/docs/parent-and-sub-issues#overview)
- Project 以共同成果組織 issues。[Projects — Overview](https://linear.app/docs/projects#overview)
- Project 可提供專屬進度圖。[同章節](https://linear.app/docs/projects#overview)
- 每個 issue 同時只能歸屬一個 project。[Projects — Add issues to a project](https://linear.app/docs/projects#add-issues-to-a-project)
- 需要等待另一項成果時，可使用 blocked by 關係。[Issue relations — Blocked / blocking](https://linear.app/docs/issue-relations#blocked-blocking)
- Sub-issue 建立時不繼承 parent 的 labels。[Parent and sub-issues — Copy properties](https://linear.app/docs/parent-and-sub-issues#copy-properties)
- Parent 與 sub-issue 的狀態自動關閉是 team 選用設定。[Parent and sub-issues — Status automation](https://linear.app/docs/parent-and-sub-issues#status-automation)
  - Parent auto-close 可在所有子項 Done 後關閉 parent。
  - Sub-issue auto-close 可在 parent Done 後關閉其餘子項。
- Parent 轉為 project 會改變原有結構。[Parent and sub-issues — Turn issues into projects](https://linear.app/docs/parent-and-sub-issues#turn-issues-into-projects)
  - 原 parent 與子項成為 project 內的獨立 issues。
  - 原 parent 會重新命名。
  - 親子關係會移除。

### 操作建議

- 每個子項依自己的成果確認類型。
- 要以狀態自動化推動結案前，先確認設定與整合驗收方式相符。
- Parent 轉成 project 前保存整體驗收。
- 轉換後將整體驗收放回適當成果入口。

### 選擇例子

| 情境 | 類型 | 結構 | 可判定結果 |
| --- | --- | --- | --- |
| 過期 token 顯示錯誤提示 | Bug | 單一 issue | 原失敗案例顯示規格要求的提示 |
| 完成訂閱需分別交付 API 與前端 | Feature | Parent + sub-issues | Parent 驗證端到端訂閱流程 |
| 分階段將客戶移至新登入系統 | 遷移 | Project | 各階段通過切換與一致性檢查 |
| 恢復中斷的服務 | 事故 | 獨立 issue | 服務通過恢復指標 |
| 修復事故揭露的永久漏洞 | 安全 | 連回事故的 issue | 指定漏洞情境被阻擋 |

## 來源記錄

以下來源發布者均為 Linear。
查證日期：2026-09-13。
證據方式：查閱官方文件並核對章節。

| 文件 | 章節定位 | 支持結論 |
| --- | --- | --- |
| [Create issues](https://linear.app/docs/creating-issues) | Overview | Issue 基本工作單位與必填屬性 |
| [Create issues](https://linear.app/docs/creating-issues#apply-pre-set-properties) | Apply pre-set properties | 平台可預設的屬性 |
| [Issue labels](https://linear.app/docs/labels#labels) | Labels | 分類與作用範圍 |
| [Issue labels](https://linear.app/docs/labels#label-groups) | Label groups | 同群組單選 |
| [Issue labels](https://linear.app/docs/labels#create-a-label-during-add-label-workflow) | Create a label during add label workflow | Type/Bug 範例 |
| [Issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates) | Create standard issue templates | 預填與 team 屬性限制 |
| [Issue templates](https://linear.app/docs/issue-templates#create-form-templates) | Create form templates | 必填表單欄位 |
| [Issue templates](https://linear.app/docs/issue-templates#template-based-insights) | Template based Insights | 依 template 篩選 |
| [Priority](https://linear.app/docs/priority#overview) | Overview | 急迫程度 |
| [Jira](https://linear.app/docs/jira#limitations) | Limitations | Issue Type 的產品差異 |
| [Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues#overview) | Overview | 拆分用途 |
| [Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues#copy-properties) | Copy properties | Labels 不繼承 |
| [Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues#status-automation) | Status automation | 選用自動關閉 |
| [Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues#turn-issues-into-projects) | Turn issues into projects | 轉換結果 |
| [Projects](https://linear.app/docs/projects#overview) | Overview | Project 用途 |
| [Projects](https://linear.app/docs/projects#add-issues-to-a-project) | Add issues to a project | Issue 單一 project 歸屬 |
| [Issue relations](https://linear.app/docs/issue-relations#blocked-blocking) | Blocked / blocking | 工作依賴 |

## 使用者政策

工作粒度依 [policy 的工作粒度與授權](policy.md#工作粒度與授權)。
文字與目前結論維護依 [writing](writing.md)。
