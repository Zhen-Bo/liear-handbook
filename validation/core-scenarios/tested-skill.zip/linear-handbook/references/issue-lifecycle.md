# Issue 生命週期與結案

依可觀察事件更新工作，讓狀態與實際交付一致。
以下操作流程是使用建議。
Linear 功能事實集中於「平台行為」，並附官方來源。

## 使用入口

- [進度 comment](../assets/templates/progress-comment.md)：記錄新增發現與結果。
- [Project update](../assets/templates/project-update.md)：摘要整體交付變化。
- [交接](../assets/templates/handoff.md)：提供恢復執行所需輸入。
- [文件放置](documentation.md)：選擇成果的權威位置。

## 先映射既有狀態

1. 讀取目標 Team 的 status 清單。
2. 核對每個 status 的設定。
   - ID。
   - 類別。
   - 使用說明。
3. 依下列語意選擇現有狀態。
4. 讀取會改變狀態的 automations。
5. 將映射寫入環境政策，實際更新使用該 Team 的 ID。

| 工作語意 | 映射方式 |
| --- | --- |
| 尚未排入執行 | 選既有 backlog 類狀態 |
| 已排定但尚未開始 | 選既有 unstarted 類狀態 |
| 正在執行 | 選既有 started 類執行狀態 |
| 審查或驗收中 | 優先用既有對應階段狀態，確認其類別仍為 started |
| 必要輸入阻塞 | 優先使用既有阻塞政策，關係欄位另記真正 blocker |
| 已交付並通過完成條件 | 選既有 completed 類狀態 |
| 決定停止追求本項成果 | 選既有 canceled 類狀態 |
| 重複工作併入 canonical | 使用原生 duplicate 操作，由系統設定專用 duplicate 類的 Duplicate 狀態 |

- 審查或驗收沒有專用狀態時，沿用可表達未完成工作的 started 狀態。
  - Body 記錄目前階段。
  - 審查或驗收記錄指出處理者。
- 阻塞沒有專用狀態時，保留與實際階段相符的未完成狀態。
  - Issue blocker 放在 blocked by 關係。
  - 外部輸入缺口放在 body 的阻塞段落。
- 同名狀態可能有不同 ID。
  - 跨 Team 後重新解析映射。
- 發現 completed 類狀態被命名為「待驗收」時，先釐清既有政策。
  - 必要驗收仍未成立的工作，不套用 completed 類。

## 事件與更新

### 1. 工作開始

- 觸發：執行者開始處理已界定成果。
- 欄位
  - Status：映射至 started 類的執行狀態。
  - Assignee：確認成果責任人。
  - Parent：確認本項與整體交付的關係。
- Body
  - 核對本次交付範圍。
  - 確認完成條件可判定。
  - 補上必要成果位置。
- 紀錄
  - 已有新發現或決策時追加 comment。
  - 單純開始事件由狀態變更表達。

### 2. 阻塞

- 觸發：缺少必要輸入，使具體操作無法繼續。
- 欄位
  - Issue blocker：設定正確方向的 blocked by。
  - Status：依阻塞政策映射未完成階段。
  - Due date：只有交付日期已重新決定時才調整。
- Body
  - 缺口：需要哪個輸入。
  - 影響：哪項交付無法繼續。
  - 解除條件：得到什麼結果即可恢復。
  - 處理者：誰能補上輸入。
- 紀錄
  - Comment 記錄新阻塞及證據。
  - 整體日期或範圍受影響時更新 project。
- 恢復
  1. 讀 blocker 的目前結果。
  2. 驗證必要輸入實際可用。
  3. 更新 body 的目前階段。
  4. 依現行關係及環境政策處理已解除的 blocker。

Blocker 被取消或標為 duplicate 時，追到替代成果後重新判斷。
關係外觀改變不足以證明輸入已到位。

### 3. 審查

- 觸發：已有可供判斷的成果版本。
- 欄位
  - Status：映射至審查階段。
  - 成果關聯：連到受審版本或 PR。
- Body
  - 目前方案：更新為送審版本。
  - 審查入口：提供版本與必要背景。
- 紀錄
  - 在已有發送授權的審查請求中，指出需要對方判斷的事項。
  - 審查意見需要修正時，記錄具體差異。
  - 修正開始後映射回執行階段。

Assignee 表達成果責任。
審查請求另指定審查者。

### 4. 驗收

- 觸發：成果足以逐項核對完成條件。
- 欄位
  - Status：保持對應的未完成驗收階段。
- Body
  - 驗收 checkbox：只勾選有證據支持的結果。
  - 驗證入口：連到受測版本。
  - 失敗項目：保留實際差異。
- 紀錄
  - 驗證記錄指出測試環境。
  - 每項結果附證據定位。
  - 失敗後確定需修正的工作。

PR review 通過可支持程式審查條件。
產品行為的驗收仍對照該項成果的完成條件。

### 5. 完成

- 觸發：目前有效的必要完成條件均成立。
- 結案前
  1. 核對交付成果與受驗版本一致。
  2. 確認必要驗收結果。
  3. 確認接手者可開啟成果。
  4. 檢查 parent 與子項的關閉連動。
  5. 確認後續工作有必要輸入。
- 欄位
  - Status：映射至 completed 類。
- Body
  - 彙整可使用成果。
  - 更新目前採用結論。
  - 保留影響使用的限制。
- 紀錄
  - 完成 comment 列已交付成果。
  - 驗證結果指向證據。
  - 有後續工作時提供其入口。
- 寫入後
  - 讀回本項狀態。
  - 檢查受到連動的 parent 或子項。
  - 發現必要成果被提前關閉時，依實際階段修正。

### 6. 取消

- 觸發：已有決策停止追求本項成果。
- 操作前
  - 確認取消決策及其適用範圍。
  - 檢查依賴此成果的工作。
  - 檢查可能連動關閉的 GitHub PR。
- 欄位
  - Status：映射至 canceled 類。
  - 關係：已有替代工作時更新依賴。
- Body
  - 取消理由：記錄採用的決定。
  - 剩餘影響：說明下游需要如何調整。
  - 已有成果：保留仍有用途的入口。
- 紀錄
  - 結案 comment 記錄取消理由。
  - 有承接工作時使用原生 issue mention。
- 寫入後
  - 回讀本項取消結果。
  - 確認受影響 PR 的狀態。
  - 確認必要下游成果有承接方式。

取消表達需求決策。
短期阻塞仍沿阻塞流程處理。

### 7. 重開

- 觸發：新證據顯示原完成條件不成立，或取消決策已改變。
- 選擇原項或新項
  - 原承諾的缺口：重開原 issue。
  - 已完成承諾以外的新需求：建立有獨立完成條件的相關工作。
- 欄位
  - Archived：先依平台入口 restore。
  - Status：映射至下一個實際未完成階段。
  - Assignee：確認接續責任人。
  - 關係：核對受影響的 parent 與依賴工作。
- Body
  - 加入使原判斷失效的新證據。
  - 修正目前有效的完成條件或結果。
  - 保留仍然成立的成果。
- 紀錄
  - Comment 說明重開原因。
  - 交接記錄提供下一個可執行操作。
- 原項若為 duplicate
  - 先確認 canonical 是否仍承接同一成果。
  - 確認目前介面如何移除錯誤 duplicate 關係。
  - 修正後讀回關係與狀態。

### 8. 重複 issue

- 觸發：兩項工作承接相同成果，保留一項即可追蹤。
- 操作順序
  1. 選定 canonical issue。
  2. 比對兩項的成果與完成條件。
  3. 比對重複項獨有證據，將必要文字結論納入 canonical。
  4. 確認 canonical 的接手者可讀取必要來源。
  5. 檢查 GitHub PR 關閉連動。
  6. 從重複項使用原生 duplicate 操作指向 canonical。
  7. 讀回 Duplicate 狀態與 canonical 關係。
  8. 核對移至 canonical 的附件。
  9. 核對移至 canonical 的 customer requests。
  10. 核對移至 canonical 的 synced Slack threads。
  11. 確認下游關係及受影響 PR。
- Body
  - 重複項保留併入理由。
  - 原生 issue mention 指向 canonical。
  - Canonical 摘要目前有效需求。
- 紀錄
  - Comment 記錄此次合併新增了哪些必要資訊。
  - 原有證據位置保持可追溯。

原生 duplicate 會搬移特定資料，詳見 L08。
操作前確認 canonical 的存取範圍適合接收這些資料。
搬移完成後更新失效的成果引用。

部分重疊但各有獨立交付時，保留各項並說明共享成果。
不要以一般 related 關係代替已確定的 duplicate 操作。

## 依交付定義完成條件

- 研究文件
  - 回答約定問題。
  - 結論有可定位證據。
  - 接手者讀得到文件。
- 可交付的程式變更
  - 約定行為驗證通過。
  - 必要程式審查成立。
  - 交付版本可定位。
- 包含正式發布的工作
  - 指定版本成功部署至目標環境。
  - 正式環境的必要驗證通過。
  - 成果可由目標使用者取得。
- Parent
  - 各項必要成果均有證據。
  - 整合驗收成立。
  - 子項取消或 duplicate 的影響已核對。

若部署由另一個 issue 承接，實作項依自身完成條件結案。
部署項保留正式環境交付責任。
原本包含上線的工作，需有範圍決策與承接入口才能改變其完成邊界。

## 案例

以下為虛構示範，透過紙上核對說明判斷方式。

### PR 已合併但驗收失敗

- 原承諾：使用者可匯出全部篩選資料。
- 已有證據
  - PR 已合併。
  - 驗收輸出 100 筆，預期為 200 筆。
- 處理
  1. 在 body 記錄實際筆數差異。
  2. 將工作映射至實際修正階段。
  3. 檢查 PR automation 是否提前設為 completed。
  4. 依查證定位遺漏原因後修正。
  5. 重新驗證全部 200 筆只出現一次。
- [x] 合併證據與行為驗收分開判讀。
- [x] 失敗證據支持工作維持未完成。
- [x] 下一步可從差異開始查證。

### 部分完成

- 原承諾：支援 CSV 與 XLSX 匯出。
- 已有證據
  - CSV 通過約定驗收。
  - XLSX 大檔案產生失敗。
- 沿原範圍繼續
  - Body 保留 CSV 的成果入口。
  - XLSX 保持未完成。
  - 原 issue 依實際階段維持開啟。
- 決定分階段交付時
  1. 記錄調整範圍的決策及理由。
  2. 替 XLSX 建立獨立成果與完成條件。
  3. 更新兩項工作之間的關係。
  4. 讓 parent 保留整體匯出承諾。
  5. 依調整後的 CSV 完成條件結案。
- [x] 部分成功有成果入口。
- [x] 必要剩餘工作有承接條件。
- [x] 整體承諾保留在 parent 驗收。

## 平台行為

查證日期：2026-09-13。
以下來源發布者均為 Linear。
證據層級為官方文件查閱。

- L01：[Issue status](https://linear.app/docs/configuring-workflows#configure)
  - 章節：Configure。
  - Team 可自訂狀態名稱。
  - 狀態類別的排序固定。
- L02：[Duplicate issue status](https://linear.app/docs/configuring-workflows#duplicate-issue-status)
  - 章節：Duplicate issue status。
  - Duplicate 狀態由系統管理。
  - 標為 duplicate 時自動套用。
- L03：[Issue relations](https://linear.app/docs/issue-relations#duplicate)
  - 章節：Duplicate。
    - 從重複項指向 canonical。
    - Issue 顯示指回 canonical 的入口。
  - 章節：[Blocked / blocking](https://linear.app/docs/issue-relations#blocked-blocking)。
    - Blocker resolved 後，關係會顯示在 Related。
- L04：[GitHub](https://linear.app/docs/github#workflow-automation)
  - 章節：Workflow automation。
    - PR 事件可依 Team 設定更新 issue status。
  - 章節：[Magic words](https://linear.app/docs/github#magic-words)。
    - Closing 關聯會套用 merge 時的狀態自動化。
    - Non-closing 關聯不套用 merge 時的狀態。
    - Relation 語法只建立關聯。
  - 章節：[Automatic PR Cancellation](https://linear.app/docs/github#automatic-pr-cancellation)。
    - 直接取消 issue 或標為 duplicate，會關閉以 Closes 或 Contributes 關聯的開啟 PR。
    - PR 若同時連到另一個 open issue，維持開啟。
    - 僅 reference 關聯的 PR 維持開啟。
    - 完成 issue 不會關閉 PR。
    - Automated cancellations 不會關閉 PR。
- L05：[Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues#status-automation)
  - 章節：Status automation。
  - Team 可啟用全部子項 Done 時自動關閉 parent。
  - Team 可啟用 parent Done 時自動關閉剩餘子項。
  - Git 整合觸發的狀態變更也遵循這些設定。
- L06：[Delete and archive issues](https://linear.app/docs/delete-archive-issues#auto-close)
  - 章節：Auto-close。
    - 可設定依閒置時間自動關閉 issue。
    - 更改狀態可重開自動關閉項。
  - 章節：[Restore issues](https://linear.app/docs/delete-archive-issues#restore-issues)。
    - Archived issue 可還原。
- L07：[Releases](https://linear.app/docs/releases#overview)
  - 章節：Overview。
  - Done 狀態不必然代表已交付使用者。
- L08：[Project Slack channels — Issue duplicates](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
  - 發布日期：2026-05-21。
  - 章節：Issue duplicates。
  - Duplicate 使用專用 status type。
  - 每個 duplicate 必須指向原 issue。
  - 標為 duplicate 時，customer requests 移至原 issue。
  - Synced Slack threads 移至原 issue。
  - Attachments 移至原 issue。
  - 原 issue 完成時，synced Slack threads 會收到通知。
  - 相關 Zendesk 或 Intercom customer tickets 會重新開啟。

## 採用前確認

- Team 狀態語意
  - 檢查實際類別與說明。
  - 指派名稱前先解析 ID。
- 關閉連動
  - 核對 PR automations。
  - 核對 parent 與子項設定。
  - 以代表工作確認實際更新結果。
- Duplicate 恢復
  - 官方引用未列完整解除步驟。
  - 採用目前 UI 或工具前，確認可移除關係及恢復狀態的操作。
- 成果存取
  - 使用接手角色核對必要證據可讀性。
- 自動化與驗收不一致
  - 先依成果修正工作狀態。
  - 由有權限的設定維護者調整觸發政策。
  - 以代表事件讀回修正結果。
