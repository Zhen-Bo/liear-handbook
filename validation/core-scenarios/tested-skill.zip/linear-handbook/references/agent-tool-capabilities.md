# Linear API、MCP 與 GitHub 整合能力

官方文件查證日期：2026-09-12。
固定 API schema：`23f11eb41ef63ba219ec582911079c19d1abbf62`。
本文件保留官方證據範圍，操作前需核對當前介面。

## 證據等級

- 官方產品文件支持功能與使用條件。
- API schema 支持該固定版本的欄位宣告。
- 目前工具 schema 決定本次可傳的參數。
- 實際讀回只支持該帳號、物件與操作。

## 能力矩陣

- Issue 與 comment 讀寫
  - 官方依據
    - API query／mutation [S02]。
    - MCP 用例 [S03]。
  - 操作前確認
    - 建立工具。
    - 更新工具。
    - 讀回工具。

- Parent
  - 官方依據
    - Parent 功能 [S04]。
    - parentId schema [S13a]。
  - 操作前確認
    - Parent 建立欄位。
    - Parent 移除方式。
    - 子項查詢方式。

- 相依
  - 官方依據
    - Blocking、Related 與 Duplicate [S05]。
    - relation mutation [S13b]。
  - 操作前確認
    - 關係方向。
    - 追加或取代語意。

- Document
  - 官方依據
    - 文件歸屬 [S06]。
    - document mutation [S13c]。
  - 操作前確認
    - Parent 支援範圍。
    - Patch 契約。
    - 讀回方式。

- 分頁
  - 官方依據：GraphQL Relay cursor [S07]
  - 操作前確認：各工具的頁面參數與回傳位置

- GitHub
  - 官方依據：Team PR 狀態映射 [S08]
  - 操作前確認
    - App 安裝。
    - PR 關聯類型。
    - Workflow。


### 親子與相依

- Parent／sub-issue 自動關閉由 Team 配置。[S04]
- 固定 schema 的 IssueCreateInput 與 IssueUpdateInput 包含 parentId。[S13a]
- API 支持 relation 建立與刪除。[S13b]
- 讀取每個前置的目前 status 及成果。
  - 關係清單不是完成條件。
  - 取消或 duplicate 時追到替代成果。
- 關係寫入後讀回兩端，確認方向與保留關係。

### 文件

- 產品文件列出的 document 歸屬 [S06]
  - Project。
  - Initiative。
  - Team。
  - Issue。
  - Cycle。
- 固定 schema 的部分 parent 欄位標為 Internal。[S13c]
- 依當前介面確認所需歸屬，不能只憑產品文件承諾 connector 支援。
- 文件回復與重新歸屬各自核對可用操作。
- 附件依 [tool-recovery 的附件交付](tool-recovery.md#附件交付) 選擇適用協定。

### 分頁

- GraphQL 使用 first／after 與 pageInfo.endCursor。[S07]
- hasNextPage 決定是否仍有下一頁。[S07]
- Connector 可使用不同欄位，逐工具查 schema 與實際回傳。
- 保持 filter 與排序，保存 cursor 並依 ID 去重。
- 完整走完列表仍需重讀選定目標，不能當作同一時點快照。

## 權限、方案與身分

- API key 可以限制操作與 Teams。[S01]
- OAuth scopes 分離 [S09]
  - read。
  - write。
  - issues:create。
  - comments:create。
  - admin。
- 讀取成功不保證寫入或其他 Team 可用。
- 官方 MCP 唯讀 endpoint 只暴露讀取工具。[S03]
- OAuth user 與 actor=app 是不同身分。[S09][S10]
- 原生 Agent 的委派與 session 生命週期另有介面。[S11]
  - Delegate 欄位存在不代表外部 MCP 自動成為原生 Agent。
  - 操作前確認連線身分與 Team access。
- 方案及 App approvals 由目標環境確認。[S12][S14]
  - 方案比較文字缺少勾選狀態時，不推定所有方案可用。
  - 上傳還需核對當前介面的單檔限制。

## 寫入、分頁與恢復的介面邊界

1. 查閱當前工具的版本條件、patch、idempotency 與交易範圍。
2. 未宣告的保證不自行推定。
3. GraphQL 回傳可同時包含資料與 errors，HTTP 200 不足以證明成功。[S02]
4. updatedAt 讀回可提示變動，但不等於伺服器強制的版本條件。
5. 即使單次 patch 有原子契約，也不擴大成跨工具交易或認領排他保證。
6. 嚴格排他需求採用能拒絕第二個執行者並使舊執行者失去寫入能力的已驗證排程機制。
7. 結果未知時先查遠端效果，按 [tool-recovery](tool-recovery.md) 恢復。

API headers 提供額度與 reset。
request、endpoint 與 complexity 可各有限制。[S15]
Connector 可能不暴露 headers，依實際回傳採有限退避。
多 Agent 共用額度時協調請求量。

## GitHub 採用條件

以下條件由 2026-09-12 官方文件支持。[S08]

- Team 的 PR／commit automations 決定狀態映射。
- Target branch 可影響規則。
- Closing 關聯可觸發 merge 狀態。
- Non-closing 保留其他 workflow 更新，但不套用 merge 狀態。
- Relation 只建立關聯。
- 多 PR 的狀態需依官方多關聯規則及目前設定核對。
- Ready for merge 另需核對
  - Checks。
  - Review。
  - Branch protection。
- GitHub Issues Sync 需獨立確認方向與 Team／repo mapping。
- 取消或 duplicate 前核對 [issue-lifecycle 的平台行為](issue-lifecycle.md#平台行為)。

採用前記錄：

- GitHub host。
- App 安裝的 repo。
- Linear Team。
- 事件與 status 映射。
- PR 關聯類型。
- 代表事件及預期結果。

用已授權代表工作讀回所需 PR 與 issue 階段。
合併提供整合證據。
部署與成果驗收各依自己的證據判斷。

## 來源

發布者均為 Linear，查閱日期均為 2026-09-12。
S13a–S13c 是固定版本 API schema，其餘為產品或開發文件。

- S01： [API and Webhooks](https://linear.app/docs/api-and-webhooks)。
  - API：資料讀寫。
  - API Keys：權限範圍。
  - API Keys：Team 限制與管理權限。
- S02： [Getting started — GraphQL](https://linear.app/developers/graphql)。
  - Endpoint 與 Authentication：API 請求方式。
  - Error handling：部分資料與 errors 可並存。
  - Creating & Editing Issues：issueCreate 與 issueUpdate 範例。
- S03： [MCP server](https://linear.app/docs/mcp)。
  - General：MCP endpoint 與傳輸方式。
  - FAQ：唯讀存取方式。
  - Common use cases：可操作物件與親子用例。
  - 工具欄位契約以實際 tools 宣告為準。
- S04： [Parent and sub-issues](https://linear.app/docs/parent-and-sub-issues)。
  - Create a sub-issue：建立親子關係。
  - Status automation：自動完成設定。
  - Converting issues：親子轉換。
- S05： [Issue relations](https://linear.app/docs/issue-relations)。
  - Related issues：相關工作語意。
  - Blocked / blocking：阻擋關係與 UI 顯示。
  - Duplicate：重複工作語意。
- S06： [Documents](https://linear.app/docs/documents)。
  - 頁首：文件可歸屬的物件。
  - Edit documents：共同編輯。
  - Version history：版本紀錄。
- S07： [Pagination](https://linear.app/developers/pagination)。
  - 頁首：Relay cursor。
  - orderBy 範例：查詢順序。
  - 預設分頁大小：50 筆。
- S08： [GitHub](https://linear.app/docs/github)。
  - Permissions：GitHub 安裝權限。
  - GitHub Enterprise options：方案條件。
  - Magic words：PR 關聯種類。
  - Link multiple issues：多項工作連結。
  - Workflow automation：狀態映射。
  - Configure GitHub Issues Sync：Issue 同步配置。
- S09： [OAuth 2.0 authentication](https://linear.app/developers/oauth-2-0-authentication)。
  - Redirect user access requests to Linear：OAuth scopes。
  - Actor 參數：預設使用者身分。
- S10： [OAuth actor authorization](https://linear.app/developers/oauth-actor-authorization)。
  - 頁首：user 與 app 操作身分。
- S11： [Agents — Getting Started](https://linear.app/developers/agents)。
  - Developer Preview：當次文件的成熟度標示。
  - Actor and scopes：原生 Agent 授權。
  - Management：App 存取管理。
  - Agent session lifecycle：原生 Agent session 邊界。
- S12： [Third-Party App Approvals](https://linear.app/docs/third-party-application-approvals)。
  - 頁首：付費方案條件。
  - Configure：核准設定與管理角色。
- S13a： [官方 schema — IssueUpdateInput](https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L22348)。
  - L22348 IssueUpdateInput：parentId。
  - L22348 IssueUpdateInput：delegateId。
  - 同檔 L18598 IssueCreateInput：建立欄位。
- S13b： [官方 schema — IssueRelationCreateInput](https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L20623)。
  - L20623 IssueRelationCreateInput：issueId。
  - L20623 IssueRelationCreateInput：relatedIssueId。
  - L20623 IssueRelationCreateInput：type。
  - 同檔 L26109：建立 relation mutation。
  - 同檔 L26122：刪除 relation mutation。
- S13c： [官方 schema — DocumentCreateInput](https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L10446)。
  - L10446 DocumentCreateInput：content 與 parent 欄位。
  - L10446 DocumentCreateInput：Internal 註記。
  - 同檔 L24335：documentCreate。
  - 同檔 L24362：documentUpdate。
- S14： [Pricing](https://linear.app/pricing)。
  - 方案摘要：Teams 與 issues 額度。
  - File upload：檔案上傳條件。
  - API and webhook access：API 存取比較列。
  - MCP access：MCP 存取比較列。
  - 當次文字抽取缺少逐方案勾選狀態。
- S15： [Rate limiting](https://linear.app/developers/rate-limiting)。
  - API request limits：每小時請求額度。
  - Query- and mutation-specific request limits：特定操作額度。
  - Complexity limits：複雜度限制。
  - 回應 headers：剩餘額度與 reset。


[S01]: https://linear.app/docs/api-and-webhooks
[S02]: https://linear.app/developers/graphql
[S03]: https://linear.app/docs/mcp
[S04]: https://linear.app/docs/parent-and-sub-issues
[S05]: https://linear.app/docs/issue-relations
[S06]: https://linear.app/docs/documents
[S07]: https://linear.app/developers/pagination
[S08]: https://linear.app/docs/github
[S09]: https://linear.app/developers/oauth-2-0-authentication
[S10]: https://linear.app/developers/oauth-actor-authorization
[S11]: https://linear.app/developers/agents
[S12]: https://linear.app/docs/third-party-application-approvals
[S13a]: https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L22348
[S13b]: https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L20623
[S13c]: https://github.com/linear/linear/blob/23f11eb41ef63ba219ec582911079c19d1abbf62/packages/sdk/src/schema.graphql#L10446
[S14]: https://linear.app/pricing
[S15]: https://linear.app/developers/rate-limiting
