# 文件放置與維護指南

- 適用情境：個人開發者＋多個 Agent。
- 查證日期：2026-09-13。

本指南的放置選擇與維護流程是第一版建議。
平台功能依據見「Linear 功能與來源」。
本版的寫作與 issue 內文維護政策以 [寫作規則](writing.md) 為準。

- 物件選擇依據：[object-model.md](object-model.md)。
- 定期檢查入口：[maintenance.md](maintenance.md)。

## 放置決策

1. 確認文件服務的讀者需求。
   - 理解目標。
   - 判斷成果。
   - 採取具體操作。
2. 短內容能在 issue 或 project description 說清楚時，直接維護內文。
3. 需要獨立全文時，依用途選位置。
   - 需隨程式版本 review 的內容選 repo。
   - 依 Linear 工作演進的協作長文選 Linear document。
   - 需要既有知識庫或專用版面時選外部文件。
4. 確認預期讀者與執行 Agent 可存取所選位置。
5. 指定一個權威全文，其他位置保留用途與連結。
6. 需要保存驗收證據時，另存標明來源版本的快照。

### 七類文件

下列路徑可依既有專案結構調整。

- brief
  - 短版預設放 project description。
  - 需要獨立長文時放 project document。
  - 跨部門已有共同編輯空間時，可用外部文件。
  - 需隨版本保存時，可用 repo `docs/brief.md`。
  - Project 保留目標與權威全文入口。
  - 建議維護者：project lead。
- PRD
  - 預設放 project document。
  - 需求需與程式一起 review 時，可用 repo `docs/product/`。
  - 外部產品協作可沿用既有文件平台。
  - Project 保留採用需求的摘要。
  - 實作 issues 連到對應章節。
  - 建議維護者：需求決策者。
- 研究
  - 預設放 repo `research/`。
  - 證據記錄
    - 來源。
    - 查證日期。
    - 事實與推論的區別。
  - 短期共同探索可用 issue document 或 project document。
  - 外部共享可沿用既有分析平台。
  - 研究 issue 摘要目前結論及其影響。
  - 建議維護者：研究負責人，結案後指定承接者。
- ADR
  - 預設放 repo `docs/adr/`，標明適用程式版本。
  - 跨 repo 決策可用共用文件 repo。
  - 沒有程式版本關聯時，可用 Linear document 或既有決策庫。
  - 決策 issue 連到 ADR。
  - 舊決策被取代時連到新 ADR。
  - 建議維護者：系統維護者。
- runbook
  - 與部署或指令綁定的內容放服務 repo `docs/runbooks/`。
  - 共通人工流程可放 team document。
  - 需在事故期間獨立存取時，可用既有營運知識庫。
  - 服務入口連到適用版本。
  - 系統變更時同步修正受影響步驟。
  - 建議維護者：服務維護者。
- postmortem
  - 事故 issue 保留恢復摘要。
  - 必要長文放 issue document。
  - 跨事故分析可用 repo `docs/postmortems/` 或既有事故庫。
  - 事故 issue 的相關入口
    - 時間線。
    - 原因證據。
    - 改善 issues。
  - 建議由事故協調者完成，再交服務維護者承接。
- 程式文件
  - 預設放 repo，依內容使用 README 或靠近程式的文件。
  - 公開讀者需要文件網站時，可由 repo 發布。
  - Repo 產生的網站以 repo 為權威來源。
  - 專用外部參考資料保留原來源。
  - Issue 連到交付版本。
  - 建議維護者：程式模組維護者。

### Linear document 歸屬建議

- Project：該項成果的規格與共同背景。
- Initiative：跨 projects 的共同目標背景。
- Team：跨 project 的共通流程。
- Issue：單項工作的補充長文。
- Cycle：該期紀錄。
  - 長期 runbook 另設持續維護的入口。

建立新 project 前，先確認既有歸屬能否滿足文件需求。

## 權威版本與連結

- Issue body 依 [writing](writing.md) 維護目前有效資訊。
  - 目標。
  - 採用結論。
  - 交付成果。
  - 未決問題。
- 完整文件連回權威全文。
- Comments 保存有新增資訊的發現與理由。
- 日常操作連到目前有效版本。
- 程式證據連到固定 commit。
- 驗收證據標明驗證版本。
- ADR 標明適用基準。
- Repo 內可用相對路徑。
- 從 Linear 進入需提供可開啟的遠端入口。
- 附件快照的入口使用穩定 issue 頁與附件名稱。
  - 下載時重新取得有效 URL。
  - 快照註明與權威全文的關係。
- 引用相關 issue 時使用原生 issue mention，並說明關聯。

不同副本衝突時：

1. 依權威聲明確認來源。
2. 比對適用版本。
3. 將新增且有效的內容合併至權威全文。
4. 更新其他入口。

最後修改時間只作檢查線索。
以預期讀者驗證連結可讀性，某個 Agent 讀取成功只證明該連線可用。

## 維護責任與資訊

持續使用的文件需要能找到維護責任。
個人專案預設由開發者本人承接，Agent 可執行已授權修訂。
維護責任不由 creator 或最後編輯者欄位推定。

依持續維護需要，在文件或既有目錄記錄以下資訊。
既有入口已能定位的資訊可直接引用。

- 用途。
- 適用範圍。
- 適用版本。
- 具名維護者。
- 權威入口。
- 最近查證日期。
- 已驗證版本：需要固定執行基準時填寫。
- 已知缺口：存在失效部分時填寫。
  - 受影響操作。
  - 替代入口或查證工作。
  - 處理責任。

移交步驟：

1. 接任者確認可讀取文件。
2. 接任者確認可修改文件。
3. 接任者確認適用基準。
4. 更新維護者。
5. 更新受影響入口。

無接任者時，建議由 project lead 或服務維護者指定承接人。
恢復有效性前，標示受影響操作及待處理工作。

## 更新與失效

建議以每月檢查為起點，依影響調整。
事件發生時優先檢查受影響內容。
定期流程見 maintenance.md 的「Recurring work 與文件有效性」。

- 需求或採用決策改變
  - 更新 brief 或 PRD。
  - 回填 issue 的目前結論。
  - 保留必要決策理由連結。
  - 未定案項目指定決策責任。
- 程式或執行環境改變
  - 比對程式文件。
  - 比對 runbook。
  - 重驗受影響步驟並記錄版本。
  - 缺少驗證時，標明不可依賴的步驟及查證工作。
- 事故恢復或原因證據改變
  - 更新 postmortem 的事實。
  - 標示仍待確認的推論。
  - 更新時間線。
  - 連到後續改善工作。
  - 必要時修訂 runbook。
- 平台能力或來源改變
  - 重讀支持結論的來源。
  - 更新查證日期。
  - 修正受影響操作。
  - 待確認條件指定查證責任。
- 連結失效或權限改變
  - 尋找同一權威內容。
  - 更新引用入口。
  - 確認預期讀者可存取。
  - 找不到內容時，記錄缺口與負責人。
  - 設定下次查證事件或日期。
- 決策被取代或用途消失
  - 舊 ADR 保留理由與替代連結。
  - 歷史快照標明已取代。
  - 失效操作文件在入口標明不再適用。
  - 無用途的重複全文可在授權範圍內移除。

文件失效取決於內容是否仍符合目前用途與證據。
可只標記受影響章節。

### 多個 Agent 更新

1. 確認本次修改範圍與維護責任。
2. 讀取最新文件及相關 issue。
3. 寫入前再讀目標，合併期間新增的有效內容。
4. 優先使用精確局部修改。
5. 無法安全合併時保存草稿與衝突位置，交維護者決定。
6. 讀回修訂結果後回填成果。
7. 操作結果不明時先讀回，再判斷是否重試。

- [ ] 修訂後的文件可供下一位讀者使用。
  1. 讀回內容。
  2. 檢查清單層級。
  3. 開啟成果連結。
  4. 確認權威聲明。
  5. 確認歸屬與讀者權限。

## Linear 功能與來源

查證日期：2026-09-13。
以下功能事實依官方文件查閱整理。

- [D01 Documents](https://linear.app/docs/documents)
  - 頁首：文件歸屬
    - Project。
    - Initiative。
    - Team。
    - Issue。
    - Cycle。
  - Edit documents：支援共同編輯。
  - Version history：document 可查看及回復早期版本。
  - Version history：project description 也有版本歷史。
  - Reference documents：編輯器可用 `@` 選取 document。
  - Link to headers：可複製章節連結。
- [D02 Project overview](https://linear.app/docs/project-overview)
  - External links：Resources 可加入外部連結。
  - Project documents：Resources 可建立 document。
- [D03 Team pages](https://linear.app/docs/default-team-pages#team-documents)
  - Team documents：team document 可承載跨 project 共通內容。
  - Team documents：官方列 runbook 為使用情境。
- [D04 Exporting Data](https://linear.app/docs/exporting-data)
  - Issue view CSV exports：CSV 不包含附件檔案。
  - Copy issues as markdown for LLMs：可複製 issue 為 Markdown。
  - Copy issues as markdown for LLMs：可複製 document 為 Markdown。

### 工具能力確認

- 從當前 schema 確認 document 的可用 parent 與消歧欄位。
- 核對建立、修改、重新歸屬與版本回復是否各有可用介面。
- 工具缺少回復操作時，使用已授權原生介面並先保留後續變更。
- 附件 URL 過期時重新取得有效網址。

### 操作前確認

- 查找文件時保留交付 ID 與 URL。
- 列舉時處理分頁，依工具實際欄位界定範圍。
- 保存快照時保留原始檔。
- 匯出後逐項核對所需內容。
  - 文字。
  - 圖片。
  - 附件。
  - 關係。

下列條件由實際環境確認：

- 目標功能是否適用於所用方案。
- 預期讀者是否有存取權限。
- 執行者是否有修改權限。
- 歷史版本是否涵蓋所需期間。
  - 有長期保存需求時安排快照。
