# Linear 功能覆蓋與採用指南

查證日期：2026-09-12。
適用情境：個人開發者＋多個 Agent。
證據原則：[policy](policy.md#證據與來源)。
物件選擇：[object-model.md](object-model.md)。
專案政策：[寫作規則](writing.md)。

## 功能矩陣

用途與限制欄記錄官方文件事實。
重要性欄是本 handbook 的建議。
「核心」表示第一版流程需處理該問題。
「條件採用」表示有對應需求再配置功能
「擴充」表示先保留介面與決策位置。
來源 F01–F15 的章節及證據狀態列於文末。

- 搜尋與 views
  - 用途與行為
    - 全域 Search 可查 issue 內文與 comments。
    - view 內搜尋只比對 ID／title。
    - Custom Views 保存動態篩選條件。
  - 核心用途（建議）
    - 建立前查重。
    - 執行前找待辦。
    - 定期查看停滯工作。
  - 權限與方案限制
    - Search 最多回傳 500 筆。
    - 分享 view URL 不會授予存取權。
    - Initiative views 限 Enterprise。
    - 一般搜尋與 issue/project views 的最低方案未在功能頁明列。
  - 來源
    - [F01](https://linear.app/docs/search)。
    - [F02](https://linear.app/docs/custom-views)。

- Triage
  - 用途與行為
    - Team 的收件匣，先檢查外部 team 或整合送入的工作再納入 workflow。
    - 預設不進一般 views。
  - 第一版重要性與適用情境（建議）
    - 核心處理收件。
    - 有外部入口再啟用 Triage。
    - 個人既有 backlog 可先人工檢查。
  - 權限與方案限制
    - Team 設定需啟用。
    - 設定權限受 Team Settings Management 控制。
    - Business／Enterprise 功能
      - Intelligence。
      - Rules。
      - Responsibility。
    - 基本 Triage 的最低方案待核對。
  - 來源
    - [F03](https://linear.app/docs/triage)。
    - [F13](https://linear.app/docs/members-roles)。

- 回饋
  - 用途與行為
    - Customer Requests 將回饋連到 issue/project，保留來源。
    - 一般 team email intake 建 issue，但不通知寄件者後續更新。
  - 第一版重要性與適用情境（建議）
    - 核心：來源→查重→採用結論→issue。
    - Customer Requests 條件採用。
    - 需要雙向受理再評估 Asks。
  - 權限與方案限制
    - Customer Requests 明列 Free／Basic／Business／Enterprise，admin 啟用。
    - 整合另受方案限制。
    - Asks 與 Intercom/Zendesk 整合列 Business。
    - Guest 看不到 Customer Requests，FAQ 與角色文件一致。
  - 來源
    - [F04](https://linear.app/docs/customer-requests)。
    - [F06](https://linear.app/docs/creating-issues)。
    - [F12](https://linear.app/pricing)。
    - [F13](https://linear.app/docs/members-roles)。

- Templates
  - 用途與行為
    - Issue standard template 預填內容與屬性。
    - form template 可要求欄位。
    - Project template 可含 milestones 與 issues。
  - 第一版重要性與適用情境（建議）
    - 核心用途：重用必要輸入結構
      - 成果。
      - 範圍。
      - 驗收。
    - 重複專案才加入 Project template。
  - 權限與方案限制
    - Workspace issue template 不能預設 team 專屬 status/label。
    - Team template 限對應 team。
    - Team Template Management 可限 team owners。
    - 各 template 的最低方案未明列。
  - 來源
    - [F05](https://linear.app/docs/issue-templates)。
    - [F14](https://linear.app/docs/project-templates)。
    - [F13](https://linear.app/docs/members-roles)。

- Recurring work
  - 用途與行為
    - Recurring issue 依到期日與 cadence 建立後續工作。
    - 原 template 更新不會同步 recurrence。
  - 第一版重要性與適用情境（建議）：條件採用：已形成固定維護節奏，且每次有可判定成果
  - 權限與方案限制
    - 文件描述於 team 時區到期日次日 00:01 產生下一筆。
    - 非完成事件觸發。
    - 功能頁未明列最低方案及 recurrence 專屬角色矩陣。
  - 來源：[F06](https://linear.app/docs/creating-issues)

- 分析
  - 用途與行為
    - Insights 以目前 view 計算指標，例如
      - Issue count。
      - Cycle Time。
      - Lead Time。
    - 可選擇包含 archived issues。
  - 第一版重要性與適用情境（建議）
    - 擴充：有跨期趨勢問題再使用。
    - 第一版先由 views 檢查待辦與阻塞。
  - 權限與方案限制
    - Insights 限 Business／Enterprise。
    - Cycle Time 只繪出經過 in progress 後完成的 issues，Lead Time 只含完成項目。
    - 需保留取樣條件與可見範圍。
  - 來源：[F07](https://linear.app/docs/insights)

- 通知
  - 用途與行為
    - Inbox 接收通知。
    - 個人可配置通知
      - Desktop。
      - Mobile。
      - Email。
      - Slack。
      - Issue 訂閱。
  - 第一版重要性與適用情境（建議）
    - 核心：負責工作與阻塞關聯要有查看入口。
    - 只對需處理的 view 訂閱。
  - 權限與方案限制
    - Account 設定及瀏覽器／系統權限影響送達。
    - 通知分類包含多種事件，不能任意拆分。
    - 功能頁未明列最低方案。
  - 來源
    - [F08](https://linear.app/docs/notifications)。
    - [F02](https://linear.app/docs/custom-views)。

- 匯入與匯出
  - 用途與行為
    - 專用 importer 或 CLI 將外部資料映射到 Linear。
    - CSV 支援分析與保存記錄。
  - 第一版重要性與適用情境（建議）
    - 有以下需求時採用
      - 接手舊系統。
      - 交接資料。
      - 外部分析。
    - 先選必要資料。
  - 權限與方案限制
    - 匯入需 workspace admin 及來源端權限。
    - Workspace issue CSV 由 admin 匯出，Enterprise 為 owner。
    - View 匯出 member 上限 250 issues，admin／Enterprise owner 為 2,000。
    - guest 不可匯出 issues。
    - CSV 不含附件檔案。
    - 最低方案待核對。
  - 來源
    - [F09](https://linear.app/docs/import-issues)。
    - [F10](https://linear.app/docs/exporting-data)。

- 歸檔
  - 用途與行為
    - Auto-close 關閉停滯工作。
    - Auto-archive 在結案與閒置期限滿足後移入 archive。
    - 可由 archive 還原。
  - 第一版重要性與適用情境（建議）
    - 核心用途：區分各項操作效果
      - 結案。
      - 歸檔。
      - 刪除。
    - 自動化條件採用，避免清理動作代替驗收。
  - 權限與方案限制
    - Issue 歸檔由自動化執行，沒有手動 archive 選項。
    - 可能延後歸檔的關聯，依官方具體條件判斷
      - Parent／sub-issues。
      - Active cycle。
      - Unfinished project。
    - Team 設定權限受限制。
    - 刪除後僅保留 30 天復原期。
    - 最低方案未明列。
  - 來源
    - [F11](https://linear.app/docs/delete-archive-issues)。
    - [F13](https://linear.app/docs/members-roles)。


## 採用與後續流程

以下流程依實際需求選用。
檢查結果應以實際資料判斷。

- 搜尋與 views
  - 觸發與輸入：準備建立 issue，或檢查停滯 backlog
  - 檢查後應得到的結果
    - 查重範圍
      - Issue 內文。
      - Comments。
      - 必要的 archived 工作。
    - 找到既有 issue 就連結並說明關聯。
    - 保存「待受理」「停滯」「待確認結案」等有明確用途的篩選。
  - 後續工作
    - [maintenance](maintenance.md) 的重複／停滯檢查。
    - [workspace-setup](workspace-setup.md) 盤點 view 權限。

- Triage
  - 觸發與輸入：外部回饋或整合建立新 issue
  - 檢查後應得到的結果
    - 受理判斷
      - 確認問題情境。
      - 查找既有工作。
      - 指定責任人。
      - 採用時接受進 workflow。
      - 重複時連到 canonical。
      - 不採用時記錄理由。
    - 需要等待資訊時設定可追蹤的返回條件。
    - view 明確包含 Triage status。
  - 後續工作
    - [maintenance](maintenance.md) 定義受理檢查。
    - [workspace-setup](workspace-setup.md) 確認啟用與設定權限。

- 回饋
  - 觸發與輸入：收到來源訊息或 Customer Request
  - 檢查後應得到的結果
    - 保留可定位來源。
    - 先掛既有工作，再決定是否另建可驗收 issue。
    - 把目前採用結論更新進內文。
    - 需要回覆時另確認接收者與發送授權。
  - 後續工作
    - [maintenance](maintenance.md) 定義回饋流向。
    - [extension-model](extension-model.md) 處理產品營運擴充。

- Templates
  - 觸發與輸入：同類 issue 重複缺少必要資訊
  - 檢查後應得到的結果
    - 將必要問題寫入 standard template。
    - 只有創建時必填的輸入才改用 form。
    - 模板內容沿用 writing.md 的驗收 checkbox 與完成項目編號。
  - 後續工作
    - [issue-types](issue-types.md) 依工作類型選擇。
    - [workspace-setup](workspace-setup.md) 盤點原生配置。

- Recurring work
  - 觸發與輸入：已有穩定且有人負責的維護工作
  - 檢查後應得到的結果
    - 指定 recurrence 配置
      - Cadence。
      - Team 時區。
      - 每次完成條件。
      - 排程維護者。
    - 檢查前次未完是否需調整排程。
    - 修正文案時直接更新 recurrence。
  - 後續工作：[maintenance](maintenance.md) 決定維護節奏

- 分析
  - 觸發與輸入：需要回答「哪些工作等待最久」等具體問題
  - 檢查後應得到的結果
    - 解讀圖表前保存篩選基準
      - 日期範圍。
      - Status。
      - 是否包含 archived issues。
    - 以下結果需另外取得證據
      - 品質驗收。
      - 部署完成。
      - 使用者接受。
  - 後續工作
    - [maintenance](maintenance.md) 選擇維護指標。
    - [extension-model](extension-model.md) 評估較完整營運分析。

- 通知
  - 觸發與輸入：工作交接、被阻擋或等待他人處理
  - 檢查後應得到的結果
    - 確認 issue 訂閱與處理責任。
    - 必要時以 view 訂閱特定狀態。
    - Inbox 已讀與 email 到達均不作驗收證據。
  - 後續工作
    - [maintenance](maintenance.md) 配置檢查入口。
    - [agent-tool-capabilities](agent-tool-capabilities.md) 查 Agent 可讀取的通知介面。

- 匯入與匯出
  - 觸發與輸入：接手既有工具或保存交接資料
  - 檢查後應得到的結果
    - 先選來源及樣本。
    - 逐項核對匯入結果
      - 資料數量。
      - 狀態映射。
      - 親子關係。
      - Comments。
      - 附件可讀性。
    - 依 importer 專頁確認缺失欄位，再決定完整遷移。
  - 後續工作
    - [workspace-setup](workspace-setup.md) 接手盤點。
    - [documentation](documentation.md) 決定文件保存位置。

- 歸檔
  - 觸發與輸入：定期檢查過期與已結案工作
  - 檢查後應得到的結果
    - 先依交付證據判定狀態，再檢查 auto-close/auto-archive 條件。
    - 保留結案理由與成果入口。
    - 要修改 archived 工作時先 restore。
  - 後續工作
    - [issue-lifecycle](issue-lifecycle.md) 定義結案。
    - [maintenance](maintenance.md) 整理 backlog。


寫作預設見 [writing](writing.md)。
矩陣中的「核心」分類是採用建議。

## 方案與待查缺口

- 方案基準：Pricing 明列 Free 為 2 teams／250 issues，Basic 為 5 teams／unlimited issues，Business／Enterprise 為 unlimited teams／issues。[F12](https://linear.app/pricing)
- 權限基準：Free 成員自動為 admin。
- Business／Enterprise 可由 team owners 限制 template 與 team settings 管理。因此「功能可用」仍需逐項確認操作者權限。[F13](https://linear.app/docs/members-roles)
- Pricing 的文字擷取未保留比較表所有勾選狀態。本文件只將明確方案文字當作事實，沒有把未標註功能推定為所有方案可用。

- 實際 workspace 方案、team access 與管理權限
  - 目前採用與影響
    - 矩陣描述公開產品能力。
    - 配置前仍需判斷本環境可用性。
  - 查證方式與承接
    - workspace-setup 讀取 Billing 與 Team Access and permissions。
    - Billing 路徑依 [F15](https://linear.app/docs/billing-and-plans)。

- 部分基本功能的最低方案未明列
  - 最低方案需另外確認的功能
    - 搜尋。
    - 一般 views。
    - 基本 Triage。
    - Templates。
    - Recurrence。
    - 通知。
    - 匯入匯出。
    - 歸檔。
  - 查證方式與承接
    - workspace-setup 開啟實際方案比較表及對應功能設定。
    - 若仍不清楚，向 Linear support 確認具體功能與方案。
    - 採用前可維持人工受理與文件模板。

- Guest 的回饋交接與整合可見性
  - 目前採用與影響
    - F04 FAQ 與 F13 Guest 均明示 Guest 看不到 Customer Requests。
    - 已收斂為一致限制。
  - 查證方式與承接
    - 初始化時以 Guest 角色確認存取
      - Issue。
      - 附件。
      - 外部整合。
    - Customer Requests 不可作為唯一交接入口。

- Customer Requests FAQ 的方案表省略 Basic 欄
  - 目前採用與影響
    - F04 FAQ 的文字明列 Basic 可用。
    - 整合表未完整呈現 Basic。
    - Customer Requests 與整合的可用性分別判斷。
  - 查證方式與承接：需要 Basic 的指定整合時，另讀該整合頁與設定畫面，不由功能本體推定

- Recurrence 對未完成前次工作的處理，以及 Agent 可管理的欄位
  - 目前採用與影響
    - 文件支持時間觸發，尚不足以保證不產生重疊工作。
    - 不能將原生 UI 功能直接寫成 MCP 操作。
  - 查證方式與承接
    - maintenance 在採用前以受控樣本檢查下一筆與前次未完的關係。
    - agent-tool-capabilities 核對 API/MCP 能力與回讀。

- 匯入完整性、CSV 作為恢復來源的涵蓋範圍
  - 目前採用與影響
    - 欄位映射依來源不同。
    - CSV 不含附件，不能據此承諾完整還原 workspace。
  - 查證方式與承接
    - 依具體 importer 文件抽樣比對
      - Comments。
      - 附件。
      - 關係。
    - documentation 定義成果保存方式。

- Auto-archive 的時間與介面定位
  - 目前採用與影響
    - F11 分別使用 Workflows & automations 與 Issue statuses & automations 名稱。
    - 設定變更通常在 24 小時內的下一次執行生效。
  - 查證方式與承接
    - workspace-setup 記錄實際設定入口與期限。
    - maintenance 根據關聯工作狀態解讀延遲。
    - Free 額度是否排除 archived issues 未由本次來源確定，不以歸檔作為額度解法。


## 來源記錄

以下 15 個來源發布者均為 Linear，查證日期均為 2026-09-12。
頁面級發布／更新日期未確認。
證據狀態為「文件已確認」。
章節名稱提供頁內搜尋定位。
Guest 交接確認點與最低方案缺口見上表。

- F01
  - 標題與 URL：[Search](https://linear.app/docs/search)
  - 章節／支持結論
    - Search workspace。
    - Search specific views。
    - Q&A。
    - 搜尋範圍及結果上限。
  - 適用限制：原生搜尋介面，非 MCP 搜尋規格

- F02
  - 標題與 URL：[Custom Views](https://linear.app/docs/custom-views)
  - 章節定位
    - 頁首。
    - Create views。
    - Copy view link。
    - Issue view subscriptions。
  - 適用限制
    - Initiative views 的付費門檻明列。
    - URL 不授權。

- F03
  - 標題與 URL：[Triage](https://linear.app/docs/triage)
  - 章節／支持結論
    - Configure。
    - Automation。
    - FAQ。
    - 支持結論
      - 收件。
      - 進階功能。
      - Views 排除。
  - 適用限制：需 Team 啟用，進階功能分方案

- F04
  - 標題與 URL：[Customer Requests](https://linear.app/docs/customer-requests)
  - 章節／支持結論
    - Configure。
    - Add requests。
    - FAQ。
    - 回饋關聯與方案。
  - 適用限制
    - FAQ 明示 Guest 不可見。
    - Basic 的指定整合需另確認。

- F05
  - 標題與 URL：[Issue templates](https://linear.app/docs/issue-templates)
  - 章節定位
    - Create standard issue templates。
    - Create form templates。
  - 適用限制：Workspace/team 屬性作用域不同

- F06
  - 標題與 URL：[Create issues](https://linear.app/docs/creating-issues)
  - 章節定位
    - Create an issue via email。
    - Create recurring issues。
  - 適用限制：Team 時區與既有 recurrence 內容維護

- F07
  - 標題與 URL：[Insights](https://linear.app/docs/insights)
  - 章節定位
    - 頁首。
    - Apply filters。
    - Select Insights Parameters。
  - 適用限制
    - Business／Enterprise。
    - 自動取樣條件影響指標。

- F08
  - 標題與 URL：[Notifications](https://linear.app/docs/notifications)
  - 章節定位
    - Configure。
    - Notification timing。
    - Subscribing to an issue。
    - FAQ。
  - 適用限制：Account/channel/系統設定影響通知

- F09
  - 標題與 URL：[Importing guidance](https://linear.app/docs/import-issues)
  - 章節定位
    - 頁首。
    - Choose an import method。
    - Understand the import process。
  - 適用限制
    - 需 admin。
    - 資料對應依來源 importer。

- F10
  - 標題與 URL：[Exporting Data](https://linear.app/docs/exporting-data)
  - 章節定位
    - Workspace CSV exports。
    - Issue view CSV exports。
  - 適用限制
    - 角色與筆數限制。
    - 不含附件檔案。

- F11
  - 標題與 URL：[Delete and archive issues](https://linear.app/docs/delete-archive-issues)
  - 章節定位
    - Delete issues。
    - Auto-close。
    - Auto-archive。
    - Restore issues。
  - 適用限制
    - 關聯與時間條件。
    - 設定路徑名稱不同。

- F12
  - 標題與 URL：[Pricing](https://linear.app/pricing)
  - 章節定位
    - Free。
    - Basic。
    - Business。
    - Enterprise 方案卡片。
  - 適用限制
    - 動態方案。
    - 比較表勾選未完整呈現於文字。

- F13
  - 標題與 URL：[Members and roles](https://linear.app/docs/members-roles)
  - 章節定位
    - Admin。
    - Team owner。
    - Member。
    - Guest。
  - 適用限制
    - 方案。
    - Workspace restrictions。
    - Team 管理權限。

- F14
  - 標題與 URL：[Project templates](https://linear.app/docs/project-templates)
  - 章節定位
    - Overview。
    - Create templates。
  - 適用限制：Workspace/team template 可用範圍不同

- F15
  - 標題與 URL：[Billing and plans](https://linear.app/docs/billing-and-plans)
  - 章節／支持結論：Manage your billing
  - 適用限制：提供實際方案確認入口
