# Backlog 整理與持續營運檢查表

適用情境：個人開發者＋多個 Agent。
原功能查證日期：2026-09-12。

本指南協助判斷哪些工作需要處理，以及何時可結束一次維護。
維護流程與時間預算為第一版建議。

- 功能依據：[功能覆蓋研究](feature-coverage.md)。
- 寫作與內文維護政策：[寫作規則](writing.md)。
- 文件放置與維護規則：[documentation.md](documentation.md)。

## 維護節奏

由開發者指定本次維護負責人，Agent 執行已授權的檢查與更新。
先選需要回答的問題，再決定範圍與時間預算。

- 事件觸發
  - 新回饋進入時，下一次工作開始先檢查相關項目。
  - 承諾日期將到時，確認剩餘工作能否完成。
  - 阻塞解除時，重新判斷可執行範圍。
  - 持續影響使用者的故障依事故流程即時處理。
- 每週整理
  - 建議預留約 20 分鐘。
  - 優先查看執行中的工作。
  - 檢查已承諾的交付。
  - 檢查影響其他工作的依賴。
- 每月整理
  - 建議預留約 30 分鐘。
  - 檢查長期 backlog 是否仍有效。
  - 檢查 recurrence 是否符合容量。
  - 檢查本次需要使用的文件。
  - 產品方向或設定改變時，提前檢查受影響範圍。

- [ ] 本次選定項目已有處理結論。
- [ ] 需行動的項目有負責人與下一步。
- [ ] 等待項目有返回條件。
- [ ] 時間用完時，已保存剩餘範圍與續查入口。

沒有新證據或新決策時即可結束檢查。
一般清理的時間預算不終止事故處理責任。

## 開始與寫回

1. 確認操作者權限與本次寫入範圍。
2. 讀取目標 issue 的目前內文。
3. 查閱近期留言與成果。
4. 查看 blockedBy 對本次操作的實際影響。
5. 選定 team 或 project 的檢查範圍。
6. 依本次問題設定狀態與日期篩選。
7. 確認入口涵蓋等待項目，包含適用的 Triage 清單。[M01](https://linear.app/docs/triage)
8. 寫入前再讀目標，合併其他人或 Agent 的新變更。
9. 依下列位置寫回新增資訊。
10. 讀回變更後的內容與關係。

- Body：目前有效的目標與採用結論。
  - 回填成果入口。
  - 保留未決問題及受影響的操作。
- Comment：有新增資訊的發現或決策理由。
- Project update：影響 project 承諾的變更。

- [ ] 成果入口可開啟。
- [ ] Issue mention 指向正確工作。
- [ ] 狀態符合交付證據。

操作結果不明時，先讀回再決定是否重試。
Team workflow 可自訂狀態名稱，選擇時依既有狀態的語意判斷。[M07](https://linear.app/docs/configuring-workflows)
只有實際前置依賴才設定 blockedBy。
前置 issue 尚未結案時，先確認其輸入是否已可使用。
狀態映射與事件更新依[生命週期指南](issue-lifecycle.md#先映射既有狀態)。

## 維護檢查表

### 受理與 triage

- 觸發
  - 收到新回饋。
  - Triage 出現新項目。
  - 等待補件到期。
  - 開始收件檢查。
- 輸入
  - 原始來源。
  - 受影響情境。
  - 既有 issue。
  - Triage 清單。
  - Snoozed 清單。
- 退出條件
  - 本次選定項目已有去向。
  - 等待補件有負責人與返回時間。

- [ ] 每個收件項目有明確去向。
  1. 依「回饋至 issue 的流向」查重。
  2. 接受時補上可判斷的問題與下一步。
  3. 資料不足時記錄補件內容。
  4. 指定補件責任與返回時間。
  5. 不採用時保留理由。
  6. Snooze 時確認返回日期與可見範圍。

- Triage 可接受新工作。[M01](https://linear.app/docs/triage)
- 重複項目可連到既有工作。[M01](https://linear.app/docs/triage)
- 不採用的項目可拒絕。[M01](https://linear.app/docs/triage)
- Snooze 會在選定時間或新活動出現時返回。[M01](https://linear.app/docs/triage)
- 一般 views 預設排除 Triage。[M01](https://linear.app/docs/triage)
- Snoozed 項目預設對其他使用者隱藏。[M01](https://linear.app/docs/triage)

未啟用 Triage 時，可使用既有收件入口進行人工檢查。
暫離清單不代表處理完成。

### 停滯工作

- 觸發
  - 超過約定回報或交付時間。
  - 依賴改變。
  - 執行中的工作缺少下一步。
- 輸入
  - 最近成果與活動。
  - Assignee。
  - BlockedBy。
  - 承諾日期。
  - 執行者交接資訊。
- 退出條件
  - 工作可繼續執行。
  - 仍受阻的工作有解除責任與返回條件。
  - 不再符合目標的工作已交由過期檢查判定。

- [ ] 停滯原因與下一步可以由另一個 session 接手。
  1. 先開啟成果，確認是否只是尚未回填。
  2. 辨識缺少的決策或輸入。
  3. 確認權限與執行容量。
  4. 標示受影響的驗收條件。
  5. 補回有效成果與下一步負責人。
  6. 前置成果可用時，重新評估可執行範圍。
  7. 部分完成時，保留未達成條件。

最後更新時間不足以單獨判定沒有進展。
PR 已合併但仍缺部署或驗收證據時，依 issue 的交付定義繼續追蹤。

### 重複工作

- 觸發
  - 準備建立 issue。
  - 受理回饋。
  - 發現疑似重複工作。
- 輸入
  - 問題情境。
  - 預期成果。
  - 驗收條件。
  - 原始來源。
  - 候選 issues。
- 退出條件
  - 同一工作已整合到一個權威 issue。
  - 不同工作已釐清成果及關聯。

- [ ] 查重結果保留原始需求與可追溯入口。
  1. 以情境或成果詞彙搜尋。
  2. 有錯誤訊息時，以原文補查。
  3. 查看候選 issue 的內文與 comments。
  4. 必要時查閱已結案及 archived 工作。
  5. 比較問題與驗收範圍是否相同。
  6. 確認重複後，先把新增證據與有效需求整合到權威 issue。
  7. 檢查 GitHub PR 關聯與其他工作依賴。
  8. 確認自動關閉 PR 的影響符合本次操作授權。
  9. 確認 canonical 的存取範圍適合接收移轉資料。
  10. 使用可用的原生 duplicate 操作。
  11. 讀回 duplicate 關係及實際狀態。
  12. 讀回關聯 PR 的狀態。
  13. 核對移至 canonical 的附件。
  14. 核對移至 canonical 的 customer requests。
  15. 核對移至 canonical 的 synced Slack threads。
  16. 更新移轉後的成果引用。

- 相關工作不一定是 duplicate。
- 前置依賴不當作 duplicate。
- 不同平台變體需先比對交付範圍。
- 工具不支援 duplicate 時，保留候選與具體後續操作。

- Workspace Search 可查內文與 comments。[M02](https://linear.app/docs/search)
- View 內搜尋只比對 ID／title。[M02](https://linear.app/docs/search)
- 搜尋達 500 筆上限時，縮小範圍再查。[M02](https://linear.app/docs/search)
- Duplicate 使用系統管理的狀態，單獨修改一般 status 不會建立重複關係。[M07](https://linear.app/docs/configuring-workflows)

### 過期工作與歸檔

- 觸發
  - 每月 backlog 檢查。
  - 需求或產品方向改變。
  - 到期日已過。
  - 自動結案或歸檔結果不符預期。
- 輸入
  - 原始理由。
  - 目前影響。
  - 交付證據。
  - 日期。
  - Parent 與 sub-issues。
  - Project 與 cycle。
  - 自動化設定。
- 退出條件
  - 有效工作已有調整後的計畫。
  - 已交付工作依證據完成。
  - 失效工作有取消理由。
  - 待決問題有決策責任。
  - 歸檔延遲已能解釋或有查證工作。

- [ ] 每個清理候選依目前價值與交付證據處理。
  1. 判斷工作仍必要或已失效。
  2. 查看是否已有交付成果。
  3. 有效工作修正承諾與下一步。
  4. 失效工作取消前，確認 GitHub PR 關聯與其他工作依賴。
  5. 確認自動關閉 PR 的影響符合本次操作授權。
  6. 更新失效工作的內文結論並記錄取消理由。
  7. 取消後讀回 issue 與關聯 PR 狀態。
  8. 已交付工作回填成果與驗證入口。
  9. 檢查 auto-close 的閒置條件。
  10. 檢查 auto-archive 的時間與關聯條件。
  11. 需修改 archived 工作時先 restore。

- 久未更新只是檢查線索。
- 自動結案不代表已完成驗收。
- 清理工作不構成刪除資料的授權。

- Auto-close 依閒置期間運作。[M03](https://linear.app/docs/delete-archive-issues)
- Auto-archive 由平台自動執行，沒有手動歸檔選項。[M03](https://linear.app/docs/delete-archive-issues)
- 未完成的關聯工作或活躍 cycle 可延後歸檔，應比對官方條件與實際設定。[M03](https://linear.app/docs/delete-archive-issues)

### Project 健康

- 觸發
  - 每週檢查。
  - Milestone 或交付承諾改變。
  - 關鍵 issue 出現阻塞。
- 輸入
  - 目前交付目標。
  - Milestones。
  - 日期。
  - 關鍵依賴。
  - 成果與驗收證據。
  - 最近 project update。
- 退出條件
  - 健康判斷反映目前交付承諾。
  - 影響承諾的風險有處置責任與下一個判斷點。

- [ ] 健康判斷有交付證據與剩餘風險支持。
  1. 確認下一個交付是否仍可達成。
  2. 檢查關鍵路徑與尚缺的決策。
  3. 回填必要的目標或日期變更。
  4. 更新成果入口。
  5. 有重要變化時，由 project lead 彙整 update 並連到相關 issue。

原生 project update 提供下列健康指標與文字說明。[M06](https://linear.app/docs/initiative-and-project-updates)
以下解讀為本指南的判斷建議。

- On track：現有證據支持仍可達成承諾。
- At risk：已有具體風險可能使承諾落空。
- Off track：目前已偏離承諾，需要調整方案或目標。

完成百分比不代替驗收。
更新提醒作為查看入口，有新增資訊才寫入。

### Recurring work 與文件有效性

- 觸發
  - 每月檢查。
  - 前次維護未完成。
  - 模板修改。
  - 方案或工具能力改變。
  - 成果連結失效。
- 輸入
  - Recurrence 排程。
  - Team 時區。
  - 前次與下一筆工作。
  - 模板。
  - 權威文件入口。
  - 具名文件維護者。
  - 文件用途與適用版本。
- 退出條件
  - 排程符合執行容量。
  - 重疊工作有明確負責人。
  - 必要文件的權威入口可讀。
  - 失效內容有處理責任與替代入口。

- [ ] 排程繼續支援實際工作。
  1. 前次未完時，先判斷下一筆是否重複。
  2. 依執行容量決定是否調整節奏。
  3. 確認 cadence 與到期日。
  4. 確認 team 時區。
  5. 確認每次工作的交付成果。
  6. 修正內容時直接檢查 recurrence。
- [ ] 文件可支援下一步操作。
  1. 開啟本次需要使用的權威全文。
  2. 確認預期讀者可存取。
  3. 核對適用版本與具名維護者。
  4. 重複全文依權威聲明比對，將有效新增內容合併至權威版本。
  5. 修正失效段落，或標示受影響操作與待處理工作。
  6. 需要保留的歷史快照註明日期及版本。
  7. 將其他閱讀入口連回目前有效版本。

Recurring issues 預期在 team 時區到期日翌日 00:01 建立下一筆。[M04](https://linear.app/docs/creating-issues)
來源 template 的後續修改不會同步既有 recurrence。[M04](https://linear.app/docs/creating-issues)
前次未完時的實際生成行為依「採用前確認」檢查。
文件失效規則見 [documentation.md](documentation.md#更新與失效)。

## 回饋至 issue 的流向

1. 保存可定位來源與原意。
2. 記錄受影響情境及期待結果。
3. 依重複工作檢查查找既有 issue。
4. 相同成果補充既有工作，有獨立可驗收成果才建立新 issue。
5. 將新證據與建議分開，標示目前採用決策。
6. 必要選擇尚未定案時，指定決策責任與返回條件。
7. 將目前採用結論回填 body。
8. 有新增資訊的理由或過程保留於 comment。
9. 涉及共通規則時，由文件維護者更新權威全文。
10. 將成果入口連回 issue。
11. 影響 project 承諾時，同步健康判斷。
12. 讀回內文與來源關係。

使用者提供完整替換版本時，保留其內容與結構。
需要通知回饋者時，確認接收者與發送內容，依既有授權執行。

- Customer Requests 可將回饋連到 issue 或 project。[M05](https://linear.app/docs/customer-requests)
- 整合來源可保留原訊息連結。[M05](https://linear.app/docs/customer-requests)
- 未採用此功能時，以來源連結完成相同流向。
- 一般 team email intake 不會向寄件者發送受理或結案通知。[M04](https://linear.app/docs/creating-issues)

## 發布與事故管理

第一版適用於已有部署與監控方式的產品。
實際操作依產品既有規則執行。

### 發布前

- 觸發：預計推出一批變更。
- 輸入
  - 版本與變更範圍。
  - 驗收結果。
  - 部署方式。
  - 觀察指標。
  - 回滾入口。
- [ ] 已具備安全發布的必要輸入。
  1. 開啟交付證據。
  2. 確認發布執行者。
  3. 指定觀察責任與時窗。
  4. 確認失敗處置方式。
  5. 必要輸入缺漏時，記錄阻塞並暫停發布步驟。
- 擴充
  - 多環境核准。
  - 正式變更窗口。
  - 跨團隊發布協調。
  - 原生 Releases 整合。

### 發布後

- 觸發
  - 部署完成。
  - 觀察時窗結束。
  - 發現異常。
- 輸入
  - 部署紀錄。
  - 實際版本。
  - 核心操作驗證。
  - 監控結果。
- [ ] 發布結果有足以判定交付的證據。
  1. 回填發布紀錄。
  2. 回填驗證結果。
  3. 達成 issue 的交付定義才結案。
  4. 異常交事故流程處理。
  5. 剩餘改善連到可追蹤工作。
- 擴充
  - 自動發布管線。
  - 漸進推出。
  - 跨服務回滾策略。

### 事故受理與處理

- 觸發：發現持續影響使用者的故障。
- 輸入
  - 發現時間。
  - 影響範圍。
  - 已知證據。
  - 既有 runbook。
  - 處理者。
- [ ] 已有恢復證據與觀察責任，可進入恢復觀察。
  1. 指定協調者。
  2. 約定下一次回報時間。
  3. 優先控制使用者影響。
  4. 記錄重要處置及結果。
  5. 回填恢復證據並指定觀察責任。
- 擴充
  - 正式 severity。
  - On-call。
  - Paging。
  - SLO／SLA。
  - 外部狀態頁。

### 事故恢復與改善

- 觸發：影響解除且觀察完成。
- 輸入
  - 恢復證據。
  - 時間線。
  - 原因的證據狀態。
  - 剩餘風險。
- [ ] 事故結果與永久改善各有可追蹤的成果。
  1. 回填恢復驗證。
  2. 記錄原因與尚待查明的問題。
  3. 未達成的條件保留在原工作內。
  4. 獨立改善另附負責人與驗收條件。
  5. 將後續 issue 連回事故紀錄。
  6. 必要 postmortem 指定權威位置與維護者。
- 擴充
  - 跨團隊事故指揮。
  - 正式 postmortem 審查。
  - 跨事故改善追蹤。

## 採用前確認

- Triage
  - Intelligence／Rules／Responsibility 限 Business／Enterprise。[M01](https://linear.app/docs/triage)
  - 配置前查看實際方案與 team 設定。
  - 其他最低方案缺口見[功能覆蓋研究](feature-coverage.md#方案與待查缺口)。
- Recurrence
  1. 在已授權的受控樣本保留前次未完成。
  2. 檢查到期後生成結果。
  3. 核對時區與可讀回欄位。
  4. 依觀察決定節奏與重疊處理。
  5. 另外核對 API／MCP 的管理能力。
- Auto-close／auto-archive
  - 讀取實際期限。
  - 核對關聯條件。
  - 查看自動化結果。
  - 缺少設定或證據時，指定查證責任。
- Duplicate
  - Duplicate 使用專用 status type。[M09](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
  - Duplicate 是原生標記後自動套用的系統狀態名稱。[M07](https://linear.app/docs/configuring-workflows)
  - 重複判定以指向權威 issue 的 duplicate 關係為準。
  - 操作後讀回專用狀態與 canonical 關係。
  - Customer requests 會移至 canonical。[M09](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
  - Synced Slack threads 會移至 canonical。[M09](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
  - 附件會移至 canonical。[M09](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
- GitHub PR 自動關閉
  - 直接取消 issue 會關閉以 Closes 或 Contributes 關聯的開啟 PR。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
  - 標記 duplicate 具有相同效果。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
  - PR 另連到其他 open issue 時維持開啟。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
  - PR 只有 reference 關聯時維持開啟。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
  - 完成 issue 不會關閉 PR。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
  - 自動取消不會關閉 PR。[M08](https://linear.app/docs/github#automatic-pr-cancellation)
- 文件與回饋可見性
  - 以預期讀者權限確認來源可開啟。
  - 確認成果與權威文件可讀。
  - Guest 看不到 Customer Requests，應提供可存取的 issue 或附件入口。
  - Guest 限制依[功能覆蓋研究](feature-coverage.md#方案與待查缺口)已比對的官方結論。

## 來源記錄

發布者：Linear。
原功能查證日期：2026-09-12。
證據狀態：文件已確認。

- M01：[Triage](https://linear.app/docs/triage)
  - 定位
    - Take actions。
    - Automation。
    - FAQ。
  - 用途
    - 受理與 snooze 操作。
    - views 排除及方案條件。
  - 限制：需確認 team 啟用與實際設定。
- M02：[Search](https://linear.app/docs/search)
  - 定位
    - Search workspace。
    - Search specific views。
    - Q&A。
  - 用途
    - 搜尋範圍與 500 筆上限。
  - 限制：MCP 搜尋依實際工具能力。
- M03：[Delete and archive issues](https://linear.app/docs/delete-archive-issues)
  - 定位
    - Auto-close。
    - Auto-archive。
    - Restore issues。
  - 用途
    - 時間與關聯條件。
  - 限制：需讀取實際環境設定。
- M04：[Create issues](https://linear.app/docs/creating-issues)
  - 定位
    - Create an issue via email。
    - Create recurring issues。
  - 用途
    - Email 通知行為。
    - Recurrence 排程。
  - 限制：Agent 管理能力需另行核對。
- M05：[Customer Requests](https://linear.app/docs/customer-requests)
  - 定位
    - Add requests to issues or projects。
  - 用途
    - 回饋來源與工作關聯。
  - 限制：需確認指定整合及讀者可見性。
- M06：[Initiative and Project updates](https://linear.app/docs/initiative-and-project-updates)
  - 定位
    - Overview。
    - Create Initiative and Project updates。
  - 用途
    - 健康指標及文字說明。
  - 限制：健康判斷仍需由交付證據支持。
- M07：[Issue status](https://linear.app/docs/configuring-workflows)
  - 定位
    - Configure。
    - Duplicate issue status。
  - 用途
    - Team workflow。
    - 系統 duplicate 狀態。
  - 限制：原生狀態與工具回傳表達需分別核對。

### 補充查證

查證日期：2026-09-13。

- Duplicate 類別以 M09 的專用 status type 為採用依據。
  - M01 的 Take actions 仍描述 Canceled type。
  - M09 的 2026-05-21 更新明示專用類別。
- M07 的 Duplicate issue status：重讀系統管理的 Duplicate 名稱。
- M08：[GitHub](https://linear.app/docs/github#automatic-pr-cancellation)
  - 定位：Automatic PR Cancellation。
  - 用途：直接取消與標記 duplicate 對 PR 的影響。
  - 限制：需核對實際 PR 關聯及其他 open issue。

- M09：[Project Slack channels](https://linear.app/changelog/2026-05-21-project-slack-channels#issue-duplicates)
  - 發布日期：2026-05-21。
  - 定位：Issue duplicates。
  - 用途
    - Duplicate 專用類別。
    - Context 移轉至 canonical。
  - 限制：移轉前需確認 canonical 存取範圍。

## 相關規範

- [生命週期指南](issue-lifecycle.md)：完成條件與狀態映射。
- [生命週期的重開規則](issue-lifecycle.md#7-重開)：原承諾缺口與新需求的分流。

- [documentation.md](documentation.md)：權威位置與具名維護者。
- [Project update 範本](../assets/templates/project-update.md)：健康判斷與整體交付變化。
- [documentation.md 的更新與失效](documentation.md#更新與失效)：失效判斷與歷史快照處理。
- [寫作規則](writing.md)：Issue 內文與工作紀錄的寫作政策。

開始維護時讀取目標 issue 的最新內容，選擇本次檢查範圍。
需要配置功能時，完成「採用前確認」的對應項目。
