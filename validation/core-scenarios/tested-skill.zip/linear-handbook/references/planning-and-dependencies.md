# Milestone 與相依排程

適用情境：個人開發者＋多個 Agent。
查證日期：2026-09-13。

- 規畫輸入：[從需求建立 Project](project-planning.md)。
- 成果欄位：[Project brief](../assets/templates/project-brief.md)。

## 功能選擇

| 需要回答的問題 | 選擇 | 使用範圍 |
| --- | --- | --- |
| 這個 Project 到哪個成果階段？ | Milestone | Project 內的階段與所屬 issues。[S1] |
| Team 這段時間安排哪些工作？ | Cycle | 固定時間區間的工作安排。[S2] |
| 哪項 issue 必須先提供成果？ | Issue dependency | `Blocks` 與 `Blocked by` 表達方向。[S3] |
| 哪個 Project 結束後另一個才能開始？ | Project dependency | Project 層級的 end → start 關係。[S4] |
| 目前能同時承接多少工作？ | WIP 管理 | 本指南建議的工作量政策，見下節。 |

### 功能事實

- Milestone
  - 可在 Project overview 建立並加入描述。[S1]
  - 目標日期可選填。[S1]
  - 同一 milestone 無法跨 Projects 共用。[S1]
  - 進度百分比反映所屬 issues 的狀態。[S1]
  - 多個 milestones 可並行，黃色焦點可忽略。[S1]
- Cycle
  - 在 Team Settings 的 Cycles 啟用。[S2]
  - 採重複的時間安排。[S2]
  - 不與 release 綁定。[S2]
  - 已分配的未完成 issues 通常自動移入下一個 cycle。[S2]
  - Cooldown 期間改為 backlog 的 issue 不移入下一個 cycle。[S2]
  - Cooldown 期間改為 triage 的 issue 不移入下一個 cycle。[S2]
  - Cooldown 期間取消或完成的 issue 不移入下一個 cycle。[S2]
- Issue dependency
  - Issue 的選單可新增關係。[S3]
  - 官方 UI 說明：blocker 解決後，關係移到 Related。[S3]
- Project dependency
  - 從 Project 選單的 Dependencies 建立。[S4]
  - Timeline 可顯示阻塞關係。[S4]

## 從成果安排工作

以下流程是 handbook 建議。

### 1. 定義 Milestone 的成果

- 輸入
  - Brief 的成功標準。
  - 已確認範圍。
- 操作
  1. 以可驗收階段命名 milestone。
  2. 為每個階段寫出完成結果。
  3. 列出驗證方式。
  4. 在 milestone 描述保留整體驗收。
  5. 依排程依據設定目標日期。
- 完成條件
  - [ ] 每個 milestone 的成果可判定。
  - [ ] 日期有依據時才用作交付目標。

### 2. 拆出可交接的 Issues

- 輸入
  - Milestone 的成果與驗收。
- 操作
  1. 以可獨立驗收的交付拆分 issue。
  2. 列明輸入入口。
  3. 指定負責角色。
  4. 寫出成果位置。
  5. 寫出驗收步驟。
  6. 將每項歸入對應 milestone。
- 完成條件
  - [ ] 下一個 session 能找到必要上下文。
  - [ ] 每個 issue 都有可判定的完成結果。

### 3. 判斷真正的 Blocker

對每個前置逐項確認：

1. 缺少哪個具體輸入會使本項無法交付？
2. 哪項工作負責提供這個輸入？
3. 輸入何時可用，需符合什麼條件？
4. 能否拆出不依賴它的部分先做？

- 必須等待可用輸入時，建立 `Blocked by`。
- 只有背景關聯時，使用 `Related`。
- 只是同屬一個 milestone，不足以判定相依。
- 只是優先順序較低，不足以判定相依。
- 多個 Agent 修改同一檔案時，先協調執行範圍。
  - 若屬寫入衝突，用工作分配處理。
  - 若後項需要前項的新介面，記錄成果相依。
- 前置只完成一部分時，拆出可驗收的共用契約。
  - 依賴該契約的工作連到契約 issue。
  - 整合驗收仍依賴完整實作。
- 形成循環相依時，先檢查是否誤設 blocker。
  - 若雙方需要同一份規格，抽出共用契約作為前置。
  - 重新核對關係後，確認至少有一項工作可以開始。

使用工具接手時，讀取每個前置的目前狀態並查看成果。
關係清單非空時，仍需依目前狀態與成果判斷必要輸入是否可用。
前置被取消時，也要確認輸入已由其他成果取代，或需求已經移除。

### 4. 選擇可執行工作與控制 WIP

WIP 在本指南指已開始且尚未完成的執行工作。
審閱中的交付仍占用容量。
等待 blocker 的工作另標等待原因，仍計入已開始工作，避免持續開新項目隱藏壅塞。

1. 先讀 issue 最新內容。
2. 核對必要前置的狀態與成果。
3. 確認執行者有必要存取與授權。
4. 確認當前沒有重複承接者。
5. 確認剩餘執行容量。
6. 確認後續審閱容量。
7. 從可執行集合選擇最能解除後續阻塞的工作。
8. 若解除阻塞的效益相近，再依交付期限與優先級選擇。

- WIP 上限由採用者設定。
  - 可從每位執行者一項開始，依實際周轉調整。
  - 多個 Agent 共用同一審閱者時，需共同控制待審數量。
  - Agent 數量增加不代表審閱容量增加。
- 達到上限時，優先完成或解除既有工作阻塞。
- 需要插入緊急工作時，記錄被延後項目的恢復條件。
- 容量以實際執行 issue 計算，聚合用途的 parent 不重複計數。

### 5. 放入 Cycle 並重新規畫

本節適用於已使用 Cycle 的 Team。
未使用 Cycle 時，沿用前述成果與容量判斷安排工作。

- 輸入
  - 可執行工作清單。
  - 已確認的 WIP 上限。
  - Team 的 Cycle 設定。
- 操作
  1. 依可用容量選入當期工作。
  2. 將尚需前置的候選工作標清啟動條件。
  3. 前置完成時重新核對成果，再承接候選工作。
  4. 發現延誤時更新影響的 issue。
  5. 若影響 milestone 交付，更新其目標與原因。
  6. Cycle 結束後逐項檢查移入下期的未完成工作。
  7. 重新判斷它們是否值得繼續占用容量。
- 完成條件
  - [ ] 當期工作有足夠輸入可開始。
  - [ ] 候選工作與已承接工作可區分。
  - [ ] 移入下一期後重新核對容量。

## 跨 Milestone 示範：工時 CSV 匯出

以下為假設排程，以紙上推演說明選擇方法。
工作代號是案例標記。
WIP 上限與時間安排均為示範設定。

- Project 成果：使用者取得指定日期範圍的工時 CSV。
- M1：CSV 資料能力可用。
  - [ ] 已知工時資料與 API 產出的 CSV 逐筆一致。
- M2：使用者可完成下載。
  - [ ] 使用者透過介面取得指定日期範圍的 CSV。
    1. 準備跨日期範圍的已知資料。
    2. 在介面指定其中一段日期。
    3. 下載並核對檔案內容。
- 角色
  - Agent A：API 與整合驗證。
  - Agent B：介面。
  - 維護者：審閱交付。
- 示範容量
  - 每個 Agent 同時一項執行工作。
  - 待審交付最多一項。

| 代號 | Milestone | 可驗收交付 | 必要前置 | 負責角色 |
| --- | --- | --- | --- | --- |
| A | M1 | CSV API 契約有欄位定義與回應範例 | Brief | Agent A |
| B | M1 | API 輸出通過已知資料比對 | A 的可用契約 | Agent A |
| C | M2 | 介面依契約送出日期並處理模擬回應 | A 的可用契約 | Agent B |
| D | M2 | 介面接入實際 API 並通過 M2 驗收 | B 與 C 的交付 | Agent A |

### Cycle 1

1. Agent A 完成 A，由維護者確認契約可用。
2. B 與 C 同時開始。
3. B 和 C 分別使用已確認的契約。
4. 審閱容量滿時，先完成現有審閱或返工。
5. 另一項交付保留待審並計入 WIP。
6. 容量釋放後再送審。

- 真正 blocker
  - A 未可用前，B 缺少輸出規格。
  - A 未可用前，C 缺少可依循的 API 契約。
  - B 未完成時，D 缺少可用 API。
  - C 未完成時，D 缺少可整合介面。
- 可並行
  - A 完成後，B 與 C 沒有彼此的成果相依。
  - C 屬於 M2，仍能在 M1 尚未完成時進行。
  - C 使用模擬回應的驗收只涵蓋介面行為。
  - 完整下載成果仍由 D 驗收。

### Cycle 1 到期時的假設狀態

- B 已完成並通過資料比對。
- C 還缺錯誤回應處理。
- D 尚未開始。

依此狀態判斷：

1. M1 的成果已達成。
2. M2 的成果尚未達成。
3. C 按一般 rollover 行為移入下一個 cycle。[S2]
4. D 仍等待 C，保留啟動條件。
5. 維護者重新確認 C 的剩餘範圍。
6. Cycle 2 先完成 C，再承接 D。
7. 若 M2 的目標日期受影響，更新交付預期。

### Cycle 到期與成果完成

| 判斷對象 | 依據 | 後續操作 |
| --- | --- | --- |
| Cycle 到期 | 時間區間結束。[S2] | 檢查 rollover 後的工作容量。 |
| Issue 完成 | 本項驗收結果與成果證據。 | 回填成果並更新狀態。 |
| Milestone 成果完成 | 階段驗收成立。 | 核對整體結果，記錄成果入口。 |
| Project 完成 | Brief 的成功標準成立。 | 依採用者的驗收流程結案。 |

上表的成果判斷與後續操作是 handbook 建議。
Milestone 百分比可協助掌握狀態，仍需核對階段驗收是否涵蓋實際成果。

## 採用者配置

下列選擇由採用者確認並記錄為自己的工作政策。

- WIP 上限。
- 審閱容量。
- 緊急工作插入方式。
- 等待工作恢復條件。
- Cycle 使用週期。
- 成果驗收責任。

## 來源記錄

發布者均為 Linear。
查證日期：2026-09-13。
證據狀態：文件已確認。

- S1：[Project milestones](https://linear.app/docs/project-milestones)
  - `Create milestones`：建立與日期選填。
  - `Milestones progress`：依 issue 狀態顯示進度。
  - `FAQ`：跨 milestone 並行。
  - `FAQ`：milestone 無法跨 Projects 共用。
- S2：[Cycles](https://linear.app/docs/use-cycles)
  - 頁首：Team 工作時間區間。
  - `Configure`：Team 設定入口。
  - `Cycle duration`：重複安排。
  - `Issues rollover`：未完成工作的移轉與例外。
- S3：[Issue relations](https://linear.app/docs/issue-relations)
  - `Add relationships`：建立關係。
  - `Blocked / blocking`：方向與解決後的 UI 顯示。
- S4：[Project dependencies](https://linear.app/docs/project-dependencies)
  - `Overview`：end → start 限制。
  - `Create a project dependency`：選單入口。
  - `View project dependencies`：timeline 顯示。

[S1]: https://linear.app/docs/project-milestones
[S2]: https://linear.app/docs/use-cycles
[S3]: https://linear.app/docs/issue-relations
[S4]: https://linear.app/docs/project-dependencies
