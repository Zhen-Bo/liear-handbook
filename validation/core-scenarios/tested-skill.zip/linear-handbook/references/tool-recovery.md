# 寫入驗證與工具恢復

讓 Agent 在結果不完整時辨認已完成的操作，從可確認的進度繼續。
適用於個人開發者與多個 Agent 使用 Linear 的情境。

- 工作認領與併發衝突處理見 [多 Agent 協作](multi-agent-coordination.md)。
- 授權與敏感資訊處理見 [Agent 邊界](agent-boundaries.md)。
- 介面能力與查證方法見 [工具能力研究](agent-tool-capabilities.md)。

本文的恢復步驟是建議流程。
官方功能事實另列來源。
connector 欄位依當前宣告確認。

## 結果判定

| 判定 | 必要證據 | 下一步 |
| --- | --- | --- |
| 已確認成功 | 以目標 ID 讀回，必要欄位符合本次預期 | 保存證據，繼續下一步 |
| 已確認失敗 | 明確拒絕或未套用的證據，且已排除其他步驟成功 | 修正原因後判斷是否重試 |
| 結果未知 | 逾時、斷線或缺少必要回傳，無法確認是否套用 | 查證遠端結果，暫停依賴此結果的寫入 |
| 部分成功 | 至少一個步驟已確認成功，其他步驟失敗或未知 | 逐步核對，只恢復尚未完成的步驟 |

HTTP 200 不足以判定 GraphQL 成功。
官方 API 可能同時回傳資料與 `errors`。
應核對錯誤路徑及必要欄位。[S1]
Connector 回傳若未暴露 HTTP 或 GraphQL 細節，使用可取得的工具錯誤與物件讀回結果，不補猜缺失欄位。

工作完成須滿足 issue 的驗收條件。
失敗或未知結果不得寫成完成，也不得用 Done 隱藏待恢復步驟。

## 寫入前準備

1. 讀取本次授權的操作範圍。
2. 查閱實際可呼叫工具的最新宣告。
3. 以已知 ID 讀取目標物件。
4. 比對回傳的 workspace 與 Team。
5. 比對物件的用途與所屬 parent 或 Project。
6. 讀取此次會修改的最新欄位。
7. 保存本次修改差異。
8. 為每個寫入步驟列出可讀回的成功條件。

名稱只用於尋找候選物件。
遇到同名或範圍不符時，停止該次寫入並取得正確 ID。
官方 API 的 issue 操作支援 UUID 或 issue identifier，其他物件應依各介面契約處理。[S1]

對可能中斷的工作，將恢復記錄保存在下一個 session 可讀取的位置：

- 操作識別：本次工作與步驟的穩定識別值。
- 目標：已解析的物件 ID。
- 預期：本次欲修改的欄位值或內容差異。
- 基準：讀取時間與遠端 `updatedAt`（若有）。
- 進度：最後確認成功的步驟。
- 回傳：已取得的新物件 ID。
- 錯誤：去除敏感資訊後的錯誤代碼與原因。
- 查證：讀回的結果與時間。
- 恢復：下一個可執行動作。

短期簽名 URL 不作永久成果入口。
恢復記錄不保存 token 或簽名。
需要存取檔案時重新取得有效網址。

## 建立前去重

1. 若已有目標 ID，直接讀取該物件。
2. 尚無 ID 時，在正確範圍搜尋相同用途的候選物件。
3. 依「完整分頁」走完必要查詢。
4. 讀取候選內文，核對工作目標。
5. 發現同一工作時，沿用已確認的 ID。
6. 多個候選無法區分時，停止建立並釐清對應關係。
7. 確認首次建立確有必要後，保存操作識別及查詢範圍再送出建立。
8. 取得回傳 ID 後立即保存，並以該 ID 讀回。

標題相同不等於相同工作。
搜尋未命中也不證明物件不存在，可能受到可見權限或搜尋範圍影響。
官方 API 分頁預設隱藏 archived 資料。
查重應依必要範圍納入 archived，connector 的參數須另外確認。[S1]

去重識別值只協助追查。
除非介面明確提供相應契約，不能當成服務端 idempotency key 或唯一性約束。
首次建立前的查重也不能防止另一 Agent 同時建立。
認領應依協作協議完成。

## 更新與讀回

1. 更新前重新讀取目標。
2. 與保存的基準比對。
3. 若他人已修改同一內容，先合併差異或依協作協議解決衝突。
4. 只提交本次必要修改。
5. 檢查工具回傳中的錯誤。
6. 以目標 ID 讀回必要欄位。
7. 內容寫入核對完整文字，保留清單層級與連結語意。
8. 關係變更依需求讀取兩端，確認方向正確。
9. 讀回一致後，記錄該步已確認成功。

若寫回完整 description，必須將他人新增內容納入最新版本。
若使用 patch，先核對 anchor 是否仍符合目前內容。
使用 patch 前查目前工具的版本條件、idempotency 與失敗契約。
沒有明確契約時，不推定寫入可安全重放。
讀前比對與 patch 都不能保證兩個寫入之間沒有競爭。

讀回失敗時，將寫入結果列為未知並重試讀取。
讀回與預期不同時，先辨認平台格式正規化或其他寫入造成的差異。
持續衝突時停止該欄位寫入，保留最新遠端內容與本次差異交接，避免循環覆寫。

## 完整分頁

官方 GraphQL 使用 `first/after`，下一頁來自 `pageInfo.endCursor`，依 `hasNextPage` 判斷是否繼續。[S2]
Connector 的列表參數與回傳結構逐工具核對。

1. 保存完整 filter 與排序設定。
2. 讀取第一頁，檢查回傳是否完整。
3. 以物件 ID 去重並保存本頁結果。
4. 保存成功頁面的下一頁 cursor。
5. 有下一頁時，使用原查詢條件與回傳 cursor 繼續。
6. 明確讀到沒有下一頁，才將本次查詢列為走完。
7. 查詢期間資料可能改變時，重讀候選目標或查詢期間更新的資料。

- 中間頁逾時。
  1. 使用最後成功頁面的下一頁 cursor 重讀失敗頁。
  2. 以 ID 合併結果。
- Cursor 失效。
  1. 從第一頁重查相同條件。
  2. 與既有 ID 去重。
- Cursor 重複或未前進。
  1. 停止迴圈並保存異常回傳。
  2. 重新查詢一次。
  3. 仍異常則交接查詢缺口。
- 有下一頁但缺 cursor。
  1. 判為查詢不完整。
  2. 重新讀取該頁。
  3. 仍缺漏則停止依賴完整集合的操作。
- 空頁但標示有下一頁。
  1. 核對 cursor 有效且前進。
  2. 繼續查詢，不能以空頁當結束。
- 權限不足。
  1. 依「權限不足」恢復。
  2. 保留資料可見範圍缺口，不將不可見資料當作不存在。

分頁走完不代表取得同一時間點的快照。
資料持續變動而無法穩定核對時，保留查詢時間範圍與缺口，不宣稱完整匯出。

## 逾時與連線失敗

### 建立結果未知

1. 暫停建立重試。
2. 檢查原請求是否仍執行中，取得可用的最終回傳。
3. 有回傳 ID 時，直接以 ID 讀取。
4. 沒有 ID 時，列出原建立範圍的候選物件並走完必要分頁。
5. 以操作識別與建立時間縮小候選。
6. 逐項核對候選的目標內容與歸屬。
7. 找到已建立物件時，保存 ID 並從下一步繼續。
8. 多個候選時停止建立，交接重複物件供判斷。
9. 仍找不到時，以延後讀取或已授權的直接物件列表補查一次。
10. 無法排除已建立時，保留「結果未知」並交接查證。

只有取得明確未套用的證據，或介面提供可驗證的安全重放契約時，才重送同一建立意圖。
不得僅因搜尋未命中就重新建立。
Comment 新增與 attachment row 建立也遵循此規則。

### 更新結果未知

1. 以原目標 ID 讀取最新欄位。
2. 已達預期時記錄成功，不重送。
3. 與基準一致且可確認尚未套用時，重新核對授權與最新內容後重試必要差異。
4. 與基準或預期皆不同時，依更新衝突處理。
5. 持續無法讀取時保存未知狀態，停止後續相依操作。

Append comment 或非冪等副作用不能套用一般欄位重寫策略。
伺服器 5xx 或 connector 中斷不自動證明 mutation 未執行。

## 限流

官方 GraphQL 以 HTTP 400 與 `errors` 中的 `RATELIMITED` 表達限流。[S3]
API 的 request 與 complexity 額度各有 reset headers。
特定 endpoint 也可能有獨立限制。[S3]
Connector 可能轉換錯誤格式，應檢查其實際回傳，不只比對 HTTP 429。

1. 暫停同一憑證範圍的後續請求，包含查證用讀取。
2. 保存已完成步驟與 cursor。
3. 若回傳可用的 reset 時間，依其單位換算並等到相關限制解除。
4. 若缺 reset 資訊，採有限次退避。
5. 恢復後先查證最後一次寫入結果。
6. 從尚未完成的步驟繼續。

優先沿用環境既有退避政策。
尚無政策時，可採以下可調整的建議值，每次另加 0–5 秒隨機延遲：

1. 首次等候 5 秒。
2. 第二次等候 15 秒。
3. 第三次等候 30 秒。

連續三次仍受限即保存進度，交由後續排程或可處理連線的人接手。
這些數值是本流程建議，並非 Linear 保證的 reset 時間。

若是單次 query complexity 過高，縮小所需欄位或每頁數量再試。
等待不會修正固定超過單次 complexity 上限的查詢。[S3]
多個 Agent 共用同一使用者 API key 額度時，應協調降低請求量。
替換同使用者的 key 不會分離該額度。[S3]

## 權限不足與輸入錯誤

### 權限不足

1. 保存去敏後的錯誤與目標 ID。
2. 確認目前連線的身分與 workspace。
3. 確認操作需要的 scope。
4. 確認目標物件在連線可見範圍內。
5. 若為官方 MCP，檢查是否連到唯讀 endpoint。[S4]
6. 交由有權處理連線的人修復必要存取權。
7. 權限恢復後先讀取目標最新狀態。
8. 從尚未完成且已授權的步驟繼續。

OAuth 的讀取與寫入 scopes 分開，建立 issue 與新增 comment 也有各自 scope。[S5]
讀取成功不代表寫入可用。
找不到物件時先核對 ID 與可見範圍，不自動改到別的 Team 建立替代品。
不得自行升權或切換其他身分繞過拒絕。

### 輸入或 schema 錯誤

1. 查閱目前工具宣告與具體欄位錯誤。
2. 重新解析正確目標 ID。
3. 依最新內容修正必要輸入。
4. 若錯誤來自 anchor 不符，重新讀取全文再產生 patch。
5. 確認未套用後才提交修正版。

相同輸入遭明確驗證拒絕時，不以重試次數取代修正。

## 部分成功

1. 將整體操作拆成可讀回的步驟。
2. 逐步標記成功、失敗或未知。
3. 保存成功步驟的新物件 ID。
4. 查證未知步驟。
5. 修復失敗原因。
6. 只執行尚未完成的必要步驟。
7. 重新核對整體驗收條件。

例如 issue 已建立，但關係設定失敗：

1. 用已取得 ID 讀回 issue。
2. 讀取目前關係。
3. 確認工具的新增或取代語意。
4. 補上缺少的已授權關係。
5. 讀回兩端確認方向。

跨工具操作沒有已確認的整體交易保證。
不得因後一步失敗就重跑整組建立，也不得自動刪除已成功物件當作回滾。
補償操作需另外確認影響與既有授權。

### 附件交付

僅當目前 connector 明確提供 prepare → raw PUT → attachment row 的協定時，才使用以下流程。
若介面提供單步上傳，依該契約操作並讀回檔案。
缺少上傳能力時保留本地成果與具體交付需求。

1. 保存本地檔案大小與 SHA-256。
2. Prepare 取得上傳請求。
3. 依回傳 headers 原樣 PUT 原始 bytes。
4. PUT 確認成功後，以 assetUrl 建立 attachment row。
5. 保存 attachment ID。
6. 讀回 issue 的附件。
7. 下載該附件，比對大小與 SHA-256。

- Prepare 成功，PUT 明確失敗或 URL 過期。
  1. 重新 prepare 同一檔案。
  2. 按新回傳完成 PUT。
- PUT 結果未知。
  1. 暫停 finalize。
  2. 查證 asset 是否可讀且 bytes 相同。
  3. 無法證明上傳成功時重新 prepare 及 PUT。
  4. 記錄舊 asset 可能殘留。
- PUT 成功，finalize 明確失敗。
  1. 保存已上傳 asset 的識別。
  2. 修正失敗原因。
  3. 只恢復 attachment row 建立。
- Finalize 結果未知。
  1. 讀取目標附件。
  2. 依 asset 的穩定路徑定位候選，單憑同名不足以認定成功。
  3. 下載核對內容。
- 下載 URL 過期。
  1. 重新取得該 attachment ID 的下載 URL。
- 下載內容不一致。
  1. 保留失敗證據並停止宣告交付成功。
  2. 確認來源 bytes。
  3. 修復附件。

依當前 prepare 回傳確認 URL 時效與 headers，逐一 prepare → PUT → finalize。
Prepare 回傳 URL 只代表可開始上傳。
Finalized row 尚未讀回時，也不能宣稱檔案已完成交付。

## 來源

查證日期：2026-09-13。
官方文件發布者均為 Linear。

- S1：[Getting started](https://linear.app/developers/graphql)。
  - Error handling。
    - HTTP 200 可包含部分資料與錯誤。
  - Queries & Mutations。
    - 支援物件 ID 查詢。
  - Creating & Editing Issues。
    - 建立回傳包含新 issue ID。
  - Archived resources。
    - API 分頁預設排除 archived。
- S2：[Pagination](https://linear.app/developers/pagination)。
  - Relay cursor 範例。
    - `pageInfo` 控制下一頁。
  - `orderBy` 範例。
    - 可依 `updatedAt` 排序。
- S3：[Rate limiting](https://linear.app/developers/rate-limiting)。
  - API request limits。
    - 相同使用者的 API keys 共用額度。
    - 回傳 headers 提供 reset 資訊。
  - Query- and mutation-specific request limits。
    - Endpoint 可有獨立限制。
  - Complexity limits。
    - 複雜度有獨立額度。
  - Maximum complexity。
    - 固定超過單次上限的查詢會遭拒。
  - Handling rate limit errors。
    - GraphQL 限流回傳 HTTP 400。
    - 錯誤代碼為 `RATELIMITED`。
- S4：[MCP server](https://linear.app/docs/mcp)。
  - Setup → General。
    - 唯讀 endpoint 只暴露讀取工具。
    - `read` scope 限制寫入存取。
- S5：[OAuth 2.0 authentication](https://linear.app/developers/oauth-2-0-authentication)。
  - Redirect user access requests to Linear → scope。
    - 各操作 scope 分離。
[S1]: https://linear.app/developers/graphql
[S2]: https://linear.app/developers/pagination
[S3]: https://linear.app/developers/rate-limiting
[S4]: https://linear.app/docs/mcp
[S5]: https://linear.app/developers/oauth-2-0-authentication
