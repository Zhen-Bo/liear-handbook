# Project update 範本

用於說明 project 整體交付的變化。
單項操作細節放在 [issue comment](progress-comment.md)。

## 使用時機

以下為使用建議。

- 既定更新日：摘要自上次 update 以來影響交付的變化。
  - 沒有新增資訊時，完成進度檢查即可。
- 關鍵里程碑達成：說明已可使用的成果。
- 交付風險改變：說明受影響目標與應對操作。
- 範圍或日期定案：說明新的承諾與採用理由。
- Project 完成：摘要整體成果與驗收入口。

更新頻率由 project lead 依協作需求決定。
單項 issue 的細節用連結支援整體判斷。
目前有效的 project 範圍同步更新 overview。
Issue 的目前結論同步更新各自 body。

## 使用方式

1. 在更新介面選擇 health。
2. 複製精簡版並替換 `{…}`。
3. 保留影響整體交付的內容。
4. 刪除不適用的段落。

以下為 health 判斷建議，依所在專案的承諾調整。

- On track：現有證據支持仍可達成承諾。
- At risk：已有具體風險可能使承諾落空。
- Off track：目前已偏離承諾，需要調整方案或目標。

Health 需附理由。
完成項目比例不直接決定 health。
預估與已觀察結果分開表達。

## 精簡版

```markdown
## 結果摘要

- 期間：{上次更新至本次更新的日期。}
- Health 理由：{支持所選 health 的具體證據。}
- 目標：{目前承諾的交付日期或里程碑。}

## 完成項目

1. {已交付且影響 project 的成果，附入口。}

## 風險與決策

- {風險主題。}
  - 事實：{已觀察結果與證據。}
  - 預估影響：{尚未發生的交付影響。}
  - 應對：{已採用操作。}
  - 理由：{採用依據。}
  - 負責人：{具名責任人。}
  - 檢查點：{重新判斷風險的日期或事件。}

## 下一步

- {下一個具體成果。}
  - 工作：{插入原生 issue mention。}
  - 負責人：{具名責任人。}
  - 預計：{完成日期。}
```

## 填寫案例

以下為虛構示範。
實際使用時將證據名稱替換成可存取的入口。

介面選擇：At risk。

```markdown
## 結果摘要

- 期間：2026-09-07 至 2026-09-11。
- Health 理由：跨頁匯出仍遺漏資料，可能影響試用日期。
- 目標：2026-09-16 提供任務 CSV 匯出試用。

## 完成項目

1. 匯出按鈕已整合至列表頁，成果見 project Resources 的「CSV 試用展示」。
2. 欄位格式確認完成，依據見 project Resources 的「EXPORT-01 核定需求」。

## 風險與決策

- 跨頁資料遺漏
  - 事實：export-rc1 只輸出 200 筆測試資料中的 100 筆。
  - 證據：匯出 issue 附件 export-rc1-tests.txt，pagination FAIL。
  - 預估影響：若 9 月 14 日前未修復，9 月 16 日試用可能延後。
  - 應對：先依請求紀錄查明資料遺漏位置，修正後進行試用驗收。
  - 理由：完整篩選結果是 EXPORT-01 的必要驗收。
  - 負責人：陳怡安。
  - 檢查點：2026-09-14 的跨頁驗收結果。

## 下一步

- 完成跨頁匯出修正。
  - 工作：在此插入跨頁修正工作的原生 issue mention。
  - 負責人：陳怡安。
  - 預計：2026-09-14。
```

## 配置說明

### 功能事實

查證日期：2026-09-13。

- Project update 包含 health indicator 與 rich text description。
  - 來源：[Initiative and Project updates — Overview](https://linear.app/docs/initiative-and-project-updates#overview)。
- Health 選項
  - On track。
  - At risk。
  - Off track。
  - 來源：[Create Initiative and Project updates](https://linear.app/docs/initiative-and-project-updates#create-initiative-and-project-updates)。
- 最新 update 顯示於 Project Overview。
  - 來源：[View Initiative and Project updates](https://linear.app/docs/initiative-and-project-updates#view-initiative-and-project-updates)。
- 過往 updates 可在 Updates tab 查閱。
  - 來源：[View Initiative and Project updates](https://linear.app/docs/initiative-and-project-updates#view-initiative-and-project-updates)。


## 寫作預設

依 [writing](../../references/writing.md) 維護格式、證據與 issue 目前結論。
