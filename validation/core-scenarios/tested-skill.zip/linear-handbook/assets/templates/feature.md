# Feature issue body 範本

適用於交付使用者原本無法完成的新能力。
類型依據：[工作類型指南 — Feature](../../references/issue-types.md#feature)。

## 使用方式

1. 將標題填入 issue title。
2. 複製精簡版作為 issue body，替換 `{…}`。
3. 有多個關鍵流程時，逐項補上可觀察的驗收結果。
4. 刪除填寫後無用途的空欄與指示。

尚未採用的需求另列待決問題，說明會影響的成果。
有獨立交付的部分，依 [工作拆分指南](../../references/issue-types.md#issueparent-與-project-選擇) 判斷是否建立 sub-issues。

## 精簡版

標題：`讓 {使用者} 能 {完成的新任務}`

```markdown
## 需求

{目標使用者目前遇到的限制。}

- 使用者：{具體角色。}
- 情境：{何時需要這項能力。}
- 成果：{完成後使用者能做到什麼。}

## 範圍

- {本項交付的能力邊界。}

## 驗收

- [ ] {主要流程的可觀察結果。}
- [ ] {指定失敗情境的處理結果。}

## 依據

- {已採用需求的來源與定位。}
```

## 填寫案例

以下為虛構產品案例，示範填寫完成的需求與驗收。

標題：`讓專案管理者能匯出目前篩選的任務為 CSV`

```markdown
## 需求

專案管理者每週需將任務清單交給外部合作方，目前只能逐筆複製。

- 使用者：具有專案讀取權限的專案管理者。
- 情境：在任務列表完成篩選後，準備週會資料。
- 成果：取得包含目前篩選結果的 CSV 檔案。

## 範圍

- 匯出目前篩選條件下的全部任務。
- 依目前列表的排序輸出。
- 使用 UTF-8 編碼。
- 輸出欄位
  - 任務 ID。
  - 標題。
  - 狀態。
- 無篩選結果時，匯出按鈕停用。
- 匯出失敗時，提供重試入口。

## 驗收

- [ ] CSV 只包含符合篩選的 3 筆待處理任務。
  1. 建立 3 筆待處理任務與 2 筆已完成任務。
  2. 篩選待處理任務並依 ID 升冪排序。
  3. 執行匯出。
  4. 以 CSV 解析器讀取後，確認資料恰為該 3 筆待處理任務。
- [ ] CSV 的任務順序與列表的 ID 升冪排序一致。
- [ ] 每筆資料含指定的 3 個欄位。
- [ ] 中文標題經 UTF-8 解碼後與原值一致。
- [ ] 標題中的逗號經 CSV 解析後仍保留於同一欄位。
- [ ] 無符合條件的任務時，匯出按鈕停用。
- [ ] 匯出失敗後可重試成功。
  1. 讓匯出請求回傳 500。
  2. 確認顯示「匯出失敗，請重試」。
  3. 恢復服務後按重試。
  4. 確認取得符合原篩選條件的檔案。

## 依據

- 需求記錄：EXPORT-01「週會任務清單」，2026-09-10 核定版本。
```

## 配置說明

### 功能事實

查證日期：2026-09-13。

- Standard template 可預填 issue 屬性與 description。
  - 來源：[Linear Issue templates — Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates)。
- Workspace template 不能預設 team 專用的 labels。
  - 來源：[同章節](https://linear.app/docs/issue-templates#create-standard-issue-templates)。
- Workspace template 不能預設 team 專用的 issue status。
  - 來源：[同章節](https://linear.app/docs/issue-templates#create-standard-issue-templates)。

### 使用建議

- 將本檔的精簡版作為內文起點。
- 按實際工作選擇 labels。
- 設定 template 時核對預設屬性的適用範圍。
- 交付後在內文補上成果入口。
- 在內文保留實際驗證結果的定位。


## 寫作預設

依 [writing](../../references/writing.md) 維護格式、證據與 issue 目前結論。
