# 研究 issue body 範本

適用於需要以證據作出下一步決策的工作。
分類依據：[工作類型指南](../../references/issue-types.md#研究)。

## 填寫說明

- 必要欄位
  - 問題與決策。
  - 範圍。
  - 時間上限。
  - 判斷準則。
  - 證據計畫。
  - 驗收條件。
  - 完成前補上採用結論與可定位的證據。
- 選填欄位
  - 影響決策的風險。
  - 有具體用途的相關工作。

### 填寫建議

1. 複製下方內文並替換所有占位文字。
2. 以需要作出的決策界定範圍。
3. 刪除不適用的選填欄位。
4. 將實際發現回填「結論與證據」。

- 時間上限是重新評估範圍的時點。
  - 到時仍缺必要證據，應補足證據或重新約定可獨立回答的問題。
  - 只列出資訊缺口不足以完成研究。
- 不可行可作為完成結論。
  - 證據須足以排除方案。
  - 結論須回答約定的決策。
- 來源記錄保留查證日期與章節定位。
  - 功能事實優先使用官方來源。
  - 實驗結果保留環境與資料入口。
  - 推論說明如何由證據得到結論。

- 研究成果須足以支持約定決策。
- 決策者與證據門檻依採用團隊調整。
- 本文件的「必要欄位」是撰寫建議。
  - 要在建立時強制填寫，可將這些欄位配置為 form template 必填欄位。

## 可複製內文

```markdown
## 問題與決策

<要回答的問題，以及答案將決定的下一步>

## 範圍

- 研究對象：<版本或情境>。
- 範圍上限：<本項處理到的邊界>。
- 時間上限：<截止時間或投入時數>。

## 判斷準則

1. <方案必須滿足的條件與門檻>。
2. <比較方案的另一項條件>。

## 證據計畫

- <來源或實驗>：回答<判斷準則>。

## 結論與證據

- 決策：<採用方案或不可行結論>。
- 理由：<證據如何滿足準則或排除方案>。
- 證據：<來源章節或實驗紀錄連結>。
- 查證日期：<YYYY-MM-DD>。
- 後續操作：<依結論採取的具體行動>。

## 驗收條件

- [ ] 約定問題已有足以作出決策的證據。
- [ ] 採用結論逐項對應判斷準則。
- [ ] 若結論為不可行，排除理由有可核對的證據。
- [ ] 阻止決策的必要資訊缺口已補齊。
```

## 填寫案例：選擇共用範本的作用範圍

以下以官方文件示範一份已完成的研究內文。
需求與時間上限為案例設定。

```markdown
## 問題與決策

一份供多個 team 使用的文字範本，應建立為 workspace template 或 team template？
本項決定共用範本的作用範圍。

## 範圍

- 研究對象：Linear standard issue template。
- 範圍上限：共用文字與 team 專用屬性的預設能力。
- 時間上限：官方文件查閱一小時。

## 判斷準則

1. 範本能供 workspace 中任何 team 使用。
2. 共用範本不需要預設 team 專用狀態。

## 證據計畫

- 查閱 Issue templates 的 Create standard issue templates 章節，核對作用範圍。

## 結論與證據

- 決策：採用 workspace template。
- 功能事實：workspace template 可用於 workspace 中任何 team。
- 功能限制：workspace template 不能預設 team 專用狀態。
- 推論：共用文字符合第一項準則。
- 推論：不能預設 team 專用狀態的限制不影響本案例需求。
- 證據：[Issue templates — Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates)。
- 查證日期：2026-09-13。
- 後續操作：將共用內文設定為 workspace template。

## 驗收條件

- [x] 官方文件明確支持跨 team 使用。
- [x] 已確認 team 專用狀態不能預設。
- [x] 採用結論符合兩項判斷準則。
```

若需求改為「同一份 workspace template 必須預設 team 專用狀態」，上述官方限制即足以支持不可行結論。
後續決策可改為接受建立時選擇狀態，或為各 team 建立 team template。

## Linear 功能依據

查證日期：2026-09-13。

- Standard template 可預填內文。[Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates)
- Form template 可將欄位設為必填。[Create form templates](https://linear.app/docs/issue-templates#create-form-templates)

## 其他類型的映射

依[各類工作的證據與完成條件](../../references/issue-types.md#各類工作的證據與完成條件)選擇最接近的基本範本，再替換驗收。

| 工作類型 | 基本範本 | 必須補入的驗收重點 |
| --- | --- | --- |
| 改善 | [Feature](feature.md) | 指定情境的改善門檻 |
| 技術債 | [重構](refactor.md) | 已知負擔消除的目標狀態 |
| 效能 | [Feature](feature.md) | 相同工作負載下的量測門檻 |
| 安全 | [Bug](bug.md) | 風險情境被阻擋的證據 |
| 文件 | [Feature](feature.md) | 指定讀者能完成的操作 |
| 測試 | [Feature](feature.md) | 測試能偵測指定錯誤 |
| 事故 | [Bug](bug.md) | 恢復指標與觀察期間 |
| 發布 | [遷移](migration.md) | 目標環境中的版本與健康檢查 |

- 已承諾行為的修復使用 [Bug 基本範本](bug.md)。
- 新能力交付使用 [Feature 基本範本](feature.md)。
- 類型映射不代表沿用全部欄位。
  - 依主要成果刪除不適用欄位。
  - 事故保留實際處置時間線。
  - 發布依適用情況改寫資料對帳欄位。

## 寫作預設

依 [writing](../../references/writing.md) 維護格式、證據與 issue 目前結論。
