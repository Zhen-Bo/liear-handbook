# Bug issue body 範本

適用於實際行為偏離已承諾行為的修正。
類型依據：[工作類型指南 — Bug](../../references/issue-types.md#bug)。

## 使用方式

1. 將標題填入 issue title。
2. 複製精簡版作為 issue body，替換 `{…}`。
3. 有多個受影響情境時，逐項補上環境與驗收。
4. 刪除填寫後無用途的空欄與指示。

根因尚未確定時，以可觀察的失敗描述問題。
需要保留假設時，另列支持證據與待驗證問題。

## 精簡版

標題：`修復 {觸發情境} 時 {可觀察的錯誤}`

```markdown
## 問題

{受影響使用者在什麼任務遇到什麼阻礙。}

- 實際：{觀察到的結果。}
- 預期：{已承諾的結果。}
- 依據：{規格或既有驗收的連結與章節。}

## 重現

- 版本：{受影響版本或 commit。}
- 環境：{影響重現的執行環境。}
- 前置：{帳號狀態或測試資料。}

1. {操作。}
2. {觸發錯誤的操作。}

## 範圍

- {本項修正的行為邊界。}

## 驗收

- [ ] {原失敗情境符合預期的可觀察結果。}
- [ ] {受影響路徑的具體回歸結果。}

## 證據

- {失敗紀錄的定位與觀察時間。}
```

## 填寫案例

以下為虛構產品案例，示範填寫完成的問題與驗收。

標題：`修復密碼重設連結過期時持續顯示載入畫面`

```markdown
## 問題

使用者開啟過期的密碼重設連結後，無法得知連結已失效。

- 實際：頁面持續顯示「載入中」。
- 預期：顯示「連結已過期，請重新申請」。
- 依據：需求記錄 AUTH-04，條件為重設連結建立 30 分鐘後失效。

## 重現

- 版本：Web 1.8.2。
- 環境：Windows 11 / Chrome 128。
- 前置：測試帳號已建立 31 分鐘前簽發的重設連結。

1. 在未登入的瀏覽器開啟該重設連結。
2. 等待重設 API 回傳 410 與 TOKEN_EXPIRED。

## 範圍

- 處理密碼重設頁收到 TOKEN_EXPIRED 的顯示結果。

## 驗收

- [ ] 過期連結顯示「連結已過期，請重新申請」。
  1. 開啟 31 分鐘前簽發的連結。
  2. 確認 API 回傳 TOKEN_EXPIRED。
  3. 確認載入畫面消失並顯示過期提示。
- [ ] 有效連結仍可完成密碼重設。
  1. 開啟 5 分鐘前簽發的連結。
  2. 設定符合密碼規則的新密碼。
  3. 使用新密碼登入成功。

## 證據

- 需求記錄：AUTH-04「密碼重設連結期限」。
- 失敗紀錄：附件 expired-reset.har，請求 /password/reset/validate。
- 觀察時間：2026-09-10 10:20 UTC+8。
```

## 配置說明

### 功能事實

查證日期：2026-09-13。

- Standard template 可預填 issue 屬性與 description。
  - 來源：[Linear Issue templates — Create standard issue templates](https://linear.app/docs/issue-templates#create-standard-issue-templates)。
- Form template 可將欄位設為必填。
  - 來源：[Linear Issue templates — Create form templates](https://linear.app/docs/issue-templates#create-form-templates)。

### 使用建議

- 將本檔的精簡版作為內文起點。
- 需要建立時必填的資訊，可改用 Form template。
- 修正後在證據區補上實際驗證入口。
- 程式證據使用固定版本的永久連結。


## 寫作預設

依 [writing](../../references/writing.md) 維護格式、證據與 issue 目前結論。
