---
name: linear-handbook
description: 在 Linear 規畫專案、拆分工作、撰寫與維護 issue、交接進度及恢復 Agent 操作。適用於個人開發者與多 Agent 協作，也可依環境政策擴充至小型團隊與產品營運。一般程式實作或與 Linear 無關的寫作不觸發。
---

# Linear handbook

將需求轉成可交付、可驗收、可接手的 Linear 工作。
依本次任務選流程，只讀需要的文件與範本。

## 執行

1. 判斷使用者要取得的成果與已授權操作。
2. 需要現況時，讀目標 issue 的目前內文、相關最新決策及必要前置成果。
3. 依任務路由載入對應流程。
4. 寫入前核對目標 ID、實際工具契約與已有授權。
5. 更新後讀回必要欄位與關係，以有效完成條件判斷成果。

- Issue body 保留目前目標、採用結論與成果入口。
- Comments 只記錄真正新增的資訊。
- 必要驗收未成立時，保持實際未完成階段。
- 流程建議不增加使用者未授權的操作，也不取代已確認的需求。
- 操作結果未知時，先走恢復流程，不重送非冪等建立。

## 任務路由

下列連結相對於本 `SKILL.md`。
不要按當前工作目錄解析。
範例中的產品檔案路徑是待替換的成果位置。

- 選物件與功能
  - 首先讀 [object-model](references/object-model.md)。
  - 遇功能或方案選擇時讀 [feature-coverage](references/feature-coverage.md)。
- 初始化或接手 Workspace
  - 首先讀 [workspace-setup](references/workspace-setup.md)。
  - 需要環境映射時讀 [policy](references/policy.md)。
  - 需要完整規畫例子時讀 [project-bootstrap](references/project-bootstrap.md)。
- 從想法規畫 Project
  - 首先讀 [project-planning](references/project-planning.md)。
  - 有階段、相依或容量問題時讀 [planning-and-dependencies](references/planning-and-dependencies.md)。
  - 產出 Brief 時讀 [project-brief](assets/templates/project-brief.md)。
- 分類或撰寫 issue
  - 首先讀 [issue-types](references/issue-types.md)。
  - 撰寫內容時讀 [writing](references/writing.md)。
  - 依主要成果選下方一份類型範本。
- 拆分大型工作
  - 首先讀 [issue-decomposition](references/issue-decomposition.md)。
  - 判斷 Blocker 時讀 [planning-and-dependencies](references/planning-and-dependencies.md)。
  - 需要 Feature 例子時讀 [feature-decomposition](references/feature-decomposition.md)。
  - 需要 Bug、重構或遷移例子時讀 [decomposition-edge-cases](references/decomposition-edge-cases.md)。
- 更新、驗收或交接
  - 首先讀 [issue-lifecycle](references/issue-lifecycle.md)。
  - 撰寫內容時讀 [writing](references/writing.md)。
  - 產出留言時讀 [progress-comment](assets/templates/progress-comment.md)。
  - 產出整體進度時讀 [project-update](assets/templates/project-update.md)。
  - 交接恢復執行時讀 [handoff](assets/templates/handoff.md)。
- 放置或維護文件
  - 首先讀 [documentation](references/documentation.md)。
  - 需要週期檢查時讀 [maintenance](references/maintenance.md)。
- 多 Agent 認領或衝突
  - 首先讀 [multi-agent-coordination](references/multi-agent-coordination.md)。
  - 操作結果不明時讀 [tool-recovery](references/tool-recovery.md)。
- 逾時、限流或部分成功
  - 首先讀 [tool-recovery](references/tool-recovery.md)。
  - 能力不明時讀 [agent-tool-capabilities](references/agent-tool-capabilities.md)，並核對當前工具。
- 授權、敏感資訊或外部指令
  - 首先讀 [agent-boundaries](references/agent-boundaries.md)。
  - 環境受限時讀 [policy](references/policy.md)。
- 加入協作者或產品營運
  - 首先讀 [extension-model](references/extension-model.md)。
  - 責任與設定映射讀 [policy](references/policy.md)。
  - 啟用受理、發布、事故或維護時，讀 [maintenance](references/maintenance.md) 的相應流程。

類型範本依主要交付選取：

- 修復已承諾行為：[Bug](assets/templates/bug.md)。
- 交付新能力：[Feature](assets/templates/feature.md)。
- 取得決策證據：[研究](assets/templates/research.md)。
- 保持外部行為並調整結構：[重構](assets/templates/refactor.md)。
- 切換資料或使用流程：[遷移](assets/templates/migration.md)。

## 環境與證據

需要實際 Workspace、Team、status、責任或自動化映射時讀 [policy](references/policy.md)。
沿用適用的既有政策。
缺少政策文件不阻止一般草稿或已授權的獨立工作。
本版寫作預設為繁體中文並保留 Linear 原文術語，可由使用者明確指定的政策替換。

功能結論保留各 reference 的官方查證日期與適用限制。
使用動態功能、方案或工具欄位前核對當前來源與環境。
歷史文件不能保證當前連線可用。
案例為合成推演，驗收 checkbox 表達該案例要判斷的結果。
